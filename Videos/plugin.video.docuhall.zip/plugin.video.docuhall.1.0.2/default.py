# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Thanks to the Authors of the base code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# modified by: MUSICHALL
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.DocuHall'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_playlist_ID_1 = "PLSyCRkPeE-W2_nIFwuhPT5eGb26bBABV9" 	
YOUTUBE_playlist_ID_2 = "PLQ2GSFmitMrb4Hez9a4XzSb3vjk9-_PcE" 	
YOUTUBE_playlist_ID_3 = "PLcLMtwnOht4hKT9V0W3Vv055Ehd_8SdxS" 	
YOUTUBE_playlist_ID_4 = "PL7z9QMyBja1LWReZZVjJBBjmEr2LYuYvl" 	
YOUTUBE_playlist_ID_5 = "PL6OcpiGR1-rKtcT0Ov0DupC0omt5C3VD9"
YOUTUBE_playlist_ID_6 = "PLhGDrIpue3iI4dhOwfxoGdqSeWaRtw3uZ" 	
YOUTUBE_playlist_ID_7 = "PLnV4u_xKa3ripfSz3ItKixlJSCQhTXu5Y" 
YOUTUBE_playlist_ID_8 = "PLgPTASVBisNEiS6f5S4nymFngTYGiUYk_" 	
YOUTUBE_playlist_ID_9 = "PLMGMVfFYo_XREw9HSknByEp1M3iATTFWd" 	
YOUTUBE_playlist_ID_10 = "PLybVCOVMPtkoXTrMCD79gfOzDspqTktbn" 	
YOUTUBE_playlist_ID_11 = "PLcLMtwnOht4hQIHvYc15VTamH1S23Za-0" 
YOUTUBE_playlist_ID_12 = "PLcLMtwnOht4ht6JWE3EKu28uA8JbJjBgi" 	
YOUTUBE_playlist_ID_13 = "PLF0JBpl2yjna_Auy0S8khPNQ-bcDkHbkL" 	
YOUTUBE_playlist_ID_14 = "PLybVCOVMPtkr6BUGQDc3u0mHhKlaVrS0-" 	
YOUTUBE_playlist_ID_15 = "PLnlizpBDb7exPk3BOlsLapUJ68-Liv9JQ" 	
YOUTUBE_playlist_ID_16 = "PLnAYV-HOdPJSeTcSmQjEgB2rJrFcpbmJs" 	
YOUTUBE_playlist_ID_17 = "PLQ8yHMSBC8UDC8QfgUSDPx6vnVQuxuvGn" 
YOUTUBE_playlist_ID_18 = "PL5H3Ej7cwX-sVcpbAndGoQJ954bAs9-OC" 	
YOUTUBE_playlist_ID_19 = "PLNxO272BUiZv6dgXBejHZ2R7j98wYqV6n" 	
YOUTUBE_playlist_ID_20 = "PL5F6059A8BF6F63A0" 	
YOUTUBE_playlist_ID_21 = "PLdOQYbmbdlXFkfvlUuvAVXKoatNVQt0BI" 
YOUTUBE_playlist_ID_22 = "PLHTdwgezn5j2Zd2PP93kSar8XeBWQWKWX" 	
YOUTUBE_playlist_ID_23 = "PLdGl0ACEUL8woL60tkXQ2YwhuQmEIRzih" 
YOUTUBE_playlist_ID_24 = "PLaDyjBVNCVKy-Kdkotvez01LVQSfwYVmB" 	
YOUTUBE_playlist_ID_25 = "PL7Gl77owRvTtqr2g2z4KV1uF3RLz5ULpM" 	
YOUTUBE_playlist_ID_26 = "PLlNKltCN7wbOQ4SykrZ-Yai9Inkg3H7hD" 
YOUTUBE_playlist_ID_27 = "PLZMYKCMJPCbvBR-SUlfwZG1bojLX68VWv" 	
YOUTUBE_playlist_ID_28 = "PL7Gl77owRvTsXOB_IWthyFO4s63QHeKs6" 	
YOUTUBE_playlist_ID_29 = "PLweLk4OdOI-kzyItwyR7YjcTmyNVCd65M" 	
YOUTUBE_playlist_ID_30 = "PLzpBCPOY1Xwmmd1GG8UETHUd8SC6vyZFQ" 	
YOUTUBE_playlist_ID_31 = "PLcLMtwnOht4hQIHvYc15VTamH1S23Za-0" 	
YOUTUBE_playlist_ID_32 = "PLI4i0AYCbfZsvcFiH8AmLgIUk4xZV85G6" 	
YOUTUBE_playlist_ID_33 = "PL8QDD61UWAeVb2ufMXxPpiHO2irV_MmxS" 	
YOUTUBE_playlist_ID_34 = "PLNnz6hG_g5n8gtFHqd4KqFIDM697WRyiL" 	
YOUTUBE_playlist_ID_35 = "PLfX6r8sjgTANPptasMqz9-5_y0PVEfndr" 	
YOUTUBE_playlist_ID_36 = "PLcLMtwnOht4gb4fh1IWCOjWS5J-ZHQ1R1" 	
YOUTUBE_playlist_ID_37 = "PLAuu8RVB0KsLaJ8em7Y6KmoxqNb6q5n3T" 	
YOUTUBE_playlist_ID_38 = "PLC4FWT1NtL9EPm_i8TUTapjgl2ZS_ht_U" 
YOUTUBE_playlist_ID_39 = "PLepaMVgW8Yc8nlES3Jbv9Ox2B4wpTmZXy" 	
YOUTUBE_playlist_ID_40 = "PLGILqGfUkdwGpp3L09_qE--HfQBO-zEZc" 
YOUTUBE_playlist_ID_41 = "PLftYafR5GTliryDVANOh-WBLbO-lcXScF"
YOUTUBE_playlist_ID_42 = "PL7Gl77owRvTth-5Xd-VPVDM14UugIYUET"
YOUTUBE_playlist_ID_43 = "PLdPuSDS7TDUYxeHoWCJuKllIpQ_qFKZt4"   
YOUTUBE_playlist_ID_44 = "PLWqZF0MUAZ1dsYfBYDdxcDyqJ5yQgn5jY"   
YOUTUBE_playlist_ID_45 = "PLIvwUcXFHeOHshLU7F8Z0fSH8qd2tFU1V"   
YOUTUBE_playlist_ID_46 = "PL7Gl77owRvTvnPcV8Liz_QB5yuQ9K1FT5"   
YOUTUBE_playlist_ID_47 = "PLwPXervdIiaBjTdqwQ-bkw2UOJM3_IN_M"   
YOUTUBE_playlist_ID_48 = "PLftYafR5GTlisFihnFoKAPSqu8rXcb7DW"   
YOUTUBE_playlist_ID_49 = "PLoLwYl521zKg83hQkmYonEtoXHHKboPnj"   
YOUTUBE_playlist_ID_50 = "PLa8FoD37ilo9Agcdg6dx9t1_W4shjWeUl"
YOUTUBE_playlist_ID_51 = "PLLt4gpa2yB6K0cezJGYJ5mN2cLQRi61YC"   
YOUTUBE_playlist_ID_52 = "PLglnvA6MBlsqxWZIzqxwieGhPnSpxi5s3"   
YOUTUBE_playlist_ID_53 = "PLIJ_jSscSSNKA5SUMYhU-FNjEf2TaVfg_"   
YOUTUBE_playlist_ID_54 = "PLhi0Na006EkTvzZMTkWeyOiHn3ZKTFRRw"   
YOUTUBE_playlist_ID_55 = "PLODwjigeo1YyOUuM4jXBById37qg6hbJL"   
YOUTUBE_playlist_ID_56 = "PL7Gl77owRvTuC4eryV9MrYI1jiG7_0gaJ"   
YOUTUBE_playlist_ID_57 = "PLLzlg6WfnxdbVSaRK8J3EcA2i9rvY9xXK"   
YOUTUBE_playlist_ID_58 = "PLz7GXfjMJsQQSTvRPrFemP3f5da7pEySa"   
YOUTUBE_playlist_ID_59 = "PLZMYKCMJPCbunocC4wd7JR614qEZSvUXX"   
YOUTUBE_playlist_ID_60 = "PLNqFB7lW8Xrr-63labiXsclK_qekNhrhL"   
YOUTUBE_playlist_ID_61 = "PLyrFzjpgxykctwDsqhFPNTU0apF2rKjLG"   
YOUTUBE_playlist_ID_62 = "PLvxFc9UZUY3zizEcIQJRGmNppmUgwYEA8"   
YOUTUBE_playlist_ID_63 = "PLZ4POPAfakSGQOlMTvNhtsWBf5YLropAZ"   
YOUTUBE_playlist_ID_64 = "PLs6Z5zFedJgqpaICfkpjbsK_yDCOOjPGH"   
YOUTUBE_playlist_ID_65 = "PLe_yIHUGxwjx3U4LdGJP8w9cw4oEeonhm"   
YOUTUBE_playlist_ID_66 = "PL7Gl77owRvTvdiQRn3yfMDGg1JRjGHFWB"   
YOUTUBE_playlist_ID_67 = "PLnhq-NjCRSEWAYCtQap42-I_dECJkGpTx"   
YOUTUBE_playlist_ID_68 = "PLkt5o_SG5f0qLRavZGShLjL564SkbZDL2"   
YOUTUBE_playlist_ID_69 = "PLqAiJ3i-9oRq5E1FfC1dayk1Q6jdau_46"   
YOUTUBE_playlist_ID_70 = "PL7iQjxZEUpDl5vVbg_drUWSXAdGPAMqyf"   
YOUTUBE_playlist_ID_71 = "PLyoaXu_ewAiOJ1SclWajr8aPdZ5c-1bZX"   
YOUTUBE_playlist_ID_72 = "PLQPcX7gTF07x0PHMLkGoOOBm6IawOgA4D"   
YOUTUBE_playlist_ID_73 = "PLEfZ5NPwIVSVUSEk3lwHoCzF6mMHQTJ8H"   
YOUTUBE_playlist_ID_74 = "PLkAbDBN5-fY0zlhFdvO6mHp4ub5YwMB9O"   
YOUTUBE_playlist_ID_75 = "PLQmStubzgLox35C_cC_-bb171DiIJjsFu"   
YOUTUBE_playlist_ID_76 = "PLcRlu6WsQ88aWvupaAi9zs6B3jy4dUKnt"   
YOUTUBE_playlist_ID_77 = "PLnGdoWmhwFp5VG019jzBnOG51jTh9YB73"   
YOUTUBE_playlist_ID_78 = "PLvh8wO1OSvdBEkscCHWs77iLu6SQqDrbE"   
YOUTUBE_playlist_ID_79 = "PL2ceFeGjHmZNrtvwg2bH6EX7hBnYKf6XP"   
YOUTUBE_playlist_ID_80 = "PLDN8i9cChZOQAl6VeCnZA-f8KBVIFVO4l"   
YOUTUBE_playlist_ID_81 = "PL5bY4Gln8etuDjevpTPzxhM14eivsLqOH"   
YOUTUBE_playlist_ID_82 = "PL3xiDl5cSV5Dt6ijtweOogWIsdywQG9Lz"   
YOUTUBE_playlist_ID_83 = "PLiDr5dMixdkUXRM-g9R1AHJVx2nUuU1Ob"   
YOUTUBE_playlist_ID_84 = "PLMSP1ikT0Q5KggFPdlSrpn1rwdrmW5lId"   
YOUTUBE_playlist_ID_85 = "PLYpLsv_07x75MI-Z3LoagRJG-H9W5jDhC"   
YOUTUBE_playlist_ID_86 = "PL0wX1_LMG0k6f894DFz_O9FPzEo7kzejW"   
YOUTUBE_playlist_ID_87 = "PLQ2GSFmitMrahcfqco6251i72TwIA34A1"   
YOUTUBE_playlist_ID_88 = "PLgpQcBQ9XWw_Yz2Nj-uMH5rSc0cNZph96"   
YOUTUBE_playlist_ID_89 = "PLAfxiUR-xg3s8gK7ZYSMTNt_izKarm7Sk"   
YOUTUBE_playlist_ID_90 = "PLd-iUXSuOEbrPiyOiiHO8z5hhAfmazEfU"   
YOUTUBE_playlist_ID_91 = "PL3YkPHBfTh4IA3BPn9ay5lA3ChmeBd0gA"   
YOUTUBE_playlist_ID_92 = "PL83uSP3LRG7592jcwC9Oy6xBfDYPo4OvZ"   
YOUTUBE_playlist_ID_93 = "PLy-qmp54bpB3FAYmJ8sZbwp-3Yyragp36"   
YOUTUBE_playlist_ID_94 = "PLBl8uqP1c1AR4kCGY8hfCK3PTfQFV-Si1"   
YOUTUBE_playlist_ID_95 = "PL9qT3cTHNeGDbgFedrB75wuQuEHxPXJ4-"   
YOUTUBE_playlist_ID_96 = "PLXNXTwnjZ9RNDFgaclA4CAJE0kYI1WyvA"   
YOUTUBE_playlist_ID_97 = "PL2F311D0EC3613FF7"   
YOUTUBE_playlist_ID_98 = "PLLxxgrF1QnBicl1c-LxPlukxMsuKbzerO"   
YOUTUBE_playlist_ID_99 = "PLCOcS_82_WcaJVAl6VZVG8DWT5TOFwjTd"   
YOUTUBE_playlist_ID_100 = "PLYZMZqK5ibS_u5Cg0zT6RUmjNokDB0kue" 
YOUTUBE_playlist_ID_101 = "PL7iQjxZEUpDn20QoSVf4EFUh6wSlyR6I3"   
YOUTUBE_playlist_ID_102 = "PL7Gl77owRvTvuRjpyhO8lY28xcRmPkCP6"   
YOUTUBE_playlist_ID_103 = "PLXYVeJTcn1wYR4JazhIgHRsc-hKftITXB"   
YOUTUBE_playlist_ID_104 = "PLusO63Nwcxf8lXSkrLv9Kv1PEG3F_7vMR"   
YOUTUBE_playlist_ID_105 = "PLuCCZXv0C9HRT0eX1bgq6miqbc-b9E89L"   
YOUTUBE_playlist_ID_106 = "PLag-vCNkW7_Q3X_K-ISpptDF8QK0bY5GU"   
YOUTUBE_playlist_ID_107 = "PLnD6x2p8nHr51WhpjAdAb-jl0MgeXWqph"   
YOUTUBE_playlist_ID_108 = "PLQF7H2AzfefO009FSgU3xjJVnrPNNW1kE"   
YOUTUBE_playlist_ID_109 = "PLzeSEkTvfNkd9HCacBgLGmppp42RgNJ7r"   
YOUTUBE_playlist_ID_110 = "PLgcCV8T_UkUao5KDygBrbPMktIfSz_SXe"   
YOUTUBE_playlist_ID_111 = "PLkgIxWtXSRl4Fz_Km0pT93WDIxJDFmuGI"   
YOUTUBE_playlist_ID_112 = "PLSNLaAwR6E8yZGlfPZazdyKICA1py7onL"   
YOUTUBE_playlist_ID_113 = "PLGje2TnQsOv9Lac9JOwvtljYV6Jnq6Uz7"   
YOUTUBE_playlist_ID_114 = "PLhoLNpXDxEdTc4pktGzuZemke3WRac8YK"   
YOUTUBE_playlist_ID_115 = "PLYFW7rJpDJfZ8Zfn-1OSTWauG6hSbd-W2"   
YOUTUBE_playlist_ID_116 = "PL0E7994D36B19569D"   
YOUTUBE_playlist_ID_117 = "PL_mCQt23V8ybXeum2oqvpROVrPcNV_c75"   
YOUTUBE_playlist_ID_118 = "PLvxFc9UZUY3wDcMRbs_s4wTm8T-qQV_OX"   
YOUTUBE_playlist_ID_119 = "PL7Gl77owRvTuc_XdTKaMFwK3PUS3risOv"   
YOUTUBE_playlist_ID_120 = "PLiKjDPTQ4dGI9bdpPmfpW6tbkh1A-d_ic" 	
# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pide Aqui Tu Documental en el Grupo Telegram @AprendiendoKodi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1+"/",
        thumbnail="https://i.imgur.com/44PV3Ff.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Al Filo De Lo Imposible[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_50+"/",
        thumbnail="https://i.imgur.com/s1BlLFj.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Alma Viajera[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_101+"/",
        thumbnail="https://i.imgur.com/z9Vc2Xt.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Animales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_12+"/",
        thumbnail="https://i.imgur.com/yq4RuxO.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Animales Terrorificos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_98+"/",
        thumbnail="https://i.imgur.com/VvNrfKi.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Antiguo Egipto[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_63+"/",
        thumbnail="https://i.imgur.com/nNEFyxv.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Apocalipsis: La Segunda Guerra Mundial HD[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_6+"/",
        thumbnail="https://i.imgur.com/xZw7GFN.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Armas De Fuego[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_114+"/",
        thumbnail="https://i.imgur.com/uifjl8Q.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Arqueologia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_116+"/",
        thumbnail="https://i.imgur.com/ELldYEk.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Asesinos En Serie[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_9+"/",
        thumbnail="https://i.imgur.com/l8BRLUo.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Aves Exoticas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_65+"/",
        thumbnail="https://i.imgur.com/6ivX2Wq.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Aviones De Guerra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_57+"/",
        thumbnail="https://i.imgur.com/13FhiU9.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Belicos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_4+"/",
        thumbnail="https://i.imgur.com/7BWSJ0p.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Buceo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_52+"/",
        thumbnail="https://i.imgur.com/X7sbHbs.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Camino A La Libertad[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_86+"/",
        thumbnail="https://i.imgur.com/xfy10yY.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Canal Historia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_29+"/",
        thumbnail="https://i.imgur.com/CB5Ka2b.png",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta] Canal Viajar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_38+"/",
        thumbnail="https://i.imgur.com/vHmFoaP.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Canarias Un Paseo Por Las Nubes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_61+"/",
        thumbnail="https://i.imgur.com/6SDdUCA.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ciencia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_17+"/",
        thumbnail="https://i.imgur.com/rEzzSsF.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ciencias y Fisica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_43+"/",
        thumbnail="https://i.imgur.com/UBLurQB.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ciencias y Tecnologias[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_25+"/",
        thumbnail="https://i.imgur.com/ucMWq4e.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Construyendo Gigantes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_68+"/",
        thumbnail="https://i.imgur.com/8NciFo1.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Criaturas del Mar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_15+"/",
        thumbnail="https://i.imgur.com/BXeGRp2.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Cruceros De Ensueño[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_64+"/",
        thumbnail="https://i.imgur.com/hiNsC4Y.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Criaturas Mitologicas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_56+"/",
        thumbnail="https://i.imgur.com/R32qW9I.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Dark Net La Red Oscura[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_119+"/",
        thumbnail="https://i.imgur.com/kD3uGwG.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]David Attenborough[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_93+"/",
        thumbnail="https://i.imgur.com/h1R0qOV.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Discovery[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_99+"/",
        thumbnail="https://i.imgur.com/5IuCktA.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Docufilia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_71+"/",
        thumbnail="https://i.imgur.com/gvCORs2.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Documentales Cedecom[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_83+"/",
        thumbnail="https://i.imgur.com/6dZJH23.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Documentales Completos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_16+"/",
        thumbnail="https://i.imgur.com/DhWXLps.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Documentales De Interes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_103+"/",
        thumbnail="https://i.imgur.com/uS69ixK.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]El Hip Hop[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_88+"/",
        thumbnail="https://i.imgur.com/SLwcw7b.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Documentales Para Aprender[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_53+"/",
        thumbnail="https://i.imgur.com/39CtA2C.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Documentales Recomendados[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_31+"/",
        thumbnail="https://i.imgur.com/zQakADP.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Documentales Segunda Guerra Mundial[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_7+"/",
        thumbnail="https://i.imgur.com/JDu5oEs.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Documentos Tv[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_24+"/",
        thumbnail="https://i.imgur.com/d0yXB1C.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Documentales XXX[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_34+"/",
        thumbnail="https://i.imgur.com/pzCmhEd.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]El Cosmos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_92+"/",
        thumbnail="https://i.imgur.com/sYWurEy.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]El Hombre y La Tierra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_30+"/",
        thumbnail="https://i.imgur.com/6GFvtvo.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]El Maravilloso Mundo De Los Animanles Disney[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_85+"/",
        thumbnail="https://i.imgur.com/5SpeuMv.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]El Mundo De La Fotografia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_91+"/",
        thumbnail="https://i.imgur.com/x6SQlrW.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]El Oeste Americano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_117+"/",
        thumbnail="https://i.imgur.com/DBgQr0v.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]El Origen De La Humanidad[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_48+"/",
        thumbnail="https://i.imgur.com/3YNNVM2.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]El Origen del Universo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_41+"/",
        thumbnail="https://i.imgur.com/PYE0YS5.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Enigmas y Misterios De La Historia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_60+"/",
        thumbnail="https://i.imgur.com/59RTF4c.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Esoterismo y Ocultismo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_80+"/",
        thumbnail="https://i.imgur.com/1iAen85.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]España Entre El Cielo y La Tierra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_97+"/",
        thumbnail="https://i.imgur.com/5Wj3ZKy.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Extraterrestres I[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_18+"/",
        thumbnail="https://i.imgur.com/FAKRFgW.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Extraterrestres II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_19+"/",
        thumbnail="https://i.imgur.com/7YGy6Gw.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Fabricas De Coches[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_76+"/",
        thumbnail="https://i.imgur.com/bVeWLlP.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Gastronomias Del Mundo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_79+"/",
        thumbnail="https://i.imgur.com/rr0OrhC.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Geologia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_47+"/",
        thumbnail="https://i.imgur.com/1Rbp6x0.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Grandes Batallas Navales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_58+"/",
        thumbnail="https://i.imgur.com/632XDwW.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Grandes Biografias[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_72+"/",
        thumbnail="https://i.imgur.com/Ps0qfDv.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Grandes Biografias II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_73+"/",
        thumbnail="https://i.imgur.com/vcQ6t04.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Grandes Compositores[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_108+"/",
        thumbnail="https://i.imgur.com/oAspbF2.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Grandes Compositores II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_109+"/",
        thumbnail="https://i.imgur.com/ntx1QHi.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Grandes Descubridores[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_39+"/",
        thumbnail="https://i.imgur.com/3INzuD8.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Grandes Dinosaurios[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_26+"/",
        thumbnail="https://i.imgur.com/r4hM8C6.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Grandes Documentales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_27+"/",
        thumbnail="https://i.imgur.com/ccXwFy8.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Grandes Felinos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_59+"/",
        thumbnail="https://i.imgur.com/bEG2w84.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Hadas y Duendes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_105+"/",
        thumbnail="https://i.imgur.com/XgxczDT.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Historia I[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_2+"/",
        thumbnail="https://i.imgur.com/hfyJOxU.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Historia II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_3+"/",
        thumbnail="https://i.imgur.com/NMbgzRe.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Historia Del Alpinismo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_51+"/",
        thumbnail="https://i.imgur.com/8QZIAAw.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Historia del Arte[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_8+"/",
        thumbnail="https://i.imgur.com/gT5Ulrp.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Historia del Cine[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_21+"/",
        thumbnail="https://i.imgur.com/wDrbeap.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Historia del Cine Mudo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_22+"/",
        thumbnail="https://i.imgur.com/tpwnxjQ.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Historia del Fútbol[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_33+"/",
        thumbnail="https://i.imgur.com/xYCR4yV.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Historia De Europa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_87+"/",
        thumbnail="https://i.imgur.com/AXaEIxM.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Historia De La Formula 1[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_81+"/",
        thumbnail="https://i.imgur.com/7iLQi03.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Historia De Las Motocicletas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_82+"/",
        thumbnail="https://i.imgur.com/cKPdOUw.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Holocausto Nazi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_113+"/",
        thumbnail="https://i.imgur.com/8QKM7px.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Historia Universal Del Arte[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_95+"/",
        thumbnail="https://i.imgur.com/qffFsYj.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Humanos 3.0[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_45+"/",
        thumbnail="https://i.imgur.com/5Q29yuP.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Indios Americanos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_110+"/",
        thumbnail="https://i.imgur.com/QxlKaui.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Informe Criminal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_89+"/",
        thumbnail="https://i.imgur.com/9WJUgX0.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Internet[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_66+"/",
        thumbnail="https://i.imgur.com/6bDrhp6.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]La Edad Media[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_100+"/",
        thumbnail="https://i.imgur.com/wO1H6yi.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]La Guerra Civil Española[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_118+"/",
        thumbnail="https://i.imgur.com/byap2et.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]La Guerra Fria[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_69+"/",
        thumbnail="https://i.imgur.com/q4Lr7cL.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]La Noche Tematica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_96+"/",
        thumbnail="https://i.imgur.com/Y74xNPH.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]La Prehistoria[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_37+"/",
        thumbnail="https://i.imgur.com/Vl8TlTS.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Las Religiones En El Mundo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_55+"/",
        thumbnail="https://i.imgur.com/XhrhACi.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Las Religiones En El Mundo II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_104+"/",
        thumbnail="https://i.imgur.com/33o12wS.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Los Años Del Nodo En España[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_23+"/",
        thumbnail="https://i.imgur.com/ObiQDPL.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Maquinas Letales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_115+"/",
        thumbnail="https://i.imgur.com/MuFNbYl.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Megacatastrofes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_102+"/",
        thumbnail="https://i.imgur.com/HvHunQ5.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Megaestructuras[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_77+"/",
        thumbnail="https://i.imgur.com/iX8MYKm.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Megaestructuras Nazis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_78+"/",
        thumbnail="https://i.imgur.com/ImhTFIb.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Mejores Documentales Ovni[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_20+"/",
        thumbnail="https://i.imgur.com/pzQPCFw.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Memorias Historicas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_112+"/",
        thumbnail="https://i.imgur.com/lN2YF7l.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Miscelanea de Documentales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_42+"/",
        thumbnail="https://i.imgur.com/f0k8Wqh.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Misterios[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_36+"/",
        thumbnail="https://i.imgur.com/LdQmEap.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Misterios y Conspiraciones[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_75+"/",
        thumbnail="https://i.imgur.com/A1qX2DF.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Mitologia Griega[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_106+"/",
        thumbnail="https://i.imgur.com/t1bpPQf.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Mitologia Nordica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_107+"/",
        thumbnail="https://i.imgur.com/53x8Iks.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Mujeres En La Historia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_111+"/",
        thumbnail="https://i.imgur.com/4cpXdU8.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Nacido Para Matar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_74+"/",
        thumbnail="https://i.imgur.com/E6ngArT.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Naturaleza Marina Oceanos y Mares I[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_13+"/",
        thumbnail="https://i.imgur.com/tbekTWR.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Naturaleza Marina Oceanos y Mares II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_14+"/",
        thumbnail="https://i.imgur.com/MaGO4px.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]National Greographic[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_28+"/",
        thumbnail="https://i.imgur.com/7uIehxI.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]New Atlantis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_94+"/",
        thumbnail="https://i.imgur.com/GdinQsl.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Paleontologia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_49+"/",
        thumbnail="https://i.imgur.com/Rm5SLIk.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Pesca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_35+"/",
        thumbnail="https://i.imgur.com/3Dc6fvg.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Planeta Documental[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_70+"/",
        thumbnail="https://i.imgur.com/KXaHzVn.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Planeta Tierra - Documentales HD[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_10+"/",
        thumbnail="https://i.imgur.com/6ZDgc3n.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Primera Guerra Mundial[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_5+"/",
        thumbnail="https://i.imgur.com/kZ0TTxM.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Recomendados[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_11+"/",
        thumbnail="https://i.imgur.com/AVyye0P.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Redes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_54+"/",
        thumbnail="https://i.imgur.com/vWuYuhB.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Reyes De España[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_62+"/",
        thumbnail="https://i.imgur.com/OfJ5EPZ.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Robotica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_120+"/",
        thumbnail="https://i.imgur.com/1V9xDMj.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]RT Documentales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_32+"/",
        thumbnail="https://i.imgur.com/Q09pr2n.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Tienes Insomnio....Escucha y Duerme[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_84+"/",
        thumbnail="https://i.imgur.com/6Ma99lr.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Trenes Del Mundo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_67+"/",
        thumbnail="https://i.imgur.com/kPvYY69.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Universo Matematico[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_44+"/",
        thumbnail="https://i.imgur.com/asScFpr.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Viajes Al Polo Sur[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_40+"/",
        thumbnail="https://i.imgur.com/izyn126.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Videojuegos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_90+"/",
        thumbnail="https://i.imgur.com/7qaYRUh.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Volcanes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_46+"/",
        thumbnail="https://i.imgur.com/dKBL78H.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )
		
run()