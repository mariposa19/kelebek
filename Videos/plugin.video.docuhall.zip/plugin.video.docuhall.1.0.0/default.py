# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Thanks to the Authors of the base code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# modified by: MUSICHALL
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.docuhall'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_playlist_ID_1 = "PLQ2GSFmitMrb4Hez9a4XzSb3vjk9-_PcE" 	
YOUTUBE_playlist_ID_2 = "PLcLMtwnOht4hKT9V0W3Vv055Ehd_8SdxS" 	
YOUTUBE_playlist_ID_3 = "PLftYafR5GTliryDVANOh-WBLbO-lcXScF" 	
YOUTUBE_playlist_ID_4 = "PL7z9QMyBja1LWReZZVjJBBjmEr2LYuYvl" 	
YOUTUBE_playlist_ID_5 = "PL6OcpiGR1-rKtcT0Ov0DupC0omt5C3VD9"
YOUTUBE_playlist_ID_6 = "PLhGDrIpue3iI4dhOwfxoGdqSeWaRtw3uZ" 	
YOUTUBE_playlist_ID_7 = "PLnV4u_xKa3ripfSz3ItKixlJSCQhTXu5Y" 
YOUTUBE_playlist_ID_8 = "PLgPTASVBisNEiS6f5S4nymFngTYGiUYk_" 	
YOUTUBE_playlist_ID_9 = "PLMGMVfFYo_XREw9HSknByEp1M3iATTFWd" 	
YOUTUBE_playlist_ID_10 = "PLybVCOVMPtkoXTrMCD79gfOzDspqTktbn" 	
YOUTUBE_playlist_ID_11 = "PLcLMtwnOht4hQIHvYc15VTamH1S23Za-0" 
YOUTUBE_playlist_ID_12 = "PLcLMtwnOht4ht6JWE3EKu28uA8JbJjBgi" 	
YOUTUBE_playlist_ID_13 = "PLF0JBpl2yjna_Auy0S8khPNQ-bcDkHbkL" 	
YOUTUBE_playlist_ID_14 = "PLybVCOVMPtkr6BUGQDc3u0mHhKlaVrS0-" 	
YOUTUBE_playlist_ID_15 = "PLnlizpBDb7exPk3BOlsLapUJ68-Liv9JQ" 	
YOUTUBE_playlist_ID_16 = "PLnAYV-HOdPJSeTcSmQjEgB2rJrFcpbmJs" 	
YOUTUBE_playlist_ID_17 = "PLQ8yHMSBC8UDC8QfgUSDPx6vnVQuxuvGn" 
YOUTUBE_playlist_ID_18 = "PL5H3Ej7cwX-sVcpbAndGoQJ954bAs9-OC" 	
YOUTUBE_playlist_ID_19 = "PLNxO272BUiZv6dgXBejHZ2R7j98wYqV6n" 	
YOUTUBE_playlist_ID_20 = "PL5F6059A8BF6F63A0" 	
YOUTUBE_playlist_ID_21 = "PLdOQYbmbdlXFkfvlUuvAVXKoatNVQt0BI" 
YOUTUBE_playlist_ID_22 = "PLHTdwgezn5j2Zd2PP93kSar8XeBWQWKWX" 	
YOUTUBE_playlist_ID_23 = "PLdGl0ACEUL8woL60tkXQ2YwhuQmEIRzih" 
YOUTUBE_playlist_ID_24 = "PLaDyjBVNCVKy-Kdkotvez01LVQSfwYVmB" 	
YOUTUBE_playlist_ID_25 = "PL7Gl77owRvTtqr2g2z4KV1uF3RLz5ULpM" 	
YOUTUBE_playlist_ID_26 = "PLlNKltCN7wbOQ4SykrZ-Yai9Inkg3H7hD" 
YOUTUBE_playlist_ID_27 = "PLZMYKCMJPCbvBR-SUlfwZG1bojLX68VWv" 	
YOUTUBE_playlist_ID_28 = "PL7Gl77owRvTsXOB_IWthyFO4s63QHeKs6" 	
YOUTUBE_playlist_ID_29 = "PLweLk4OdOI-kzyItwyR7YjcTmyNVCd65M" 	
YOUTUBE_playlist_ID_30 = "PLzpBCPOY1Xwmmd1GG8UETHUd8SC6vyZFQ" 	
YOUTUBE_playlist_ID_31 = "PLcLMtwnOht4hQIHvYc15VTamH1S23Za-0" 	
YOUTUBE_playlist_ID_32 = "PLI4i0AYCbfZsvcFiH8AmLgIUk4xZV85G6" 	
YOUTUBE_playlist_ID_33 = "PL8QDD61UWAeVb2ufMXxPpiHO2irV_MmxS" 	
YOUTUBE_playlist_ID_34 = "PLNnz6hG_g5n8gtFHqd4KqFIDM697WRyiL" 	
YOUTUBE_playlist_ID_35 = "PLfX6r8sjgTANPptasMqz9-5_y0PVEfndr" 	
YOUTUBE_playlist_ID_36 = "PLcLMtwnOht4gb4fh1IWCOjWS5J-ZHQ1R1" 	
YOUTUBE_playlist_ID_37 = "PLAuu8RVB0KsLaJ8em7Y6KmoxqNb6q5n3T" 	
YOUTUBE_playlist_ID_38 = "PLC4FWT1NtL9EPm_i8TUTapjgl2ZS_ht_U" 
YOUTUBE_playlist_ID_39 = "PLepaMVgW8Yc8nlES3Jbv9Ox2B4wpTmZXy" 	
YOUTUBE_playlist_ID_40 = "PLGILqGfUkdwGpp3L09_qE--HfQBO-zEZc" 	
# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Historia I[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1+"/",
        thumbnail="https://i.imgur.com/hfyJOxU.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Historia II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_2+"/",
        thumbnail="https://i.imgur.com/NMbgzRe.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]El Origen del Universo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_3+"/",
        thumbnail="https://i.imgur.com/PYE0YS5.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Belicos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_4+"/",
        thumbnail="https://i.imgur.com/7BWSJ0p.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Primera Guerra Mundial[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_5+"/",
        thumbnail="https://i.imgur.com/kZ0TTxM.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Apocalipsis: La Segunda Guerra Mundial HD[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_6+"/",
        thumbnail="https://i.imgur.com/xZw7GFN.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Documentales Segunda Guerra Mundial[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_7+"/",
        thumbnail="https://i.imgur.com/JDu5oEs.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Historia del Arte[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_8+"/",
        thumbnail="https://i.imgur.com/gT5Ulrp.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Asesinos En Serie[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_9+"/",
        thumbnail="https://i.imgur.com/l8BRLUo.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Planeta Tierra - Documentales HD[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_10+"/",
        thumbnail="https://i.imgur.com/6ZDgc3n.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Recomendados[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_11+"/",
        thumbnail="https://i.imgur.com/AVyye0P.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Animales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_12+"/",
        thumbnail="https://i.imgur.com/yq4RuxO.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Naturaleza Marina Oceanos y Mares I[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_13+"/",
        thumbnail="https://i.imgur.com/tbekTWR.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Naturaleza Marina Oceanos y Mares II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_14+"/",
        thumbnail="https://i.imgur.com/MaGO4px.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Criaturas del Mar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_15+"/",
        thumbnail="https://i.imgur.com/BXeGRp2.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Documentales Completos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_16+"/",
        thumbnail="https://i.imgur.com/DhWXLps.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Ciencia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_17+"/",
        thumbnail="https://i.imgur.com/rEzzSsF.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Extraterrestres I[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_18+"/",
        thumbnail="https://i.imgur.com/FAKRFgW.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Extraterrestres II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_19+"/",
        thumbnail="https://i.imgur.com/7YGy6Gw.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Mejores Documentales Ovni[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_20+"/",
        thumbnail="https://i.imgur.com/pzQPCFw.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Historia del Cine[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_21+"/",
        thumbnail="https://i.imgur.com/wDrbeap.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Historia del Cine Mudo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_22+"/",
        thumbnail="https://i.imgur.com/tpwnxjQ.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Los Años Del Nodo En España[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_23+"/",
        thumbnail="https://i.imgur.com/ObiQDPL.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Documentos Tv[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_24+"/",
        thumbnail="https://i.imgur.com/d0yXB1C.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Ciencias y Tecnologias[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_25+"/",
        thumbnail="https://i.imgur.com/ucMWq4e.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Grandes Dinosaurios[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_26+"/",
        thumbnail="https://i.imgur.com/r4hM8C6.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Grandes Documentales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_27+"/",
        thumbnail="https://i.imgur.com/ccXwFy8.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]National Greographic[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_28+"/",
        thumbnail="https://i.imgur.com/7uIehxI.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Canal Historia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_29+"/",
        thumbnail="https://i.imgur.com/CB5Ka2b.png",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]El Hombre y La Tierra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_30+"/",
        thumbnail="https://i.imgur.com/6GFvtvo.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Documentales Recomendados[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_31+"/",
        thumbnail="https://i.imgur.com/zQakADP.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]RT Documentales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_32+"/",
        thumbnail="https://i.imgur.com/Q09pr2n.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Historia del Fútbol[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_33+"/",
        thumbnail="https://i.imgur.com/xYCR4yV.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Documentales XXX[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_34+"/",
        thumbnail="https://i.imgur.com/pzCmhEd.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Pesca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_35+"/",
        thumbnail="https://i.imgur.com/3Dc6fvg.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Misterios[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_36+"/",
        thumbnail="https://i.imgur.com/LdQmEap.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]La Prehistoria[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_37+"/",
        thumbnail="https://i.imgur.com/Vl8TlTS.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow] Canal Viajar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_38+"/",
        thumbnail="https://i.imgur.com/vHmFoaP.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Grandes Descubridores[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_39+"/",
        thumbnail="https://i.imgur.com/3INzuD8.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Viajes Al Polo Sur[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_40+"/",
        thumbnail="https://i.imgur.com/izyn126.jpg",
		fanart="https://i.imgur.com/44PV3Ff.jpg",
        folder=True )

run()