# -*- coding: utf-8 -*-
from core.libs import *

HOST = 'https://cuevana3.io'

LNG = Languages({
    Languages.es: ['español', 'espanol', '210'],
    Languages.la: ['latino', '48'],
    Languages.vos: ['subtitulado', '51']
})

QLT = Qualities({
    Qualities.hd: ['49', 'HD'],
    Qualities.rip: ['9422', 'DVD'],
    Qualities.scr: ['53', 'WEB-S']
})

SERVERS = {
    '28190': 'fembed',
    '55625': 'damedamehoy',
    '54846': 'streamtape',
    '47506': 'mystream',
    '10190': 'hqq',
    '7251': 'hqq'
}


def mainlist(item):
    logger.trace()
    itemlist = list()

    new_item = item.clone(
        type='label',
        label="Películas",
        category='movie',
        thumb='thumb/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    )
    itemlist.append(new_item)
    itemlist.extend(menupeliculas(new_item))

    new_item = item.clone(
        type='label',
        label="Series",
        category='tvshow',
        thumb='thumb/tvshow.png',
        icon='icon/tvshow.png',
        poster='poster/tvshow.png',
    )
    itemlist.append(new_item)
    itemlist.extend(menuseries(new_item))

    return itemlist


def menupeliculas(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="movies",
        label="Recientes",
        url=HOST + '/peliculas',
        type="item",
        group=True,
        content_type='movies'))

    itemlist.append(item.clone(
        action="movies",
        label="Español",
        url=HOST + "/peliculas-espanol",
        type="item",
        group=True,
        lang=[Languages.es],
        content_type='movies'))

    itemlist.append(item.clone(
        action="movies",
        label="Latino",
        url=HOST + "/peliculas-latino",
        type="item",
        group=True,
        lang=[Languages.la],
        content_type='movies'))

    itemlist.append(item.clone(
        action="movies",
        label="Subtitulado",
        url=HOST + "/peliculas-subtituladas",
        type="item",
        group=True,
        lang=[Languages.vos],
        content_type='movies'))

    itemlist.append(item.clone(
        action="generos",
        label="Géneros",
        url=HOST,
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        action="movie_search",
        label="Buscar",
        query=True,
        type='search',
        group=True,
        content_type='movies'
    ))

    return itemlist


def menuseries(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="tvshows",
        label="Últimas",
        url=HOST + "/serie",
        type="item",
        group=True,
        post_action='cuevana_ajax_pagination',
        post_page=1,
        content_type='tvshows'))

    itemlist.append(item.clone(
        action="tvshows",
        label="Estrenos",
        url=HOST + "/serie",
        type="item",
        group=True,
        post_action='cuevana_ajax_pagination_estreno',
        post_page=1,
        content_type='tvshows'))

    itemlist.append(item.clone(
        action="tvshows",
        label="Más vistas",
        url=HOST + "/serie",
        type="item",
        group=True,
        post_action='cuevana_ajax_pagination_view',
        post_page=1,
        content_type='tvshows'))

    itemlist.append(item.clone(
        action="newest_episodes",
        label="Nuevos episodios",
        url=HOST + "/serie",
        type="item",
        group=True,
        content_type='episodes'))

    return itemlist


def generos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    patron = '<a href=([^>]+/category/[^>]+)>([^<]+)</a>'
    for url, title in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            label=title,
            url=urllib_parse.urljoin(item.url, url),
            action='movies',
            content_type='movies',
        ))

    return sorted(itemlist, key=lambda x: x.label)


def movie_search(item):
    logger.trace()
    item.url = HOST + '/?s=%s' % item.query
    return movies(item)


@LimitResults
def movies(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    patron = r'<li class="xxx TPostMv">.*?<a href=([^>]+)>.*?data-src=([^ ]+).*?<h2 class="Title">([^<]+)</h2>.*?' \
             r'<span class="Date AAIco-date_range">(\d+)</span> <span class=Qlty>([^<]+)</span></p>' \
             r'<div class=Description><p><p>([^<]+)'

    for url, poster, title, year, qlt, plot in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            title=title,
            year=int(year),
            poster=poster,
            type='movie',
            action='findvideos',
            url=url,
            plot=plot,
            quality=QLT.get(qlt),
            content_type='servers'
        ))

    # Paginador
    next_page = scrapertools.find_single_match(data, r'<a href=([^ ]+) class="next page-numbers">')

    if next_page:
        itemlist.append(item.clone(type='next', url=next_page))

    return itemlist


def findvideos(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    # Stream
    patron = r'<li data-TPlayerNv=([^ ]+) data-server=(\d+) data-quality=(\d+) data-lang=(\d+)'

    for _id, server, qlt, lng in scrapertools.find_multiple_matches(data, patron):
        if item.lang and isinstance(item.lang, list) and LNG.get(lng) not in item.lang:
            continue

        url_patron = r'<div class=TPlayerTb id=%s><iframe class=no-you width=560 height=315 data-src="([^"]+)"' % _id
        url = scrapertools.find_single_match(data, url_patron)

        itemlist.append(item.clone(
            url=urllib_parse.urljoin(item.url, url),
            type='server',
            server=SERVERS.get(server, server),
            lang=LNG.get(lng),
            quality=QLT.get(qlt),
            action='play'
        ))

    # Descargas
    patron = r'<span class=Num>#\d+</span>([^<]+)</td><td>([^<]+)</td><td><span>([^<]+)</span>.*?href="?([^ "#]+)"?'
    for server, lng, qlt, url in scrapertools.find_multiple_matches(data, patron):
        if item.lang and isinstance(item.lang, list) and LNG.get(lng.lower()) not in item.lang:
            continue

        itemlist.append(item.clone(
            url=urllib_parse.urljoin(item.url, url),
            type='server',
            server=server.lower().strip(),
            lang=LNG.get(lng.lower()),
            quality=QLT.get(qlt),
            action='play',
            stream=False
        ))

    return servertools.get_servers_from_id(itemlist)


def newest_episodes(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    data = scrapertools.find_single_match(data, '<h1>Ultimos Episodios</h1>(.*?)<h1>Series Online</h1>')

    patron = r'<li class="xxx TPostMv">.*?<a href=([^>]+)>.*?<span class=Year>([^<]+)</span>.*?' \
             r'data-src=([^ ]+).*?<h2 class="Title">([^<]+)</h2>.*?'

    for url, episode, thumb, title in scrapertools.find_multiple_matches(data, patron):
        if ':' in title:
            tvshowtitle = title.split(':')[0]
            season, episode = scrapertools.get_season_and_episode(title)

        else:
            tvshowtitle = title
            season, episode = scrapertools.get_season_and_episode(title)
            tvshowtitle = re.sub(r'\d+x\d+', '', tvshowtitle)

        itemlist.append(item.clone(
            tvshowtitle=tvshowtitle,
            season=int(season),
            episode=int(episode),
            thumb=thumb,
            type='episode',
            action='findvideos',
            url=url,
            content_type='servers'
        ))

    return itemlist


def tvshows(item):
    logger.trace()
    itemlist = list()

    post = {
        'action': item.post_action,
        'page': item.post_page
    }

    data = scrapertools.remove_white_spaces(httptools.downloadpage(
        HOST + '/wp-admin/admin-ajax.php',
        post=post
    ).data)

    patron = r'<li class="xxx TPostMv">.*?<a href=([^>]+)>.*?<span class="Year">(\d*)</span>.*?src="([^"]+)".*?' \
             r'<h2 class="Title">([^<]+)</h2>.*?<div class="Description"><p><p>([^<]+)'

    for url, year, poster, title, plot in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            title=title,
            poster=poster,
            type='tvshow',
            action='seasons',
            url=urllib_parse.urljoin(item.url, url),
            content_type='seasons'
        ))

    # Paginador
    next_page = scrapertools.find_single_match(data, r'(wp-admin/admin-ajax.php\?paged=%s)' % (item.post_page + 1))

    if next_page:
        itemlist.append(item.clone(type='next', post_page=item.post_page + 1))

    return itemlist


def seasons(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    patron = r'<option value=(\d+)>Temporada \d+</option>'

    for season in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            tvshowtitle=item.title,
            season=int(season),
            type='season',
            action='episodes',
            content_type='episodes'
        ))

    return itemlist


def episodes(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)
    data = scrapertools.find_single_match(data, r'<ul id=season-%s[^>]+>.*?</ul>' % item.season)

    patron = r'<li class="xxx TPostMv">.*?href=([^>]+).*?<span class=Year>\d+x(\d+)</span>.*?' \
             r'data-src=([^ ]+).*?<h2 class="Title">([^<]+)</h2>'

    for url, episode, thumb, title in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            title=title,
            episode=int(episode),
            url=url,
            thumb=urllib_parse.urljoin(item.url, url),
            type='episode',
            action='findvideos',
            content_type='servers'
        ))

    return itemlist


def play(item):
    logger.trace()
    videoid = scrapertools.find_single_match(item.url, 'h=([^$]+)')

    if '/sc/index.php' in item.url:  # Streamtape
        item.url = httptools.downloadpage(
            urllib_parse.urljoin(item.url, 'r.php'),
            post={
                'h': videoid
            },
            add_referer=True,
            follow_redirects=False
        ).headers['location']

    elif '/ir/player.php' in item.url:  # mystream
        post = {
            'url': videoid
        }
        item.url = httptools.downloadpage(
            urllib_parse.urljoin(item.url, 'rd.php'),
            post=post,
            add_referer=True,
            follow_redirects=False
        ).headers['location']

    elif '/fembed/' in item.url:  # fembed
        data = jsontools.load_json(httptools.downloadpage(
            urllib_parse.urljoin(item.url, '/fembed/api.php'),
            post={
                'h': videoid
            },
            add_referer=True
        ).data)
        item.url = data['url']

    elif 'ir/goto_ddh.php' in item.url:  # damedamehoy
        item.url = httptools.downloadpage(
            urllib_parse.urljoin(item.url, 'redirect_ddh.php'),
            post={
                'url': videoid
            },
            add_referer=True,
            follow_redirects=False
        ).headers['location']

    elif 'uptobox/' in item.url:  # uptobox

        data = jsontools.load_json(httptools.downloadpage(
            urllib_parse.urljoin(item.url, '/uptobox/api.php'),
            post={
                'h': videoid
            },
            add_referer=True
        ).data)
        item.url = data['url']

    return servertools.normalize_url(item)
