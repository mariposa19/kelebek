# -*- coding: utf-8 -*-
from core.libs import *

HOST = 'https://www.pelis24.in'

LNG = Languages({
    Languages.es: ['es', 'Español'],
    Languages.la: ['mx', 'ar', 'co', 'Latino'],
    Languages.sub_es: ['en', 'de', 'it', 'kr', 'jp', 'fr', 'cn', 'se', 'ph', 'egt', 'cl', 'pl', 'ru', 'br',
                       'Subtitulado']
})

QLT = Qualities({
    Qualities.hd_full: ['HD 1080p'],
    Qualities.hd: ['HD 720p', 'WEB-DL 720p'],
    Qualities.rip: ['DVD Rip', 'HDRip'],
    Qualities.scr: ['TS-Screener', 'WEBScreener']
})


def mainlist(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="movies",
        label="Novedades",
        url=HOST + "/movies",
        type="item",
        content_type='movies'))

    itemlist.append(item.clone(
        action="movies",
        label="Español",
        url=HOST + "/genre/castellano",
        type="item",
        lang=[Languages.es],
        content_type='movies'))

    itemlist.append(item.clone(
        action="movies",
        label="Latino",
        url=HOST + "/genre/latino",
        type="item",
        lang=[Languages.la],
        content_type='movies'))

    itemlist.append(item.clone(
        action="generos",
        label="Géneros",
        url=HOST,
        type="item",
    ))

    itemlist.append(item.clone(
        action="years",
        label="Años",
        url=HOST,
        type="item",
    ))

    itemlist.append(item.clone(
        action="search",
        label="Buscar",
        query=True,
        type='search',
        content_type='movies',
        category='movie'
    ))

    return itemlist


def generos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = scrapertools.find_single_match(data, r'<ul class="genres scrolling">(.*?)</ul>')

    patron = r'<a href="([^"]+)"[^>]*>([^<]+)</a>'

    for url, title in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            label=title,
            url=url,
            action='movies',
            content_type='movies',
        ))

    return sorted(itemlist, key=lambda x: x.label)


def years(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = scrapertools.find_single_match(data, r'<ul class="releases scrolling">(.*?)</ul>')

    patron = r'<li><a href="([^"]+)">(\d+)</a></li>'

    for url, title in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            label=title,
            url=url,
            action='movies',
            content_type='movies',
        ))

    return sorted(itemlist, key=lambda x: x.label, reverse=True)


def search(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(HOST + '?s=%s' % item.query).data)

    patron = r'<a href="([^"]+)"><img src="([^"]+)" alt="([^"]+)" /><span class="movies">Película </span>.*?' \
             r'<span class="year">(\d+)</span> ((?:<span class="flag" style="background-image: url[^"]+"></span>)+)' \
             r'</div><div class="contenido"><p>([^<]+)'
    for url, poster, title, year, lng, plot in scrapertools.find_multiple_matches(data, patron):
        langs = []
        values = set(scrapertools.find_multiple_matches(lng, r'flags/([^.]+)'))
        for x in values:
            langs.append(LNG.get(x))

        itemlist.append(item.clone(
            title=title,
            year=year,
            poster=poster,
            type='movie',
            action='findvideos',
            plot=plot,
            lang=langs,
            url=url,
            content_type='servers'
        ))

    return itemlist


def movies(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    patron = r'<article id="post-\d+" class="item movies">.*?src="([^"]+)".*?' \
             r'<div class="audio">((?:<div class="idioma" style="[^"]+"></div>)+).*?' \
             r'<span class="quality">([^<]+)</span>.*?<h3><a href="([^"]+)">([^<]+)\s?(\d+)?</a>.*?' \
             r'<div class="texto">([^<]+)'

    for poster, lng, qlt, url, title, year, plot in scrapertools.find_multiple_matches(data, patron):
        langs = []
        if 'HD 1080p' in qlt:
            qlt = 'HD 1080p'
        if 'HD 720p' in qlt:
            qlt = 'HD 720p'
        if 'HDRip' in qlt:
            qlt = 'HDRip'
        values = set(scrapertools.find_multiple_matches(lng, r'mini_icon_([^.]+)'))
        for x in values:
            langs.append(LNG.get(x))

        itemlist.append(item.clone(
            title=title,
            year=year,
            poster=poster,
            type='movie',
            action='findvideos',
            quality=QLT.get(qlt),
            lang=langs,
            url=url,
            plot=plot,
            content_type='servers'
        ))

    # Paginador
    next_page = scrapertools.find_single_match(data, r'<a class=\'arrow_pag\' href="([^"]+)">')
    if next_page:
        itemlist.append(item.clone(type='next', url=next_page))

    return itemlist


def findvideos(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    patron = r"<li id='player-option-\d+' class='dooplay_player_option' data-type='([^']+)' data-post='([^']+)' " \
             r"data-nume='([^'])+'>.*?<span class='title'>([^<]+)</span><span class='server'>([^<]+)</span>"

    for _type, post, nume, lng, server in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            post=post,
            nume=nume,
            post_type=_type,
            type='server',
            server=server.split('.')[0].lower(),
            lang=LNG.get(lng.strip()),
            action='play'
        ))

    return servertools.get_servers_from_id(itemlist)


def play(item):
    logger.trace()

    data = httptools.downloadpage(
        HOST + '/wp-admin/admin-ajax.php',
        post={
            'action': 'doo_player_ajax',
            'post': item.post,
            'nume': item.nume,
            'type': item.post_type
        }
    ).data

    item.url = scrapertools.find_single_match(data, r"src='([^']+)'")

    return servertools.normalize_url(item)
