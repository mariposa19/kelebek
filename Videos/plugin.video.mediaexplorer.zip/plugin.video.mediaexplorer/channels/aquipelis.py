# -*- coding: utf-8 -*-
from core.libs import *

HOST = 'https://www.aquipelis.info'

LNG = Languages({
    Languages.es: ['Castellano'],
    Languages.la: ['Latino'],
    Languages.sub_es: ['Subtitulado']
})

QLT = Qualities({
    Qualities.hd_full: ['DVD', '1080p'],
    Qualities.hd: ['720p', 'HDTV'],
    Qualities.scr: ['TS', 'CAM', 'HD&TS']
})


def mainlist(item):
    logger.trace()
    itemlist = list()

    new_item = item.clone(
        type='label',
        label="Películas",
        category='movie',
        thumb='thumb/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    )
    itemlist.append(new_item)
    itemlist.extend(menupeliculas(new_item))

    new_item = item.clone(
        type='label',
        label="Series",
        category='tvshow',
        thumb='thumb/tvshow.png',
        icon='icon/tvshow.png',
        poster='poster/tvshow.png',
    )
    itemlist.append(new_item)
    itemlist.extend(menuseries(new_item))

    return itemlist


def menupeliculas(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="movies",
        label="Novedades",
        url=HOST + "/peliculas/",
        type="item",
        group=True,
        content_type='movies'))

    itemlist.append(item.clone(
        action="movies",
        label="Español",
        url=HOST + "/idioma/castellano/",
        type="item",
        group=True,
        lang=[Languages.es],
        content_type='movies'))

    itemlist.append(item.clone(
        action="movies",
        label="Latino",
        url=HOST + "/idioma/latino/",
        type="item",
        group=True,
        lang=[Languages.la],
        content_type='movies'))

    itemlist.append(item.clone(
        action="movies",
        label="Subtitulado",
        url=HOST + "/idioma/subtitulado/",
        type="item",
        group=True,
        lang=[Languages.sub_es],
        content_type='movies'))

    itemlist.append(item.clone(
        action="generos",
        label="Géneros",
        url=HOST,
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        action="search",
        label="Buscar",
        query=True,
        type='search',
        group=True,
        content_type='movies'
    ))

    return itemlist


def menuseries(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="tvshows",
        label="Novedades",
        url=HOST + "/series/",
        type="item",
        group=True,
        content_type='tvshows'))

    itemlist.append(item.clone(
        action="tvshows",
        label="Español",
        url=HOST + "/idioma/castellano/",
        type="item",
        group=True,
        lang=[Languages.es],
        content_type='tvshows'))

    itemlist.append(item.clone(
        action="tvshows",
        label="Latino",
        url=HOST + "/idioma/latino/",
        type="item",
        group=True,
        lang=[Languages.la],
        content_type='tvshows'))

    itemlist.append(item.clone(
        action="tvshows",
        label="Sbutitulado",
        url=HOST + "/idioma/subtitulado/",
        type="item",
        group=True,
        lang=[Languages.sub_es],
        content_type='tvshows'))

    itemlist.append(item.clone(
        action="generos",
        label="Géneros",
        url=HOST,
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        action="search",
        label="Buscar",
        query=True,
        type='search',
        group=True,
        content_type='tvshows'
    ))

    return itemlist


def generos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    patron = r'<li><a href="([^"]+/genero/[^"]+)">([^<]+)</a>\s+(\d+)</li>'
    for url, title, cant in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            label=title,
            url=url,
            action='movies' if item.category == 'movie' else 'tvshows',
            content_type='movies' if item.category == 'movie' else 'tvshows',
        ))

    return sorted(itemlist, key=lambda x: x.label)


def search(item):
    logger.trace()

    item.url = HOST + '?s=%s' % item.query

    if item.category == 'movie':
        return movies(item)
    else:
        return tvshows(item)


@LimitResults
def movies(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data

    patron = r'<li class="xxx TPostMv">\s+<article[^>]+>\s+<a href="([^"]+/pelicula/[^"]+)">.*?' \
             r'<span class="Year">([^<]+)</span>.*?' \
             r'src="([^"]+)".*?<h2 class="Title">([^<]+)</h2>.*?<span class="Qlty">[^<]+</span>.*?' \
             r'<div class="Description">\s+<p></p>\s+<p>([^<]+)</p>'

    for url, year, poster, title, plot in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            title=title,
            year=year,
            poster=poster,
            type='movie',
            plot=plot,
            action='findvideos',
            url=url,
            content_type='servers'
        ))

    # Paginador
    next_page = scrapertools.find_single_match(data, r'<a href="([^"]+)" class="next page-numbers">')
    if next_page:
        itemlist.append(item.clone(type='next', url=next_page))

    return itemlist


@LimitResults
def tvshows(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data

    patron = r'<li class="xxx TPostMv">\s+<article[^>]+>\s+<a href="([^"]+/serie/[^"]+)">.*?' \
             r'<span class="Year">([^<]+)</span>.*?' \
             r'src="([^"]+)".*?<h2 class="Title">([^<]+)</h2>.*?<span class="Qlty">[^<]+</span>.*?' \
             r'<div class="Description">\s+<p></p>\s+<p>([^<]+)</p>'

    for url, year, poster, title, plot in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            tvshowtitle=title,
            year=year,
            poster=poster,
            type='tvshow',
            plot=plot,
            action='seasons',
            url=url,
            content_type='seasons'
        ))

    # Paginador
    next_page = scrapertools.find_single_match(data, r'<a href="([^"]+)" class="next page-numbers">')
    if next_page:
        itemlist.append(item.clone(type='next', url=next_page))

    return itemlist


def seasons(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data

    patron = r'<option value="([\d+]+)">([^<]+)</option>'

    for season, label in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            label=label,
            season=int(season),
            type='season',
            action='episodes',
            content_type='episodes'
        ))

    return itemlist


def episodes(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data

    patron = r'<li class="xxx TPostMv">.*?<a href="([^"]+)">.*?<span class="Year">\d+x(\d+)</span>.*?<img src="([^"]+)"'

    for url, episode, thumb in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            title=item.tvshowtitle,
            episode=int(episode),
            type='episode',
            action='findvideos',
            thumb=thumb,
            url=url,
            content_type='servers'
        ))

    return itemlist


def findvideos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    patron = r'<td><a href="([^"]+)".*?class="glyphicon glyphicon-([^"]+).*?td>' \
             r'<img.*?title="([^"]+)".*?<td>([^<">]+)</td>\s+<td>([^<">]+)</td>'

    for url, mode, server, lng, qlt in scrapertools.find_multiple_matches(data, patron):
        if item.lang and LNG.get(lng) not in item.lang:
            continue
        itemlist.append(item.clone(
            url=urllib_parse.urljoin(item.url, url),
            type='server',
            server=server.strip().lower(),
            lang=LNG.get(lng.strip()),
            quality=QLT.get(qlt.strip()),
            referer=item.url,
            stream=mode == 'play',
            action='play'
        ))

    return servertools.get_servers_from_id(itemlist)


def play(item):
    logger.trace()

    data = httptools.downloadpage(item.url, add_referer=True).data

    # Metodo 1:
    if '/enlace/' in item.url:
        _id = scrapertools.find_single_match(data, r'<input name="id" value="([^"]+)" type="hidden" />')
        sitekey = scrapertools.find_single_match(data, r'data-sitekey="([^"]+)"')

        post = {
            'g-recaptcha-response': platformtools.show_recaptcha(item.url, sitekey),
            'id': _id
        }
        url = httptools.downloadpage(
            item.url,
            post=post,
            headers={'Referer': item.referer},
            follow_redirects=False
        ).headers['location']

    # Metodo 2:
    else:
        _id = scrapertools.find_single_match(data, r"player.id='([^']+)'")
        sitekey = scrapertools.find_single_match(data, r'data-sitekey="([^"]+)"')

        post = {
            'token': platformtools.show_recaptcha(item.url, sitekey),
            'id': _id,
            'ajax': 'true'
        }

        url = jsontools.load_json(httptools.downloadpage(
            item.url,
            post=post,
            headers={'Referer': item.referer}
        ).data)['link']

    item.url = url
    return servertools.normalize_url(item)
