import json

from six.moves import http_client, urllib_request
from ..response import HTTPResponse
import six


class HTTPConnection(http_client.HTTPConnection):
    proxy_url = 'https://api.reqbin.com/api/v1/requests'
    proxy_headers = {
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0",
        'Accept': '*/*',
        'Accept-Language': 'es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/json'
    }

    def __init__(self, *args, **kwargs):
        self.proto = kwargs.pop('proto')
        self.proxy_response = None
        self.url = None
        http_client.HTTPConnection.__init__(self, *args, **kwargs)

    def _send_request(self, method, url, body, headers, *_, **__):
        self.url = '%s://%s%s' % (self.proto, headers.pop('Host'), url)

        post = json.dumps({
            "json":
                json.dumps({
                    "method": method,
                    "url": self.url,
                    "content": six.ensure_str(body) or '',
                    "headers": '\n'.join('%s: %s' % (k, v) for k, v in headers.items())
                })
        })

        self.proxy_response = urllib_request.urlopen(
            urllib_request.Request(self.proxy_url, headers=self.proxy_headers),
            six.ensure_binary(post)
        )

    def getresponse(self):
        return HTTPResponse(self)
