from ..base import *

@Js
def console():
    pass

@Js
def log():
    try:
        print(arguments[0])
    except:
        print(repr(arguments[0].value))

console.put('log', log)