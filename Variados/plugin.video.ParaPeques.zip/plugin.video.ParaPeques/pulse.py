# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Sourced From Online Templates And Guides
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Thanks To: Google Search For This Template
# Modified: Pulse
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.ParaPeques'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

xbmc.executebuiltin('Container.SetViewMode(500)')

YOUTUBE_CHANNEL_ID_1 = "PLRmzfJ4Grw0bZ2gWFi2zp0OBYmk8_L7CB"
YOUTUBE_CHANNEL_ID_2 = "PLKXN6nw9Z7HvaN0NjeLtwf0eKwZxfP4ef"
YOUTUBE_CHANNEL_ID_3 = "PLB4E1bdzTS-0q70SQvo8dutaOAyAezHnd"
YOUTUBE_CHANNEL_ID_4 = "PLNq2eaZvd5PumPjmilxrHpS0hrCZJQxZ5"
YOUTUBE_CHANNEL_ID_5 = "PLiNcpyRLD5LsRw7f8CZOnpFjT0nQmsjXQ"
YOUTUBE_CHANNEL_ID_6 = "PL73Iu0Lv3wtQSyfZgVskUU1onHDyoBn0e"
YOUTUBE_CHANNEL_ID_7 = "PLHYjU4m8qoOaVce8BTMVeTRw2uF7zsBJh"
YOUTUBE_CHANNEL_ID_8 = "PLkfv0YNz_eismgkkCMFIQgMGmMu_qQ2h7"
YOUTUBE_CHANNEL_ID_9 = "PLDogFQIY1D4ZqGSvr1OQO1rO1dxvh-Gsz"
YOUTUBE_CHANNEL_ID_10 = "PLkxBepFUPVIsvqrkIHoJormoukxmCxSwq"
YOUTUBE_CHANNEL_ID_12 = "PLemyWmGdwuSPSn4qbS4v3Q9hreVKhSuCG"
YOUTUBE_CHANNEL_ID_13 = "PLwMdVkhuaYw2CgFWTp3jxfi6sr01kpH_f" 
YOUTUBE_CHANNEL_ID_14 = "PLIfm15g-bybp2UJiUfTWhFtIlQknGEZ_t" 
YOUTUBE_CHANNEL_ID_15 = "PL12ooCN94KKzBvLOa-b5FOpUnbMsSvKfi"
YOUTUBE_CHANNEL_ID_16 = "PLQq5fo51vA7SBzQxf00ngw9UaoQ5-k5J0"
YOUTUBE_CHANNEL_ID_17 = "PLuYDaFEnWNZDnxJgWrgUl1Vmrm2ZnHRrW" 
YOUTUBE_CHANNEL_ID_130 = "PLchPNRpVGLgZvtvmbg_xqodPNC7zmHhLQ"
YOUTUBE_CHANNEL_ID_133 = "PLtw1moQvVxOisfVtzlXQy638qLiqm34iw"
YOUTUBE_CHANNEL_ID_138 = "PLww09CxR_lB6HU5eqnvGuulqtkwI8wJmq"
YOUTUBE_CHANNEL_ID_140 = "PLnJX9p9Xo47MA0gg8jCq2k5ywehqLIPdf"
YOUTUBE_CHANNEL_ID_141 = "PLnmlahqxxEQzGYjOVE3bZ2UjMX2w3jjX_"
YOUTUBE_CHANNEL_ID_142 = "PL9A473A74B833BB3E"
# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))
	
    plugintools.add_item( 
        #action="", 
        title="Canta Juegos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://i.imgur.com/ruFEJtM.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Playmobil",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_140+"/",
        thumbnail="https://i.imgur.com/bL7pnh4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Barrio Sesamo",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_138+"/",
        thumbnail="https://i.imgur.com/yYgF0ek.jpg",
        folder=True )
	

    plugintools.add_item( 
        #action="", 
        title="Mundo Pin y Pon",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_133+"/",
        thumbnail="https://i.imgur.com/TWIjfE2.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Educativos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_130+"/",
        thumbnail="https://i.imgur.com/E80XVuT.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Patrulla Canina",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="https://i.imgur.com/Ay5Vp1b.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Dibujos Animados",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://i.imgur.com/swiL1Bh.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Caillou",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="https://i.imgur.com/XyIcChc.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Poco Yo",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="https://i.imgur.com/6uZ2K8t.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Manualidades para peques",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="https://i.imgur.com/I9A9cfS.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Peppa Pig",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://i.imgur.com/aQZQrUP.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Disney",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="https://i.imgur.com/Nf2Dmlx.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Cocina para Niños",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_141+"/",
        thumbnail="https://i.imgur.com/btlJ9wo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Reciclamos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="https://i.imgur.com/qv5J7Eb.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Los Fraguel",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://i.imgur.com/SeBQID9.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Aprende Ingles",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="https://i.imgur.com/ef8CQoy.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="A Bailar Peque",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="https://i.imgur.com/Y1aBG3t.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Adornos Navidad",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="https://i.imgur.com/d8q9FWD.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Karaoke",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="https://i.imgur.com/8abDUzf.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Zootopia",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="https://i.imgur.com/SEdUNmc.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Juguetes",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="https://i.imgur.com/7uPNMRM.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Los Cuentos de Minie",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_142+"/",
        thumbnail="https://i.imgur.com/nkqQUOa.jpg",
        folder=True )

run()