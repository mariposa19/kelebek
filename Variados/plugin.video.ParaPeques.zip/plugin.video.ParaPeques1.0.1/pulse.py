# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Sourced From Online Templates And Guides
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Thanks To: Google Search For This Template
# Modified: Pulse
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.ParaPeques'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

xbmc.executebuiltin('Container.SetViewMode(500)')

YOUTUBE_CHANNEL_ID_1 = "PLRmzfJ4Grw0bZ2gWFi2zp0OBYmk8_L7CB"
YOUTUBE_CHANNEL_ID_2 = "PLKXN6nw9Z7HvaN0NjeLtwf0eKwZxfP4ef"
YOUTUBE_CHANNEL_ID_3 = "PLB4E1bdzTS-0q70SQvo8dutaOAyAezHnd"
YOUTUBE_CHANNEL_ID_4 = "PLNq2eaZvd5PumPjmilxrHpS0hrCZJQxZ5"
YOUTUBE_CHANNEL_ID_5 = "PLiNcpyRLD5LsRw7f8CZOnpFjT0nQmsjXQ"
YOUTUBE_CHANNEL_ID_6 = "PL73Iu0Lv3wtQSyfZgVskUU1onHDyoBn0e"
YOUTUBE_CHANNEL_ID_7 = "PLHYjU4m8qoOaVce8BTMVeTRw2uF7zsBJh"
YOUTUBE_CHANNEL_ID_8 = "PLkfv0YNz_eismgkkCMFIQgMGmMu_qQ2h7"
YOUTUBE_CHANNEL_ID_9 = "PLDogFQIY1D4ZqGSvr1OQO1rO1dxvh-Gsz"
YOUTUBE_CHANNEL_ID_10 = "PLkxBepFUPVIsvqrkIHoJormoukxmCxSwq"
YOUTUBE_CHANNEL_ID_11 = "PLemyWmGdwuSPSn4qbS4v3Q9hreVKhSuCG"
YOUTUBE_CHANNEL_ID_12 = "PLwMdVkhuaYw2CgFWTp3jxfi6sr01kpH_f" 
YOUTUBE_CHANNEL_ID_13 = "PLIfm15g-bybp2UJiUfTWhFtIlQknGEZ_t" 
YOUTUBE_CHANNEL_ID_14 = "PLVbsijrFzerkdhSIcNzXpmsKWi0iMn7e5"
YOUTUBE_CHANNEL_ID_15 = "PLQq5fo51vA7SBzQxf00ngw9UaoQ5-k5J0"
YOUTUBE_CHANNEL_ID_16 = "PLuYDaFEnWNZDnxJgWrgUl1Vmrm2ZnHRrW" 
YOUTUBE_CHANNEL_ID_17 = "PLchPNRpVGLgZvtvmbg_xqodPNC7zmHhLQ"
YOUTUBE_CHANNEL_ID_18 = "PLtw1moQvVxOisfVtzlXQy638qLiqm34iw"
YOUTUBE_CHANNEL_ID_19 = "PLww09CxR_lB6HU5eqnvGuulqtkwI8wJmq"
YOUTUBE_CHANNEL_ID_20 = "PLnJX9p9Xo47MA0gg8jCq2k5ywehqLIPdf"
YOUTUBE_CHANNEL_ID_21 = "PLnmlahqxxEQzGYjOVE3bZ2UjMX2w3jjX_"
YOUTUBE_CHANNEL_ID_22 = "PL9A473A74B833BB3E"
YOUTUBE_CHANNEL_ID_23 = "PL9rE6bq_Luyyl2s76A4QTKgyPF-8U7Pan"
YOUTUBE_CHANNEL_ID_24 = "PLUuRJYptYFXBmaLE1oNJYPxyl-3mSLKL3"
YOUTUBE_CHANNEL_ID_25 = "PLutxf9xWvQKa0-ZMI5fyFSeABblPOF3Kk"
YOUTUBE_CHANNEL_ID_26 = "PL3rWuW8jgIQNTFfHzQOFAmKOWfyv3jIU4"
YOUTUBE_CHANNEL_ID_27 = "PLvyDCUr4HHt3z-6NjZB1Gx-fnvRVn0_E0"
YOUTUBE_CHANNEL_ID_28 = "PLKXN6nw9Z7HstOVIA68ZjmvZSQoE3vjG5"
YOUTUBE_CHANNEL_ID_29 = "PLkQH3mZohooAXHCjfkEAr_L8sITEbnyRX"
YOUTUBE_CHANNEL_ID_30 = "PLjxOg4YY7Ah2JGb_QvA6KSB6YmikzA2fo"
YOUTUBE_CHANNEL_ID_31 = "PLPBylKJy18Us88S092hTxluHkU4PrwgpM"
YOUTUBE_CHANNEL_ID_32 = "PL2QrQSTMbPE1a8Rto67D_1lUKaxn1mm6X"
# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))
	
    plugintools.add_item( 
        #action="", 
        title="Canta Juegos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://i.imgur.com/ruFEJtM.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Playmobil",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_20+"/",
        thumbnail="https://i.imgur.com/bL7pnh4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Barrio Sesamo",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_19+"/",
        thumbnail="https://i.imgur.com/yYgF0ek.jpg",
        folder=True )
	

    plugintools.add_item( 
        #action="", 
        title="Mundo Pin y Pon",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_18+"/",
        thumbnail="https://i.imgur.com/TWIjfE2.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Educativos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="https://i.imgur.com/E80XVuT.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Patrulla Canina",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="https://i.imgur.com/Ay5Vp1b.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Dibujos Animados",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://i.imgur.com/swiL1Bh.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Caillou",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="https://i.imgur.com/XyIcChc.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Poco Yo",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="https://i.imgur.com/6uZ2K8t.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Manualidades para peques",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="https://i.imgur.com/I9A9cfS.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Peppa Pig",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://i.imgur.com/aQZQrUP.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Popeye",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="https://i.imgur.com/wi4JIab.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Cocina para Niños",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_21+"/",
        thumbnail="https://i.imgur.com/btlJ9wo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Reciclamos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="https://i.imgur.com/qv5J7Eb.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Los Fraguel",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://i.imgur.com/SeBQID9.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Aprende Ingles",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="https://i.imgur.com/ef8CQoy.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="A Bailar Peque",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="https://i.imgur.com/Y1aBG3t.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Adornos Navidad",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="https://i.imgur.com/d8q9FWD.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Karaoke",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="https://i.imgur.com/8abDUzf.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Zootopia",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="https://i.imgur.com/SEdUNmc.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Juguetes",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="https://i.imgur.com/7uPNMRM.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Los Cuentos de Minie",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_22+"/",
        thumbnail="https://i.imgur.com/nkqQUOa.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Tarta de fresa",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_23+"/",
        thumbnail="https://i.imgur.com/QcRc3Wv.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Heidi",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_24+"/",
        thumbnail="https://i.imgur.com/vaIOnWZ.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Marco",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_25+"/",
        thumbnail="https://i.imgur.com/U5QS24P.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Los Baby Muppets",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_26+"/",
        thumbnail="https://i.imgur.com/FFqjmj0.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Vicky El Vikingo",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_27+"/",
        thumbnail="https://i.imgur.com/G1nvSX9.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Campeones Oliver y Benji",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_28+"/",
        thumbnail="https://i.imgur.com/RQMQyfb.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Las Aventuras de Tintin",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_29+"/",
        thumbnail="https://i.imgur.com/WUC9U8z.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Rin Tin Tin",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_30+"/",
        thumbnail="https://i.imgur.com/vn5IXzf.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="El Pajaro Loco",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_31+"/",
        thumbnail="https://i.imgur.com/5hboEJ3.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Pippi Calzas Largas",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_32+"/",
        thumbnail="https://i.imgur.com/VdvQwUB.jpg",
        folder=True )
		
run()