# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Thanks to the Authors of the base code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# modified by: MUSICHALL
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.KinderLand'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_playlist_ID_1 = "PLRmzfJ4Grw0bZ2gWFi2zp0OBYmk8_L7CB"
YOUTUBE_playlist_ID_2 = "PLKXN6nw9Z7HvaN0NjeLtwf0eKwZxfP4ef"
YOUTUBE_playlist_ID_3 = "PLB4E1bdzTS-0q70SQvo8dutaOAyAezHnd"
YOUTUBE_playlist_ID_4 = "PLNq2eaZvd5PumPjmilxrHpS0hrCZJQxZ5"
YOUTUBE_playlist_ID_5 = "PLiNcpyRLD5LsRw7f8CZOnpFjT0nQmsjXQ"
YOUTUBE_playlist_ID_6 = "PL73Iu0Lv3wtQSyfZgVskUU1onHDyoBn0e"
YOUTUBE_playlist_ID_7 = "PLHYjU4m8qoOaVce8BTMVeTRw2uF7zsBJh"
YOUTUBE_playlist_ID_8 = "PLkfv0YNz_eismgkkCMFIQgMGmMu_qQ2h7"
YOUTUBE_playlist_ID_9 = "PLDogFQIY1D4ZqGSvr1OQO1rO1dxvh-Gsz"
YOUTUBE_playlist_ID_10 = "PLkxBepFUPVIsvqrkIHoJormoukxmCxSwq"
YOUTUBE_playlist_ID_11 = "PLemyWmGdwuSPSn4qbS4v3Q9hreVKhSuCG"
YOUTUBE_playlist_ID_12 = "PLwMdVkhuaYw2CgFWTp3jxfi6sr01kpH_f" 
YOUTUBE_playlist_ID_13 = "PLIfm15g-bybp2UJiUfTWhFtIlQknGEZ_t" 
YOUTUBE_playlist_ID_14 = "PLVbsijrFzerkdhSIcNzXpmsKWi0iMn7e5"
YOUTUBE_playlist_ID_15 = "PLSvaOCskKpXAwzbt2ri6ntxn_4Jv3kU8X"
YOUTUBE_playlist_ID_16 = "PLuYDaFEnWNZDnxJgWrgUl1Vmrm2ZnHRrW" 
YOUTUBE_playlist_ID_17 = "PLchPNRpVGLgZvtvmbg_xqodPNC7zmHhLQ"
YOUTUBE_playlist_ID_18 = "PLtw1moQvVxOisfVtzlXQy638qLiqm34iw"
YOUTUBE_playlist_ID_19 = "PLww09CxR_lB6HU5eqnvGuulqtkwI8wJmq"
YOUTUBE_playlist_ID_20 = "PLnJX9p9Xo47MA0gg8jCq2k5ywehqLIPdf"
YOUTUBE_playlist_ID_21 = "PLnmlahqxxEQzGYjOVE3bZ2UjMX2w3jjX_"
YOUTUBE_playlist_ID_22 = "PL9A473A74B833BB3E"
YOUTUBE_playlist_ID_23 = "PL9rE6bq_Luyyl2s76A4QTKgyPF-8U7Pan"
YOUTUBE_playlist_ID_24 = "PLUuRJYptYFXBmaLE1oNJYPxyl-3mSLKL3"
YOUTUBE_playlist_ID_25 = "PLutxf9xWvQKa0-ZMI5fyFSeABblPOF3Kk"
YOUTUBE_playlist_ID_26 = "PL3rWuW8jgIQNTFfHzQOFAmKOWfyv3jIU4"
YOUTUBE_playlist_ID_27 = "PLvyDCUr4HHt3z-6NjZB1Gx-fnvRVn0_E0"
YOUTUBE_playlist_ID_28 = "PLKXN6nw9Z7HstOVIA68ZjmvZSQoE3vjG5"
YOUTUBE_playlist_ID_29 = "PLkQH3mZohooAXHCjfkEAr_L8sITEbnyRX"
YOUTUBE_playlist_ID_30 = "PLEcBOvMZqbCGHlZgYNzpyDgImDuK8pCc3"
YOUTUBE_playlist_ID_31 = "PLPBylKJy18Us88S092hTxluHkU4PrwgpM"
YOUTUBE_playlist_ID_32 = "PL2QrQSTMbPE1a8Rto67D_1lUKaxn1mm6X"
YOUTUBE_playlist_ID_33 = "PLKXN6nw9Z7HviOy57S70Ito6QOaINzpgb"
YOUTUBE_playlist_ID_34 = "PLpSWLIHTG6ifGirFHPCUzX2K1C3kPJr4L"
YOUTUBE_playlist_ID_35 = "PLVtH1q_l8JQO4QjptPQTIigHUg82umewx"
YOUTUBE_playlist_ID_36 = "PL-NWsVkG3lN3bdO5uRhA5tjO4cX2HXHTE"
YOUTUBE_playlist_ID_37 = "PLKXN6nw9Z7HtaxzxDtF56Q_L3ZLBQvOd0"
YOUTUBE_playlist_ID_38 = "PLynb7MteT3bv-JXyQJFD0dgMX1p-kbTyw"
YOUTUBE_playlist_ID_39 = "PL08EcHdANEaXICpcYT9H1ZZgdFQqHEgOX"
YOUTUBE_playlist_ID_40 = "PLKXN6nw9Z7HtEQccUv2UALNJJ48jaF3ip"
YOUTUBE_playlist_ID_41 = "PLKXN6nw9Z7HtuWk78WiiQ9sBgEg3G4Aev"
YOUTUBE_playlist_ID_42 = "PLKXN6nw9Z7HssnZcHSSoNFuqI0kQsKXZk"
YOUTUBE_playlist_ID_43 = "PLBy6KvkIQY399CqUbLe6eTb5Y22FWMfHI"
YOUTUBE_playlist_ID_44 = "PLKXN6nw9Z7HsS0DPmeZNxe5TaAHDXdgwE"
YOUTUBE_playlist_ID_45 = "PLKXN6nw9Z7HtkixOu0nUU1Du3gEUyOlMf"
YOUTUBE_playlist_ID_46 = "PLKXN6nw9Z7HtKePP7N2nB2DszyF6hxZl4"
YOUTUBE_playlist_ID_47 = "PLKXN6nw9Z7HsvyRwyQhJBJiP2GeZakrso"
YOUTUBE_playlist_ID_48 = "PLKXN6nw9Z7HtvW_nxIw5IZFEg49Mknr21"
YOUTUBE_playlist_ID_49 = "PLKXN6nw9Z7HsUHYS3j_Pz6avbp4kXLECy"
YOUTUBE_playlist_ID_50 = "PLfH8EZSX2vobnR5Oc5OdhYzzpwDB5D6iH"
YOUTUBE_playlist_ID_51 = "PLHyALu4MRWqNgD-oD3HeXFhR6f0U0V1Rp"
YOUTUBE_playlist_ID_52 = "PLKXN6nw9Z7Hv8QjgB3szcgP_PLETSQ9I4"
YOUTUBE_playlist_ID_53 = "PLKXN6nw9Z7HtWLzlIzPV3tZo1vbVQeppO"
YOUTUBE_playlist_ID_54 = "PLpCM_wuG1SiDaF_ra2M7Ygudx55-jTP8j"
YOUTUBE_playlist_ID_55 = "PLUmLp8QGk1vChuwtjcYmkGOciHMD6Ahj6"
YOUTUBE_playlist_ID_56 = "PLoLuTO-srY1gFdzCO3Is53ZvVUV6HN9e-"
YOUTUBE_playlist_ID_57 = "PLe4ZuWFax2d82L388D4BDFsS5fvuQpzu-"
YOUTUBE_playlist_ID_58 = "PLKXN6nw9Z7HuhYBgbkhFswHJq0Vb6W-39"
YOUTUBE_playlist_ID_59 = "PLKXN6nw9Z7HuccOOslRqe9JrxQRrRFq7D"
YOUTUBE_playlist_ID_60 = "PLKXN6nw9Z7Hv9GVkaSijS175SzaumdgTg"
YOUTUBE_playlist_ID_61 = "PLM3zaEIjzXIX0lfjtdMiflymrv2tzS1ph"
YOUTUBE_playlist_ID_62 = "PLvmFTGTOxh9OrRZpv-GQhb_bwYTcobJDE"
YOUTUBE_playlist_ID_63 = "PLKXN6nw9Z7HsDrXtg3uKdqc8IclKslcCz"
YOUTUBE_playlist_ID_64 = "PLKXN6nw9Z7Hv3jXKsQqa1A27bWWAW8iG6"
YOUTUBE_playlist_ID_65 = "PLKXN6nw9Z7Hs4-BXD7AKjKx97EdtgAnPe"
YOUTUBE_playlist_ID_66 = "PLKXN6nw9Z7HuJznz-IKImOFhTtH3Xs84T"
YOUTUBE_playlist_ID_67 = "PLtIxg922avyKnoP01fe_KJGvoYLRqdlGG"
YOUTUBE_playlist_ID_68 = "PLbNOclD9qRWnTLTx0WyhB-wcwqo6Tbcv1"
YOUTUBE_playlist_ID_69 = "PLKXN6nw9Z7HvCi0ug6Lc79G3AMgS3r4mx"
YOUTUBE_playlist_ID_70 = "PLdNk6FKMo-YXzQZmgWCHQMbcbnie07X_m"
YOUTUBE_playlist_ID_71 = "PLJ5vn2xlGQnNeBnc53Do3tS85A2akrfWL"
YOUTUBE_playlist_ID_72 = "PLn_efX3kt9f_E8_HSsFNgLBYFhPQ5UylS"
YOUTUBE_playlist_ID_73 = "PL2F58ACE889F9EFE6"
YOUTUBE_playlist_ID_74 = "PLjXyTw1_uY7NKDZdfdmHQNqLfKvVccru4"
YOUTUBE_playlist_ID_75 = "PLHIVSRNAg7clrI3hDrPhvUe4Z7Y6u8O_G"
YOUTUBE_playlist_ID_76 = "PLKXN6nw9Z7Hu4L3KpnWM6TefxSZZ5bemJ"
YOUTUBE_playlist_ID_77 = "PL_talHzUi3vIK18QL4dLVCz97dN4RuHfU"
YOUTUBE_playlist_ID_78 = "PL8WfiHeijGLCozCvOaGFxy55WDBA8b2vf"
YOUTUBE_playlist_ID_79 = "PLx4Gqi_X0riBP0VbGk_qThpBscEXqzZqj"
YOUTUBE_playlist_ID_80 = "PLKXN6nw9Z7HtqFjXzIO1P2h2l98Xz6HQd"
YOUTUBE_playlist_ID_81 = "PLOy6Pyub2zig09F9FLMHb1mp1mex7sITh"
YOUTUBE_playlist_ID_82 = "PL0pbu2h9LmWEO9oIMSuUm7PVt4HcnYYvU"
YOUTUBE_playlist_ID_83 = "PLk8MuEC6Nz4Xxy0SSV1W3fi1rKMes58N-"
YOUTUBE_playlist_ID_84 = "PLWMYMD0Gnd9SuTMdm2VrryMAuNpUj1gOU"
YOUTUBE_playlist_ID_85 = "PL8snGkhBF7njuEl8V642ZeFwcbVRRPFLG"
YOUTUBE_playlist_ID_86 = "PL8snGkhBF7ngDp1oJtx5VcjwatxZn8xLK"
YOUTUBE_playlist_ID_87 = "PLusSrZ-7Aiev0uxn3c7KcoH9msKrXkJW7"
YOUTUBE_playlist_ID_88 = "PL028565C616627F50"
YOUTUBE_playlist_ID_89 = "PLusSrZ-7AievwZv-Zc56vIAb-BxZeYDyC"
YOUTUBE_playlist_ID_90 = "PLJK5wpK1UKMazQEWVvZ1IoYUlsnqpTiii"
YOUTUBE_playlist_ID_91 = "PLWYQuS6aEMRDcHza5LQjPbRkrwu2qt6DT"
YOUTUBE_playlist_ID_92 = "PLta2xE-Usvl-ua1eEk9XnDW1ajvBpZ1f1"
YOUTUBE_playlist_ID_93 = "PLDUvSiwQy5cEx31-XjBJCfcU1K9Lox79L"
YOUTUBE_playlist_ID_94 = "PLusSrZ-7AiesCVcITlK7S6eEh2bnx52n6"
YOUTUBE_playlist_ID_95 = "PL5tb2ODzv2rSWKrSeZwtZrPgvekFyU33P"
YOUTUBE_playlist_ID_96 = "PL8snGkhBF7njO0QvtE97AJFL3xZYQSGh5"
YOUTUBE_playlist_ID_97 = "PLDUvSiwQy5cEklxOj93LMaoqyjtoTr05t"
YOUTUBE_playlist_ID_98 = "PLJK3tljUgjzI0EVB9IGOWT4Uhiz_f7HsT"
YOUTUBE_playlist_ID_99 = "PL8snGkhBF7nhEc52y4C1S9yqjBQSLCmT4"
YOUTUBE_playlist_ID_100 = "PL_o8kq_GWfOlkFJ7ugSjRQ_soFhluWbB_"
YOUTUBE_playlist_ID_101 = "PL_o8kq_GWfOkin4jcvYdUTSP0x2XED8ll"
YOUTUBE_playlist_ID_102 = "PLuff7HnBIm5V0ty1LNEQBoI9x34UpC4iF"
YOUTUBE_playlist_ID_103 = "PLgK76qegaoMzghYeQ5xMyZK9bdFfMKvdd"
YOUTUBE_playlist_ID_104 = "PLD-2f-nig1ajeEuckkeJOxyp2MctiVQcC"
YOUTUBE_playlist_ID_105 = "PLD-2f-nig1ajD9pjWU-zpnAkudHqphTsE"
YOUTUBE_playlist_ID_106 = "PL3BEF4668E8568186"
YOUTUBE_playlist_ID_107 = "PLF457B8EA1B3039DB"
YOUTUBE_playlist_ID_108 = "PLD-2f-nig1ajk15N3oKyMA9qrZirbjhzF"
YOUTUBE_playlist_ID_109 = "PLeY6ZuXvnilX9p_XwmFsYbZm12IeEPF1E"
YOUTUBE_playlist_ID_110 = "PLeY6ZuXvnilUOmxS5s_JmtBjeOrjp7nRg"
YOUTUBE_playlist_ID_111 = "PLSyxqIHOw0ZMMjw741Pqn494SalYHVRMv"
YOUTUBE_playlist_ID_112 = "PL2KQv6-I8MwDq2uKQujePX9XuKPCR3svY"
YOUTUBE_playlist_ID_113 = "PL_Y3qbepMRobmH0XmoZ3OL8WDDbuxM3px"
YOUTUBE_playlist_ID_114 = "PLguZfwIrWHOZl5zCA8P4xNjFUMw4OjRHI"
YOUTUBE_playlist_ID_115 = "PLguZfwIrWHOZnMgmt32VOetq3a_cSr7zs"
YOUTUBE_playlist_ID_116 = "PLfVDJFxsvnTRdnn11-X_B8NvO4Lcn3uNG"
YOUTUBE_playlist_ID_117 = "PLfVDJFxsvnTRi2fuVBjMK2RDhEbi9hFjJ"
YOUTUBE_playlist_ID_118 = "PLfVDJFxsvnTRT0VbCB4wdIXUoQdFCKS3W"
YOUTUBE_playlist_ID_119 = "PLLv3wr6Ka51_NVOBLppPYg5i2T2hUoDiy"
YOUTUBE_playlist_ID_120 = "PLl3ShNbWJXFBniubEJIefEswXiL5IP-f4"
YOUTUBE_playlist_ID_121 = "PLEFC1282E4331AC14"
YOUTUBE_playlist_ID_122 = "PLgjievpwkFDJ9kbCrWAsO_SwxBkWTDNaV"
YOUTUBE_playlist_ID_123 = "PLMeWlmsH8nbGVodj5zw-fsUoU8SaA54Vk"
YOUTUBE_playlist_ID_124 = "PLz9jduKZZp17NLTiptvJ5tqfiJTTeUMvA"
YOUTUBE_playlist_ID_125 = "PL0yRdLLwg9gq1Yycy6Pv3lwzO2sGiup-5"
YOUTUBE_playlist_ID_126 = "PLi6wag8FdvTCGXRSWK7rHw-mmHBeiGW0U"
YOUTUBE_playlist_ID_127 = "PLslpKpQmman7xcUdLadsWuj0ve4dv5sS_"
YOUTUBE_playlist_ID_128 = "PLR6vyZ1nBsHReWClo7s2F9f6cB_GcTiqv"
YOUTUBE_playlist_ID_129 = "PL3oAQyb9tbOccBDyYn9RLy-esks6i-EQU"
YOUTUBE_playlist_ID_130 = "PLWCM1QJKbFLpT73U9zbj2Ys7mOV_3wnPA"
YOUTUBE_playlist_ID_131 = "PLP7X5ycpylZiDWKqRorRJKDdUh73PzFsm"
YOUTUBE_playlist_ID_132 = "PLA7cuYLKfPXTbOa4tPuVCPEDyXbroACJ2"
YOUTUBE_playlist_ID_133 = "PLKXN6nw9Z7HuJcT7VTHYTsPMlfCxyN67s"
YOUTUBE_playlist_ID_134 = "PLcx_TDPjWGai9JlLBLPjMLQ21P8xhOIxm"
YOUTUBE_playlist_ID_135 = "PL_Z_xDpQRmANyf3RsW0Z5Uy-FhdT3yca9"
YOUTUBE_playlist_ID_136 = "PLidbREU52rbfSxbiW0bvWmK-9_0-VmuAM"
YOUTUBE_playlist_ID_137 = "PL1flQe3LmzxnT4zBwwCSnzJhZCYTzTyqa"
YOUTUBE_playlist_ID_138 = "PLCF4P0UGv7KSEuRBVSboEXSl2syLUIfDS"
YOUTUBE_playlist_ID_139 = "PLKXN6nw9Z7HvyXsGf3t_8-WriklrFSYPv"
YOUTUBE_playlist_ID_140 = "PLnb4OlLvQaoNHrdsFBi9yKkztvaWjbiXM"
YOUTUBE_playlist_ID_141 = "PLpSWLIHTG6idwDXwIm-7eaCpauPBw0vGf"
YOUTUBE_playlist_ID_142 = "PLHyALu4MRWqPfYupZurrRsxlnNk8H4Bpu"
YOUTUBE_playlist_ID_143 = "PLR6-4WNns-3ePydnoZTGb-uxmWfB4YAWk"
YOUTUBE_playlist_ID_144 = "PLZ4POPAfakSGuNfFkFX3SvkrkOHVfDXNt"
YOUTUBE_playlist_ID_145 = "PLX_HAQc4rwsTCYeF_BUEM6fW6PRtQJoJs"
YOUTUBE_playlist_ID_146 = "PLKXN6nw9Z7HvUXtDe7Qf8OalvSjhAo772"
YOUTUBE_playlist_ID_147 = "PLNZOXjS7YP3VPHtavlxFXNjsX-xMfEH2p"
YOUTUBE_playlist_ID_148 = "PLvnle_quUJpjoLZEA98U1oAFGPcmekgNy"
YOUTUBE_playlist_ID_149 = "PLZ4POPAfakSFHusVG6FvI23LZu2J1cmUN"
YOUTUBE_playlist_ID_150 = "PLBy6KvkIQY38_sZNfA-NOp6uvWmmlADFz" 
YOUTUBE_playlist_ID_151 = "PLpSWLIHTG6idKFhxc3tP14r04ZMNyrl47"
YOUTUBE_playlist_ID_152 = "PL3trIOgZnbH04E4QCF8IbhmJmKmxrftX6"
YOUTUBE_playlist_ID_153 = "PLMv_f2t3KUoILdnCrprpcvssaXo4WNUzN"
YOUTUBE_playlist_ID_154 = "PL8-cgO2m6U-aV_P2IbyIZ3ccn6dMpq8f4"
YOUTUBE_playlist_ID_155 = "PLl1AauqlvQeBFukFKVpKNdWKXMMNzaluI"
YOUTUBE_playlist_ID_156 = "PLKXN6nw9Z7HsQyL3wOcwynYesKvyjem66"
YOUTUBE_playlist_ID_157 = "PL-uGaJFiLrolL_cMG3cJ1zk_T7eD-tuBp"
YOUTUBE_playlist_ID_158 = "PLA9eXd_slhPX4W-BWH9-vB0cIhBmMLuXq"
YOUTUBE_playlist_ID_159 = "PLKXN6nw9Z7Hu98NqO4lc8BZK9YJR5Cdr_"
YOUTUBE_playlist_ID_160 = "PLKXN6nw9Z7HuiMiqSzjCRLWxNv2D0WYku"
YOUTUBE_playlist_ID_161 = "PL1549393B701946BF"
YOUTUBE_playlist_ID_162 = "PLHfWUw8p_6283AICclYKYj-8XhHCuWOiA"
YOUTUBE_playlist_ID_163 = "PLr1gm1Or_cIDHHDwMrin857LFEyxCCr1N"
YOUTUBE_playlist_ID_164 = "PL0DEA3AE468DFB199"
YOUTUBE_playlist_ID_165 = "PLKXN6nw9Z7HtMAmMK9cYX0QYKKUus4W9V"
YOUTUBE_playlist_ID_166 = "PLKXN6nw9Z7HsrBbpdc_X4Uiaj_UCOJFyR"
YOUTUBE_playlist_ID_167 = "PLLmqHO944DZesPoo554QoC4J2eLh9qVfi"
YOUTUBE_playlist_ID_168 = "PL20QG-d3w2I5410t9pGSywmsCjCc6zapu"
YOUTUBE_playlist_ID_169 = "PLKXN6nw9Z7Ht6xNt6I38x_pjmDPIILszN"
YOUTUBE_playlist_ID_170 = "PLZJRFF3JnesMFEzIM7tyVKl3Cq17vE1rX"
YOUTUBE_playlist_ID_171 = "PLD6FF365C3548835D"
YOUTUBE_playlist_ID_172 = "PL9jJPHcj9quJu-IEw9IPINAQ0HTXbwV7B"
YOUTUBE_playlist_ID_173 = "PLqv7RatywjZFRURSFXg77wU5ciezO0eEN"
YOUTUBE_playlist_ID_174 = "PLTvUhM9o-6QMbOv47C1ccj8FqxgAWCFlI"
YOUTUBE_playlist_ID_175 = "PLzC1OLBfeNd1zXi6S4KjcvH-54wVUYF5c"
YOUTUBE_playlist_ID_176 = "PL-fepVzZwm6dutxBaXS_MJr-rQdSnrGDW"
YOUTUBE_playlist_ID_177 = "PL1812714DE488ECFC"
YOUTUBE_playlist_ID_178 = "PLJBalyWeYN835C6L9GKFJiCHJLUaTzc9P"
YOUTUBE_playlist_ID_179 = "PLoRxusm_agvHo1dApFLNOB6mJA63meKmL"
YOUTUBE_playlist_ID_180 = "PLjUZzWE_QWpnkui_PbLEUBPKufrE3ls7C"
YOUTUBE_playlist_ID_181 = "PLByskZSXZTMSalMD-GVAbz6hsmLhvZxho"
YOUTUBE_playlist_ID_182 = "PLQh3fzvq6wdx7s4H4uQ2JMfd6RCcp1_qn"
YOUTUBE_playlist_ID_183 = "PLKXN6nw9Z7Hsgt6C0Q458Z0PJm8FJYC-E"
YOUTUBE_playlist_ID_184 = "PLYrH1Rtzk9Ek2l8xIXJNsRhYEvzTakovd"
YOUTUBE_playlist_ID_185 = "PL43AA48CF4886CA6B"
YOUTUBE_playlist_ID_186 = "PLwSb6vqkP17DnPHcnjCM66IWLC2Eh8zTu"
YOUTUBE_playlist_ID_187 = "PLkkP3ubkwCi10MC1RpQHHxfzawhjwK_h3"
YOUTUBE_playlist_ID_188 = "PLb2UVrNDH7nfbfW6pncw7TIlDQwnDEFtg"
YOUTUBE_playlist_ID_189 = "PLZ9vJ4WHO8bXG6Z-sc84vvQVvB-ExklU-"
YOUTUBE_playlist_ID_190 = "PLG1lDDjNSFCdY7nGVJWD1zJFBpl7guaB3"
YOUTUBE_playlist_ID_191 = "PLHr42J3X9GxzTFYFiMDvYpqoHaGMw13OS"
YOUTUBE_playlist_ID_192 = "PLWUw1rjNeUtdPUNIHRkr-b4hczFTG4eAu"
YOUTUBE_playlist_ID_193 = "PLnNHbQQjTyhzq4ulFQuy9RX1dNCwCZZXh"
YOUTUBE_playlist_ID_194 = "PLHNvfrPC4hTuBYpDmw-nZMk-BxofC67Oj"
YOUTUBE_playlist_ID_195 = "PLSspY6TXFNPSsz3BA3BBw2Vu5wMIlknWb"
YOUTUBE_playlist_ID_196 = "PLrBG9aSh5RADbcCb-SaDkSPLpbmw_wBJQ"
YOUTUBE_playlist_ID_197 = "PLv2qsjtHOeiJBKcifo4mv2h5ajWrIa05R"
YOUTUBE_playlist_ID_198 = "PLylO5ejGS8ADh-ZiOUADjjtJ7l-Tlw1rW"
YOUTUBE_playlist_ID_199 = "PLSXT4sOipmuzTRcwmOkBdOwcUcCWpaoWi"
YOUTUBE_playlist_ID_200 = "PL163EA7955E070E62"
YOUTUBE_playlist_ID_201 = "PLHfWUw8p_62-wG0umEJdsONHKDacHY-gH"
YOUTUBE_playlist_ID_202 = "PLpSWLIHTG6idAf7gkOl7N92WnKu3iZqnt"
YOUTUBE_playlist_ID_203 = "PLY6rx7MsoITQFTzH1sQXdvbL2cUzHmYk3"
YOUTUBE_playlist_ID_204 = "PLVMR9Xg6y7qXrNJ1K4THIa44MjEQqbABy"
YOUTUBE_playlist_ID_205 = "PLOSv103PytYnLOo2JA59UusGbDrFM9Kg4"
YOUTUBE_playlist_ID_206 = "PLG_nGpEe-ixTbwtnD8AC5WH8xsaVACQpn"
YOUTUBE_playlist_ID_207 = "PLHaDHOEwrPcLu6s8_zm7sCPyXkgKFsQDy"
YOUTUBE_playlist_ID_208 = "PLxDEOOKKs4aOU7dPdJA6YZG95Y0P20htN"
YOUTUBE_playlist_ID_209 = "PL_ZpvsSrmdxq5wSPQH1PzRpT9i47hlCms"
YOUTUBE_playlist_ID_210 = "PLjU-M0Ww-bmoBJReLDBSk0aYFPtR_Ty6J"
YOUTUBE_playlist_ID_211 = "PLZk4VHxJSkj7aeEyxwY6TDCbe6AppJ0V_"
YOUTUBE_playlist_ID_212 = "PLokd7WSP5pp56ChjHoc-Nto-hpA2Fad_v"
YOUTUBE_playlist_ID_213 = "PLUf5g8_ANjJsUzCIp639OCs6EO0wB4Rtu"
YOUTUBE_playlist_ID_214 = "PLKXN6nw9Z7HvpS39bvfATK6MnJsEtozXG"
YOUTUBE_playlist_ID_215 = "PLYQsl_3bRnvFEwfX0TKSrhEOHOQqM08e4"
YOUTUBE_playlist_ID_216 = "PLJkSNj_cDCQ8BzvVyMaYfky8aApMncpkL"
YOUTUBE_playlist_ID_217 = "PLWJ-CDe7pZRpEe8lGHfOgwmNgPYcX5S6g"
YOUTUBE_playlist_ID_218 = "PL_Y3qbepMRobK-5b0cLm01rUz_uLNUHgf"
YOUTUBE_playlist_ID_219 = "PLfIzX94OxuJZEqMtxkqJBsZQ71L4-bGJP"
YOUTUBE_playlist_ID_220 = "PL_Y3qbepMRoY0sQyU63HpCHxkL6kTbJZm"
YOUTUBE_playlist_ID_221 = "PLfIzX94OxuJYHZ9LG2_gxFQc-cb-lpJib"
YOUTUBE_playlist_ID_222 = "PLfIzX94OxuJbBrcGOkPm6Skp07UJH6KFN"
YOUTUBE_playlist_ID_223 = "PL04_iQLCxgZJrTOIZzlhQapI1Vz6hlPjH"
YOUTUBE_playlist_ID_224 = "PLDpKxDJ6kT6WWFJs6SPUpdX0QzuWfP3cp"
YOUTUBE_playlist_ID_225 = "PLajDTu-nQtATlZoSLJAafSBbjm3jJzkbA"
YOUTUBE_playlist_ID_226 = "PL7RVQyT9-wSYcuSAqYUquzO3D3_fnOqIq"
YOUTUBE_playlist_ID_227 = "PLUHMpFAJSIMuuZI5FonSxJQo75FgoWnoc"
YOUTUBE_playlist_ID_228 = "PLWJ-CDe7pZRpz0t5cV24vf0nmCaw8YzaP"
YOUTUBE_playlist_ID_229 = "PL4fmrV2b4JujBWeGl98E6SugMdRij8ocP"
YOUTUBE_playlist_ID_230 = "PLR6vyZ1nBsHQ-1qGZZlSKyNbW8gNIg34J"
YOUTUBE_playlist_ID_231 = "PL-A7a0s0MkU-dAqriZezVbN-mwrO7NnrX"
YOUTUBE_playlist_ID_232 = "PLGRgpgkW4aRXSMWgiO3Y-lNsOThB10oET"
YOUTUBE_playlist_ID_233 = "PLF2FAFFDB8C052868"
YOUTUBE_playlist_ID_234 = "PL-A7a0s0MkU8byqhJcR2jxj8ekQh7QnkT"
YOUTUBE_playlist_ID_235 = "PLN27akZUvwXBssXjcNEQpSPERgF5q0k_Q"
YOUTUBE_playlist_ID_236 = "PLB140EE3F730A2C88"
YOUTUBE_playlist_ID_237 = "PLCGziSiGakF3djgKkC5NMC5W2P9kc-lRr"
YOUTUBE_playlist_ID_238 = "PLFyvgMP3QJSHaA1EINldbnSF1NgTlaMUL"
YOUTUBE_playlist_ID_239 = "PLxDEOOKKs4aOQm60nuyl4Dx6abewX_IQg"
YOUTUBE_playlist_ID_240 = "PLyYh3L0LMkLhJpBwLxZ1UM8GsJEpsIbtc"
YOUTUBE_playlist_ID_241 = "PLtKz87JWQAT6gsDAr6SS3G1YZQ2C99dif"
YOUTUBE_playlist_ID_242 = "PL8DGG2n9ywHyZ8XQFoPKc_afltFifBuK8"
YOUTUBE_playlist_ID_243 = "PLdVXn4eUQ_svO1UculFtcBfFWY7Tp7FO5"
YOUTUBE_playlist_ID_244 = "PLcMIROFbI26YfpQ44iSYpHPTChkLI_Io9"
YOUTUBE_playlist_ID_245 = "PLvQw-_AMqQmINjNIKpUbMzrq6dL7aMlHW"
YOUTUBE_playlist_ID_246 = "PLpCM_wuG1SiCqyzOJXtyQhcUzndwzRHef"
YOUTUBE_playlist_ID_247 = "PLvekoSFsIRO_6DmmKQH4YCLHXYIXMfd67"
YOUTUBE_playlist_ID_248 = "PLqLL7OD4G7yuPG5BEiqsmkN7SjY98SgxL"
YOUTUBE_playlist_ID_249 = "PLNqQQD2var7T4Adfng92CaVUas6zqvE9N"
YOUTUBE_playlist_ID_250 = "PLWHLfi-54l2TAS-wQKU3F6hln1vU-gOeP"
YOUTUBE_playlist_ID_251 = "PLHxlnVM4P7nKrXRdKyHs9IjoaTkjG3M3Z"   
YOUTUBE_playlist_ID_252 = "PLA7WqWOs3qDWxIFf6NDhqR4h6pSjgz6zQ"   
YOUTUBE_playlist_ID_253 = "PL8-Kan55nNhR9VpVZXsQHOdsp5BEJdujf"   
YOUTUBE_playlist_ID_254 = "PLojCK8_ompuVNWQzVmaGZHEuEY1q-9Gvt"   
YOUTUBE_playlist_ID_255 = "PLHIVSRNAg7ckPNp97fTTl1HGcuBlefMI-" 
YOUTUBE_playlist_ID_256 = "PLRRBjC3hxqIitcRtjpfLeoAt9ObE8VJK0"   
YOUTUBE_playlist_ID_257 = "PLLgo7TB2ImrbbjlLtVdMpenaJPkLhQPXI"   
YOUTUBE_playlist_ID_258 = "PLzpBCPOY1XwmzG1TFlR14oCndtg8FW4IZ"   
YOUTUBE_playlist_ID_259 = "PLcV9cgm1R-hkrsui8Z0XB4qkH37jAU2OE"   
YOUTUBE_playlist_ID_260 = "PLS70QQThwVzIOPNlmrAi-YqSK7M6nfdae" 
# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]A Bailar Peque[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_9+"/",
        thumbnail="https://i.imgur.com/Y1aBG3t.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]ABC Song For Children[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_90+"/",
        thumbnail="https://i.imgur.com/1GOyVqz.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Adivina Adivinanza[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_187+"/",
        thumbnail="https://i.imgur.com/ST6WsUX.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Adivina Adivinanza II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_188+"/",
        thumbnail="https://i.imgur.com/p485asa.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Adornos Navidad[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_12+"/",
        thumbnail="https://i.imgur.com/d8q9FWD.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Ana De Las Tejas Verdes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_43+"/",
        thumbnail="https://i.imgur.com/gbEsica.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Aprende El Alfabeto[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_222+"/",
        thumbnail="https://i.imgur.com/TaSmR8K.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Aprende Con Baby Radio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_226+"/",
        thumbnail="https://i.imgur.com/XKRhR4R.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Aprende Con Dani[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_220+"/",
        thumbnail="https://i.imgur.com/MEcS8gV.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Aprende Ingles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_13+"/",
        thumbnail="https://i.imgur.com/ef8CQoy.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Astro Boy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_250+"/",
        thumbnail="https://i.imgur.com/VlOyuo9.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Audicion y Lenguaje - Estimulación del Lenguaje de 3 a 6 Años[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_117+"/",
        thumbnail="https://i.imgur.com/mPRS3EV.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Audicion y Lenguaje - Juegos Educativos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_116+"/",
        thumbnail="https://i.imgur.com/mPRS3EV.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Audicion y Lenguaje - Discriminacion Auditiva de Sonidos Cotidianos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_118+"/",
        thumbnail="https://i.imgur.com/mPRS3EV.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Audio Cuentos Infantiles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_128+"/",
        thumbnail="https://i.imgur.com/1RGLpJe.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Audio Cuentos Infantiles II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_230+"/",
        thumbnail="https://i.imgur.com/rcC4nTo.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Aventureros Del Aire[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_158+"/",
        thumbnail="https://i.imgur.com/pN60ui2.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Baby Tv[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_186+"/",
        thumbnail="https://i.imgur.com/gB5N7yu.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Baby Firts De 2 a 3 Años[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_192+"/",
        thumbnail="https://i.imgur.com/EAiQDwp.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Bajoterra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_198+"/",
        thumbnail="https://i.imgur.com/9B80sdn.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Bakugan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_209+"/",
        thumbnail="https://i.imgur.com/iyO83Om.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Bandolero[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_54+"/",
        thumbnail="https://i.imgur.com/UQIH4X7.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Banner y Flappy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_64+"/",
        thumbnail="https://i.imgur.com/XvaWtG1.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Barba Roja[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_248+"/",
        thumbnail="https://i.imgur.com/asH5BPU.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Barrio Sesamo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_19+"/",
        thumbnail="https://i.imgur.com/yYgF0ek.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Basket Fever[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_165+"/",
        thumbnail="https://i.imgur.com/hMlHOng.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Bing[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_136+"/",
        thumbnail="https://i.imgur.com/dw9QtPQ.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Bingo y Rolly[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_255+"/",
        thumbnail="https://i.imgur.com/MwTr6n7.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Blaze y Los Monster Machines[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_79+"/",
        thumbnail="https://i.imgur.com/pZn9A6u.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Bob Esponja[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_195+"/",
        thumbnail="https://i.imgur.com/dwgdn9n.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Brandy y El Señor Bigotes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_200+"/",
        thumbnail="https://i.imgur.com/iuMdBoS.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Buenos Modales Para Niños[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_130+"/",
        thumbnail="https://i.imgur.com/ZWqDRIp.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Caillou[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_6+"/",
        thumbnail="https://i.imgur.com/XyIcChc.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Caligrafia Con El Doctor Beet Remolacha[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_228+"/",
        thumbnail="https://i.imgur.com/HVTnli0.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Calimero y Priscila[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_46+"/",
        thumbnail="https://i.imgur.com/E9erJXl.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Campeones Oliver y Benji[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_28+"/",
        thumbnail="https://i.imgur.com/RQMQyfb.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Candy Candy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_239+"/",
        thumbnail="https://i.imgur.com/7ST0VOa.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Canta Con Cleo y Cuquin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_137+"/",
        thumbnail="https://i.imgur.com/uAeCkt0.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Canta Juegos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1+"/",
        thumbnail="https://i.imgur.com/ruFEJtM.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Cantando Aprendo a Hablar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_109+"/",
        thumbnail="https://i.imgur.com/kXnF3E1.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Cantando Aprendo a Hablar - Lenguaje de Signos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_110+"/",
        thumbnail="https://i.imgur.com/kXnF3E1.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Canciones De Parchis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_251+"/",
        thumbnail="https://i.imgur.com/WRiK0S5.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Canciones Infantiles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_189+"/",
        thumbnail="https://i.imgur.com/xqegskn.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Canciones Infantiles II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_233+"/",
        thumbnail="https://i.imgur.com/UmT08Ku.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Canciones Infantiles En Lenguaje de Signos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_120+"/",
        thumbnail="https://i.imgur.com/dfE5Agj.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Canciones Preescolares[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_132+"/",
        thumbnail="https://i.imgur.com/Mwd54Li.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Cantando Villancicos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_238+"/",
        thumbnail="https://i.imgur.com/XJODVAn.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Cosas de Peques - Cuentos Infantiles Animados En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_114+"/",
        thumbnail="https://i.imgur.com/JJpREB8.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Chicho Terremoto[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_53+"/",
        thumbnail="https://i.imgur.com/HINgWNQ.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Clash A Rama[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_173+"/",
        thumbnail="https://i.imgur.com/nAZMyem.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Clarence[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_210+"/",
        thumbnail="https://i.imgur.com/xL39A6k.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Cocina para Niños[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_21+"/",
        thumbnail="https://i.imgur.com/btlJ9wo.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Codigo Lyoko[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_207+"/",
        thumbnail="https://i.imgur.com/ncr9Aek.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Comando G[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_65+"/",
        thumbnail="https://i.imgur.com/VzOzYMs.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Cortometrajes Para Educar En Valores[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_95+"/",
        thumbnail="https://i.imgur.com/lKHpoUK.png",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Cosmic Kids Yoga - Kids Yoga Adventures Starting From The Beginning[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_85+"/",
        thumbnail="https://i.imgur.com/lpnZtR2.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Cosmic Kids Yoga - Our Mindfulness For Kids Series[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_86+"/",
        thumbnail="https://i.imgur.com/lpnZtR2.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Cosmic Kids Yoga - Peace Out Guided Relaxation For Kids[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_96+"/",
        thumbnail="https://i.imgur.com/lpnZtR2.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Cosmic Kids Yoga - Playlist For Older Kids[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_99+"/",
        thumbnail="https://i.imgur.com/lpnZtR2.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Conan El Niño Del Futuro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_153+"/",
        thumbnail="https://i.imgur.com/p1LniXy.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Cortos Disney Pixar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_191+"/",
        thumbnail="https://i.imgur.com/RToXSzt.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Cosas de Peques - Manualidades Faciles Para Niños[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_115+"/",
        thumbnail="https://i.imgur.com/JJpREB8.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Croket[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_193+"/",
        thumbnail="https://i.imgur.com/ChLetcB.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Cuentos De Hadas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_231+"/",
        thumbnail="https://i.imgur.com/cg9JkjI.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Cuentos Infantiles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_127+"/",
        thumbnail="https://i.imgur.com/K3Bg47D.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Cuentos Infantiles Para Dormir[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_232+"/",
        thumbnail="https://i.imgur.com/Qsuv3zC.png",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Daniel El Travieso[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_41+"/",
        thumbnail="https://i.imgur.com/aQSApaG.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Dartacan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_141+"/",
        thumbnail="https://i.imgur.com/K8m55ZK.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Dave El Barbaro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_211+"/",
        thumbnail="https://i.imgur.com/rlMQyJ8.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]David El Gnomo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_34+"/",
        thumbnail="https://i.imgur.com/yTf55H9.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Dibujos Animados[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_4+"/",
        thumbnail="https://i.imgur.com/swiL1Bh.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Delfy y Sus Amigos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_63+"/",
        thumbnail="https://i.imgur.com/h9CHmWa.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Dinofroz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_201+"/",
        thumbnail="https://i.imgur.com/q9eqgnu.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Dino Rey[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_196+"/",
        thumbnail="https://i.imgur.com/UR733n1.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Disney Sing Along[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_121+"/",
        thumbnail="https://i.imgur.com/Gh9Kb8a.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Donde Esta Chicky[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_246+"/",
        thumbnail="https://i.imgur.com/4yMbvh8.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Donde Esta Wally[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_183+"/",
        thumbnail="https://i.imgur.com/sHSpXb7.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Doug[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_254+"/",
        thumbnail="https://i.imgur.com/HlII69W.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Dragones y Mazmorras[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_44+"/",
        thumbnail="https://i.imgur.com/LCYxqQ8.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Drama Total[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_180+"/",
        thumbnail="https://i.imgur.com/AqWFxSu.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Dream Team[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_163+"/",
        thumbnail="https://i.imgur.com/JVBGODo.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Earth Worm Jim[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_203+"/",
        thumbnail="https://i.imgur.com/NyXjHkg.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Educativos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_17+"/",
        thumbnail="https://i.imgur.com/E80XVuT.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]El Abecedario En Ingles Para Niños[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_219+"/",
        thumbnail="https://i.imgur.com/3T70fb9.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]El Antiguo Testamento En Dibujos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_235+"/",
        thumbnail="https://i.imgur.com/rWzf13x.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]El Alfabeto y Sus Sonidos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_229+"/",
        thumbnail="https://i.imgur.com/sw1pmvt.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]El Asombroso Mundo De Gumball[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_134+"/",
        thumbnail="https://i.imgur.com/JBch8vx.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]El Conde Patula[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_66+"/",
        thumbnail="https://i.imgur.com/HslGfn3.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]El Inspector Gadget[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_33+"/",
        thumbnail="https://i.imgur.com/n8Z9FFq.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]El Mago De Oz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_155+"/",
        thumbnail="https://i.imgur.com/L0Uz4rQ.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]El Mono Silabo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_223+"/",
        thumbnail="https://i.imgur.com/lxxoEgY.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]El Mundo de Luna[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_111+"/",
        thumbnail="https://i.imgur.com/anKZu7T.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]El Pajaro Loco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_31+"/",
        thumbnail="https://i.imgur.com/5hboEJ3.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]El Perro de Flandes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_49+"/",
        thumbnail="https://i.imgur.com/enPcnmz.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]El Pequeño Reino De Ben y Holly[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_249+"/",
        thumbnail="https://i.imgur.com/PNvYID7.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]El Reino Ifantil[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_112+"/",
        thumbnail="https://i.imgur.com/l69Pow1.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]El Show De Archie[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_208+"/",
        thumbnail="https://i.imgur.com/ejnb1p3.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]El Zorro Generacion Z[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_179+"/",
        thumbnail="https://i.imgur.com/7SbsiWP.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]En Busca del Valle Encantado[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_36+"/",
        thumbnail="https://i.imgur.com/ffe79dw.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Español Para Niños Extranjeros[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_224+"/",
        thumbnail="https://i.imgur.com/xz6U591.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Escuela Virtual Preescolar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_227+"/",
        thumbnail="https://i.imgur.com/WXwjtku.png",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Erase Una Vez Las Americas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_152+"/",
        thumbnail="https://i.imgur.com/CKLEJo1.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Erase Una Vez El Cuerpo Humano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_59+"/",
        thumbnail="https://i.imgur.com/Fa4TViq.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Erase Una Vez El Espacio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_58+"/",
        thumbnail="https://i.imgur.com/FQ1HE6f.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Erase Una Vez Los Exploradores[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_60+"/",
        thumbnail="https://i.imgur.com/1FYy6IE.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Erase una Vez El Hombre[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_61+"/",
        thumbnail="https://i.imgur.com/XDleqMq.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Erase Una Vez La Vida[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_62+"/",
        thumbnail="https://i.imgur.com/R6QU71P.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Fabulas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_143+"/",
        thumbnail="https://i.imgur.com/0DLwGMM.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Fabulas Del Bosque Verde[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_144+"/",
        thumbnail="https://i.imgur.com/Xk5SJH8.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Fairy Tales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_234+"/",
        thumbnail="https://i.imgur.com/fJFMkzF.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Fantasias Animadas De Ayer y Hoy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_240+"/",
        thumbnail="https://i.imgur.com/7zz6OSJ.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Flash Gordon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_159+"/",
        thumbnail="https://i.imgur.com/tZIygDi.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Flipper y Lopaka[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_150+"/",
        thumbnail="https://i.imgur.com/NQ9LlMH.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Formas y Figuras Para Niños[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_221+"/",
        thumbnail="https://i.imgur.com/qKaWRKo.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Geografia Para Niños[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_217+"/",
        thumbnail="https://i.imgur.com/0bUt8Wp.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Gogo's Adventures With English[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_92+"/",
        thumbnail="https://i.imgur.com/w6uSClq.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Guia Infantil[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_84+"/",
        thumbnail="https://i.imgur.com/Betmlmz.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Guia Infantil II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_119+"/",
        thumbnail="https://i.imgur.com/iOtJzWE.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Happy Learning Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_113+"/",
        thumbnail="https://i.imgur.com/rb8docg.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Heidi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_24+"/",
        thumbnail="https://i.imgur.com/vaIOnWZ.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]He Man y Los Masters Del Universo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_259+"/",
        thumbnail="https://i.imgur.com/JzgAp9T.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Henry El Monstruito Feliz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_75+"/",
        thumbnail="https://i.imgur.com/vw1IgAu.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Historias De La Cripta Dibujos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_243+"/",
        thumbnail="https://i.imgur.com/HSge7rb.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Historias de Juguetes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_123+"/",
        thumbnail="https://i.imgur.com/fnSpw6m.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Historia De Las Islas Canarias[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_236+"/",
        thumbnail="https://i.imgur.com/Z0n6Gdz.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Hot Wheels Battle Force 5[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_205+"/",
        thumbnail="https://i.imgur.com/4bDOkUy.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Hoy No Hay Cole[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_102+"/",
        thumbnail="https://i.imgur.com/SfFokXy.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Inazuma Eleven Go[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_199+"/",
        thumbnail="https://i.imgur.com/JpgQGCP.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Isidoro y Los Gatos Cadillac[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_69+"/",
        thumbnail="https://i.imgur.com/IWmDDcR.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Jackie y Nuca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_52+"/",
        thumbnail="https://i.imgur.com/6Jq63tC.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Jelly Jamm[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_56+"/",
        thumbnail="https://i.imgur.com/B0RqRQ7.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Jorge El Curioso[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_39+"/",
        thumbnail="https://i.imgur.com/iX2Q4Oz.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Juegos Educativos De Pipo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_225+"/",
        thumbnail="https://i.imgur.com/OwQNJsf.png",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Juguetes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_16+"/",
        thumbnail="https://i.imgur.com/7uPNMRM.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Karaoke[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_8+"/",
        thumbnail="https://i.imgur.com/8abDUzf.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Kids TV Playlist Español - Canciones Infantiles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_83+"/",
        thumbnail="https://i.imgur.com/3tkL7mU.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Kimba El Leon Blanco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_244+"/",
        thumbnail="https://i.imgur.com/k4jiIOf.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]La Abeja Maya[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_47+"/",
        thumbnail="https://i.imgur.com/hBKkwix.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]La Banda de Mozart[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_50+"/",
        thumbnail="https://i.imgur.com/NPE5uCS.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]La Banda Del Patio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_242+"/",
        thumbnail="https://i.imgur.com/LXOx2hT.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]La Casa De Mickey Mouse[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_164+"/",
        thumbnail="https://i.imgur.com/JhBb9Pe.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]La Educoteca - Matematicas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_106+"/",
        thumbnail="https://i.imgur.com/BkgGGPe.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]La Educoteca - Ciencias Naturales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_104+"/",
        thumbnail="https://i.imgur.com/BkgGGPe.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]La Educoteca - Ciencias Sociales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_105+"/",
        thumbnail="https://i.imgur.com/BkgGGPe.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]La Educoteca - Lengua y Literatura[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_107+"/",
        thumbnail="https://i.imgur.com/BkgGGPe.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]La Educoteca - El Gran Libro Viajero[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_108+"/",
        thumbnail="https://i.imgur.com/BkgGGPe.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]La Gallina Pintadita[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_157+"/",
        thumbnail="https://i.imgur.com/q5zsZOI.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]La Hormiga y El Oso Hormiguero[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_142+"/",
        thumbnail="https://i.imgur.com/YW7ayMJ.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]La Navidad en Dibujos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_147+"/",
        thumbnail="https://i.imgur.com/hYOcpVs.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]La Pantera Rosa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_51+"/",
        thumbnail="https://i.imgur.com/E4kPLGu.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]La Pequeña Lulu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_257+"/",
        thumbnail="https://i.imgur.com/S1nK7hK.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]La Princesa Sofia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_71+"/",
        thumbnail="https://i.imgur.com/70HBvxF.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Las Aventuras de Hijitus[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_253+"/",
        thumbnail="https://i.imgur.com/ULy3sJh.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Las Aventuras De Orfhen[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_213+"/",
        thumbnail="https://i.imgur.com/NoWnHdB.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Las Aventuras De Pinocho[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_174+"/",
        thumbnail="https://i.imgur.com/M8XQXmZ.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Las Aventuras de Tintin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_29+"/",
        thumbnail="https://i.imgur.com/WUC9U8z.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Las Aventuras De Tom Sawyer[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_80+"/",
        thumbnail="https://i.imgur.com/gfQfvop.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Las Aventuras de Winnie de Pooh[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_35+"/",
        thumbnail="https://i.imgur.com/vkmq3zb.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Las Cronicas Del Zorro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_197+"/",
        thumbnail="https://i.imgur.com/jS8clq8.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Las Mil y Una Americas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_214+"/",
        thumbnail="https://i.imgur.com/i8SnLVn.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Lazy Town[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_212+"/",
        thumbnail="https://i.imgur.com/M0Rmeft.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Lengua y Ortografia Para Niños[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_218+"/",
        thumbnail="https://i.imgur.com/kZoOSHi.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Little BabyBum Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_91+"/",
        thumbnail="https://i.imgur.com/KhtKS7C.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Little Treehouse Español - Canciones Infantiles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_81+"/",
        thumbnail="https://i.imgur.com/QOeh1vP.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Llego La Navidad[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_237+"/",
        thumbnail="https://i.imgur.com/aAaVD6A.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Llega Experimentos - Experimentos Caseros[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_101+"/",
        thumbnail="https://i.imgur.com/JEuZMcX.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Llega Experimentos - Hazlo Tú Mismo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_100+"/",
        thumbnail="https://i.imgur.com/JEuZMcX.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Loca Academia De Policia Dibujos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_146+"/",
        thumbnail="https://i.imgur.com/z5jDkYE.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Lola Y Virgimia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_78+"/",
        thumbnail="https://i.imgur.com/LYDFFMR.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Los Animales Del Bosque[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_149+"/",
        thumbnail="https://i.imgur.com/mkypbQZ.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Los Baby Muppets[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_26+"/",
        thumbnail="https://i.imgur.com/FFqjmj0.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Los Backyardigans[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_74+"/",
        thumbnail="https://i.imgur.com/inS5pLh.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Los Cazafantasmas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_156+"/",
        thumbnail="https://i.imgur.com/kXaSFBs.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Los Cuentos de Minie[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_22+"/",
        thumbnail="https://i.imgur.com/nkqQUOa.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Los Diminutos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_48+"/",
        thumbnail="https://i.imgur.com/F7TojeA.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Los Ewoks[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_42+"/",
        thumbnail="https://i.imgur.com/SNWzssq.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Los Fraguel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_2+"/",
        thumbnail="https://i.imgur.com/SeBQID9.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Los Fruitis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_139+"/",
        thumbnail="https://i.imgur.com/p5s2ChF.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Los Gatos Samurai[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_166+"/",
        thumbnail="https://i.imgur.com/4Qchlha.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Los Lunnis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_182+"/",
        thumbnail="https://i.imgur.com/2CJPtqu.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Los Moto Ratones De Marte[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_256+"/",
        thumbnail="https://i.imgur.com/aooapLc.png",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Los Mundos De Yupi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_258+"/",
        thumbnail="https://i.imgur.com/QYb5kE4.png",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Los Osos Amorosos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_252+"/",
        thumbnail="https://i.imgur.com/ZP1PnO0.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Los Pica Pica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_148+"/",
        thumbnail="https://i.imgur.com/s14w2yQ.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Los Pitufos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_38+"/",
        thumbnail="https://i.imgur.com/yDqAoUQ.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Los Trotamusicos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_76+"/",
        thumbnail="https://i.imgur.com/6PGjv7J.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Lucky Luke[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_151+"/",
        thumbnail="https://i.imgur.com/yAwBSFD.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Luke and Lily Español - Canciones Infantiles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_82+"/",
        thumbnail="https://i.imgur.com/e4GORQY.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Luli TV Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_103+"/",
        thumbnail="https://i.imgur.com/B7oNi9b.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Lou[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_194+"/",
        thumbnail="https://i.imgur.com/GIKRLrY.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Manualidades Para Peques[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_10+"/",
        thumbnail="https://i.imgur.com/I9A9cfS.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Marco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_25+"/",
        thumbnail="https://i.imgur.com/U5QS24P.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Mario Bros[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_170+"/",
        thumbnail="https://i.imgur.com/ML96wya.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Masha y El Oso[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_140+"/",
        thumbnail="https://i.imgur.com/5fDZ03n.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Mejores Juguetes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_126+"/",
        thumbnail="https://i.imgur.com/z4hX7sb.png",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Meteoro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_175+"/",
        thumbnail="https://i.imgur.com/Ngn9NA3.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Mickey Mouse[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_57+"/",
        thumbnail="https://i.imgur.com/b8Hs0Az.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Mix Canciones Infantiles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_129+"/",
        thumbnail="https://i.imgur.com/9dmKpXf.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Mofli El Ultimo Koala[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_202+"/",
        thumbnail="https://i.imgur.com/Tzi4XqS.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Momentos Looney Toons[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_138+"/",
        thumbnail="https://i.imgur.com/D4UJwaU.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Mona La Vampira[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_241+"/",
        thumbnail="https://i.imgur.com/qUPl24I.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Monster High[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_181+"/",
        thumbnail="https://i.imgur.com/jDgPjFw.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Morphle[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_176+"/",
        thumbnail="https://i.imgur.com/TBr3Szg.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Mortadelo y Filemon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_73+"/",
        thumbnail="https://i.imgur.com/o8s6qLw.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Muffalo Potato - Animals[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_89+"/",
        thumbnail="https://i.imgur.com/dn59edh.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Muffalo Potato - Comics[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_87+"/",
        thumbnail="https://i.imgur.com/dn59edh.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Muffalo Potato - Movies[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_94+"/",
        thumbnail="https://i.imgur.com/dn59edh.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Mundo Pin y Pon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_18+"/",
        thumbnail="https://i.imgur.com/TWIjfE2.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Narigota[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_204+"/",
        thumbnail="https://i.imgur.com/4yRrNS4.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Nils Holgersson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_167+"/",
        thumbnail="https://i.imgur.com/cjU4EaQ.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Oddbods[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_131+"/",
        thumbnail="https://i.imgur.com/P8qD4GF.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Patrulla Canina[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_7+"/",
        thumbnail="https://i.imgur.com/Ay5Vp1b.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Peliculas de Dibujos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_145+"/",
        thumbnail="https://i.imgur.com/EqcKPT2.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Peppa Pig[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_3+"/",
        thumbnail="https://i.imgur.com/aQZQrUP.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Pingus[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_133+"/",
        thumbnail="https://i.imgur.com/yCR9nQ6.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Pinta y Colorea[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_77+"/",
        thumbnail="https://i.imgur.com/7fI2dyk.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Pippi Calzas Largas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_32+"/",
        thumbnail="https://i.imgur.com/VdvQwUB.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Playmobil[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_20+"/",
        thumbnail="https://i.imgur.com/bL7pnh4.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Poco Yo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_5+"/",
        thumbnail="https://i.imgur.com/6uZ2K8t.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Popeye[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_14+"/",
        thumbnail="https://i.imgur.com/wi4JIab.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Pororo El Pequeño Pinguino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_70+"/",
        thumbnail="https://i.imgur.com/J3tj0nz.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Rainbow Brite[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_260+"/",
        thumbnail="https://i.imgur.com/Rrw68CS.png",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Reciclamos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_11+"/",
        thumbnail="https://i.imgur.com/qv5J7Eb.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Ricky Zoom[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_135+"/",
        thumbnail="https://i.imgur.com/h1BaqAc.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Rin Tin Tin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_30+"/",
        thumbnail="https://i.imgur.com/vn5IXzf.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Robin Hood[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_206+"/",
        thumbnail="https://i.imgur.com/Gz1Yfse.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Robocop[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_160+"/",
        thumbnail="https://i.imgur.com/V72xG2C.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Robotech[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_215+"/",
        thumbnail="https://i.imgur.com/3AITHCk.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Ruy El Pequeño Cid[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_177+"/",
        thumbnail="https://i.imgur.com/R5qUz7D.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Samed El Duende Magico[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_168+"/",
        thumbnail="https://i.imgur.com/xKaSUrD.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]San Francisco De Asis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_162+"/",
        thumbnail="https://i.imgur.com/N2DTLBM.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Sherlock Holmes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_37+"/",
        thumbnail="https://i.imgur.com/CAA9H37.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Simon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_172+"/",
        thumbnail="https://i.imgur.com/kwTZV2T.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Star Wars Droid[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_216+"/",
        thumbnail="https://i.imgur.com/0FLgEne.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Street Fighter Victory[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_171+"/",
        thumbnail="https://i.imgur.com/p3umCvD.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Super Simple Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_88+"/",
        thumbnail="https://i.imgur.com/DssrbEb.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Sylvan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_40+"/",
        thumbnail="https://i.imgur.com/9kSYJGs.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Tarta de Fresa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_23+"/",
        thumbnail="https://i.imgur.com/QcRc3Wv.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Tayo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_178+"/",
        thumbnail="https://i.imgur.com/gzHINvV.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Teletubbies[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_245+"/",
        thumbnail="https://i.imgur.com/x9Fm269.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Telmo y Tula, Dibujos Divertidos y Educativos De Manualidades y Recetas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_98+"/",
        thumbnail="https://i.imgur.com/R3Xn9Ei.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Teen Titans Go[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_72+"/",
        thumbnail="https://i.imgur.com/DacDMol.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Teen Wolf[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_169+"/",
        thumbnail="https://i.imgur.com/oiHhmm3.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]The Artful Parent - Action Art For Kids[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_93+"/",
        thumbnail="https://i.imgur.com/MApfFNw.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]The Artful Parent - Kids Science Activities[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_97+"/",
        thumbnail="https://i.imgur.com/MApfFNw.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Toys And Happy Kids[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_122+"/",
        thumbnail="https://i.imgur.com/NY98v0f.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Toys On The Go[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_125+"/",
        thumbnail="https://i.imgur.com/xKWeUW0.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Transformers Nueva Generacion[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_184+"/",
        thumbnail="https://i.imgur.com/zIqYYQN.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Tremending Girls[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_124+"/",
        thumbnail="https://i.imgur.com/MFQhLQo.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Trenes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_68+"/",
        thumbnail="https://i.imgur.com/PRjDB37.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Trolls[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_55+"/",
        thumbnail="https://i.imgur.com/NlLC5i8.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Ulises 31[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_45+"/",
        thumbnail="https://i.imgur.com/eIEoQpC.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Vampirina[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_67+"/",
        thumbnail="https://i.imgur.com/NZP34zi.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Vicky El Vikingo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_27+"/",
        thumbnail="https://i.imgur.com/G1nvSX9.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Videos Educativos Niños de 3 a 5 Años[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_190+"/",
        thumbnail="https://i.imgur.com/e4OyPhK.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Watchmen[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_247+"/",
        thumbnail="https://i.imgur.com/aWemFC2.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Willy Fog[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_185+"/",
        thumbnail="https://i.imgur.com/stgivjl.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Winx Club[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_154+"/",
        thumbnail="https://i.imgur.com/TZGy4QQ.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Zipi y Zape[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_161+"/",
        thumbnail="https://i.imgur.com/zLPWOx5.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR fuchsia]Zoo Super[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_15+"/",
        thumbnail="https://i.imgur.com/e4OyPhK.jpg",
		fanart="https://i.imgur.com/Ue113Uf.jpg",
        folder=True )
		
run()