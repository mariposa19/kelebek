# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Sourced From Online Templates And Guides
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Thanks To: Google Search For This Template
# Modified: MUSICHALL
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.KinderLand'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

xbmc.executebuiltin('Container.SetViewMode(500)')

YOUTUBE_CHANNEL_ID_1 = "PLRmzfJ4Grw0bZ2gWFi2zp0OBYmk8_L7CB"
YOUTUBE_CHANNEL_ID_2 = "PLKXN6nw9Z7HvaN0NjeLtwf0eKwZxfP4ef"
YOUTUBE_CHANNEL_ID_3 = "PLB4E1bdzTS-0q70SQvo8dutaOAyAezHnd"
YOUTUBE_CHANNEL_ID_4 = "PLNq2eaZvd5PumPjmilxrHpS0hrCZJQxZ5"
YOUTUBE_CHANNEL_ID_5 = "PLiNcpyRLD5LsRw7f8CZOnpFjT0nQmsjXQ"
YOUTUBE_CHANNEL_ID_6 = "PL73Iu0Lv3wtQSyfZgVskUU1onHDyoBn0e"
YOUTUBE_CHANNEL_ID_7 = "PLHYjU4m8qoOaVce8BTMVeTRw2uF7zsBJh"
YOUTUBE_CHANNEL_ID_8 = "PLkfv0YNz_eismgkkCMFIQgMGmMu_qQ2h7"
YOUTUBE_CHANNEL_ID_9 = "PLDogFQIY1D4ZqGSvr1OQO1rO1dxvh-Gsz"
YOUTUBE_CHANNEL_ID_10 = "PLkxBepFUPVIsvqrkIHoJormoukxmCxSwq"
YOUTUBE_CHANNEL_ID_11 = "PLemyWmGdwuSPSn4qbS4v3Q9hreVKhSuCG"
YOUTUBE_CHANNEL_ID_12 = "PLwMdVkhuaYw2CgFWTp3jxfi6sr01kpH_f" 
YOUTUBE_CHANNEL_ID_13 = "PLIfm15g-bybp2UJiUfTWhFtIlQknGEZ_t" 
YOUTUBE_CHANNEL_ID_14 = "PLVbsijrFzerkdhSIcNzXpmsKWi0iMn7e5"
YOUTUBE_CHANNEL_ID_15 = "PLQq5fo51vA7SBzQxf00ngw9UaoQ5-k5J0"
YOUTUBE_CHANNEL_ID_16 = "PLuYDaFEnWNZDnxJgWrgUl1Vmrm2ZnHRrW" 
YOUTUBE_CHANNEL_ID_17 = "PLchPNRpVGLgZvtvmbg_xqodPNC7zmHhLQ"
YOUTUBE_CHANNEL_ID_18 = "PLtw1moQvVxOisfVtzlXQy638qLiqm34iw"
YOUTUBE_CHANNEL_ID_19 = "PLww09CxR_lB6HU5eqnvGuulqtkwI8wJmq"
YOUTUBE_CHANNEL_ID_20 = "PLnJX9p9Xo47MA0gg8jCq2k5ywehqLIPdf"
YOUTUBE_CHANNEL_ID_21 = "PLnmlahqxxEQzGYjOVE3bZ2UjMX2w3jjX_"
YOUTUBE_CHANNEL_ID_22 = "PL9A473A74B833BB3E"
YOUTUBE_CHANNEL_ID_23 = "PL9rE6bq_Luyyl2s76A4QTKgyPF-8U7Pan"
YOUTUBE_CHANNEL_ID_24 = "PLUuRJYptYFXBmaLE1oNJYPxyl-3mSLKL3"
YOUTUBE_CHANNEL_ID_25 = "PLutxf9xWvQKa0-ZMI5fyFSeABblPOF3Kk"
YOUTUBE_CHANNEL_ID_26 = "PL3rWuW8jgIQNTFfHzQOFAmKOWfyv3jIU4"
YOUTUBE_CHANNEL_ID_27 = "PLvyDCUr4HHt3z-6NjZB1Gx-fnvRVn0_E0"
YOUTUBE_CHANNEL_ID_28 = "PLKXN6nw9Z7HstOVIA68ZjmvZSQoE3vjG5"
YOUTUBE_CHANNEL_ID_29 = "PLkQH3mZohooAXHCjfkEAr_L8sITEbnyRX"
YOUTUBE_CHANNEL_ID_30 = "PLjxOg4YY7Ah2JGb_QvA6KSB6YmikzA2fo"
YOUTUBE_CHANNEL_ID_31 = "PLPBylKJy18Us88S092hTxluHkU4PrwgpM"
YOUTUBE_CHANNEL_ID_32 = "PL2QrQSTMbPE1a8Rto67D_1lUKaxn1mm6X"
YOUTUBE_CHANNEL_ID_33 = "PLKXN6nw9Z7HviOy57S70Ito6QOaINzpgb"
YOUTUBE_CHANNEL_ID_34 = "PLpSWLIHTG6ifGirFHPCUzX2K1C3kPJr4L"
YOUTUBE_CHANNEL_ID_35 = "PLVtH1q_l8JQO4QjptPQTIigHUg82umewx"
YOUTUBE_CHANNEL_ID_36 = "PL-NWsVkG3lN3bdO5uRhA5tjO4cX2HXHTE"
YOUTUBE_CHANNEL_ID_37 = "PLKXN6nw9Z7HtaxzxDtF56Q_L3ZLBQvOd0"
YOUTUBE_CHANNEL_ID_38 = "PLynb7MteT3bv-JXyQJFD0dgMX1p-kbTyw"
YOUTUBE_CHANNEL_ID_39 = "PL08EcHdANEaXICpcYT9H1ZZgdFQqHEgOX"
YOUTUBE_CHANNEL_ID_40 = "PLKXN6nw9Z7HtEQccUv2UALNJJ48jaF3ip"
YOUTUBE_CHANNEL_ID_41 = "PLKXN6nw9Z7HtuWk78WiiQ9sBgEg3G4Aev"
YOUTUBE_CHANNEL_ID_42 = "PLKXN6nw9Z7HssnZcHSSoNFuqI0kQsKXZk"
YOUTUBE_CHANNEL_ID_43 = "PLKXN6nw9Z7HujzV_atUlQa5haQZWtLzx"
YOUTUBE_CHANNEL_ID_44 = "PLKXN6nw9Z7HsS0DPmeZNxe5TaAHDXdgwE"
YOUTUBE_CHANNEL_ID_45 = "PLKXN6nw9Z7HtkixOu0nUU1Du3gEUyOlMf"
YOUTUBE_CHANNEL_ID_46 = "PLKXN6nw9Z7HtKePP7N2nB2DszyF6hxZl4"
YOUTUBE_CHANNEL_ID_47 = "PLKXN6nw9Z7HsvyRwyQhJBJiP2GeZakrso"
YOUTUBE_CHANNEL_ID_48 = "PLKXN6nw9Z7HtvW_nxIw5IZFEg49Mknr21"
YOUTUBE_CHANNEL_ID_49 = "PLKXN6nw9Z7HsUHYS3j_Pz6avbp4kXLECy"
YOUTUBE_CHANNEL_ID_50 = "PLfH8EZSX2vobnR5Oc5OdhYzzpwDB5D6iH"
YOUTUBE_CHANNEL_ID_51 = "PLHyALu4MRWqNgD-oD3HeXFhR6f0U0V1Rp"
YOUTUBE_CHANNEL_ID_52 = "PLKXN6nw9Z7Hv8QjgB3szcgP_PLETSQ9I4"
YOUTUBE_CHANNEL_ID_53 = "PLKXN6nw9Z7HtWLzlIzPV3tZo1vbVQeppO"
YOUTUBE_CHANNEL_ID_54 = "PLpCM_wuG1SiDaF_ra2M7Ygudx55-jTP8j"
YOUTUBE_CHANNEL_ID_55 = "PLUmLp8QGk1vChuwtjcYmkGOciHMD6Ahj6"
YOUTUBE_CHANNEL_ID_56 = "PLoLuTO-srY1gFdzCO3Is53ZvVUV6HN9e-"
YOUTUBE_CHANNEL_ID_57 = "PLe4ZuWFax2d82L388D4BDFsS5fvuQpzu-"
YOUTUBE_CHANNEL_ID_58 = "PLKXN6nw9Z7HuhYBgbkhFswHJq0Vb6W-39"
YOUTUBE_CHANNEL_ID_59 = "PLKXN6nw9Z7HuccOOslRqe9JrxQRrRFq7D"
YOUTUBE_CHANNEL_ID_60 = "PLKXN6nw9Z7Hv9GVkaSijS175SzaumdgTg"
YOUTUBE_CHANNEL_ID_61 = "PLM3zaEIjzXIX0lfjtdMiflymrv2tzS1ph"
YOUTUBE_CHANNEL_ID_62 = "PLvmFTGTOxh9OrRZpv-GQhb_bwYTcobJDE"
YOUTUBE_CHANNEL_ID_63 = "PLKXN6nw9Z7HsDrXtg3uKdqc8IclKslcCz"
YOUTUBE_CHANNEL_ID_64 = "PLKXN6nw9Z7Hv3jXKsQqa1A27bWWAW8iG6"
YOUTUBE_CHANNEL_ID_65 = "PLKXN6nw9Z7Hs4-BXD7AKjKx97EdtgAnPe"
YOUTUBE_CHANNEL_ID_66 = "PLKXN6nw9Z7HuJznz-IKImOFhTtH3Xs84T"
YOUTUBE_CHANNEL_ID_67 = "PLtIxg922avyKnoP01fe_KJGvoYLRqdlGG"
YOUTUBE_CHANNEL_ID_68 = "PLbNOclD9qRWnTLTx0WyhB-wcwqo6Tbcv1"
YOUTUBE_CHANNEL_ID_69 = "PLKXN6nw9Z7HvCi0ug6Lc79G3AMgS3r4mx"
YOUTUBE_CHANNEL_ID_70 = "PLdNk6FKMo-YXzQZmgWCHQMbcbnie07X_m"
YOUTUBE_CHANNEL_ID_71 = "PLJ5vn2xlGQnNeBnc53Do3tS85A2akrfWL"
YOUTUBE_CHANNEL_ID_72 = "PLn_efX3kt9f_E8_HSsFNgLBYFhPQ5UylS"
YOUTUBE_CHANNEL_ID_73 = "PL2F58ACE889F9EFE6"
YOUTUBE_CHANNEL_ID_74 = "PLjXyTw1_uY7NKDZdfdmHQNqLfKvVccru4"
YOUTUBE_CHANNEL_ID_75 = "PLHIVSRNAg7clrI3hDrPhvUe4Z7Y6u8O_G"
YOUTUBE_CHANNEL_ID_76 = "PLKXN6nw9Z7Hu4L3KpnWM6TefxSZZ5bemJ"
YOUTUBE_CHANNEL_ID_77 = "PL_talHzUi3vIK18QL4dLVCz97dN4RuHfU"
YOUTUBE_CHANNEL_ID_78 = "PL8WfiHeijGLCozCvOaGFxy55WDBA8b2vf"
YOUTUBE_CHANNEL_ID_79 = "PLx4Gqi_X0riBP0VbGk_qThpBscEXqzZqj"
YOUTUBE_CHANNEL_ID_80 = "PLKXN6nw9Z7HtqFjXzIO1P2h2l98Xz6HQd"
YOUTUBE_CHANNEL_ID_81 = "PLOy6Pyub2zig09F9FLMHb1mp1mex7sITh"
YOUTUBE_CHANNEL_ID_82 = "PL0pbu2h9LmWEO9oIMSuUm7PVt4HcnYYvU"
YOUTUBE_CHANNEL_ID_83 = "PLk8MuEC6Nz4Xxy0SSV1W3fi1rKMes58N-"
YOUTUBE_CHANNEL_ID_84 = "PLWMYMD0Gnd9SuTMdm2VrryMAuNpUj1gOU"
YOUTUBE_CHANNEL_ID_85 = "PL8snGkhBF7njuEl8V642ZeFwcbVRRPFLG"
YOUTUBE_CHANNEL_ID_86 = "PL8snGkhBF7ngDp1oJtx5VcjwatxZn8xLK"
YOUTUBE_CHANNEL_ID_87 = "PLusSrZ-7Aiev0uxn3c7KcoH9msKrXkJW7"
YOUTUBE_CHANNEL_ID_88 = "LLLsooMJoIpl_7ux2jvdPB-Q"
YOUTUBE_CHANNEL_ID_89 = "PLusSrZ-7AievwZv-Zc56vIAb-BxZeYDyC"
YOUTUBE_CHANNEL_ID_90 = "PLvOE0yRoG4X_js9ETBSDeWrRxrrnWdzm_"
YOUTUBE_CHANNEL_ID_91 = "PLWYQuS6aEMRDcHza5LQjPbRkrwu2qt6DT"
YOUTUBE_CHANNEL_ID_92 = "PLcn453b0kzi_XxypPWQKCVKGxop_nF1qa"
YOUTUBE_CHANNEL_ID_93 = "PLDUvSiwQy5cEx31-XjBJCfcU1K9Lox79L"
YOUTUBE_CHANNEL_ID_94 = "PLusSrZ-7AiesCVcITlK7S6eEh2bnx52n6"
YOUTUBE_CHANNEL_ID_95 = "PL5tb2ODzv2rSWKrSeZwtZrPgvekFyU33P"
YOUTUBE_CHANNEL_ID_96 = "PL8snGkhBF7njO0QvtE97AJFL3xZYQSGh5"
YOUTUBE_CHANNEL_ID_97 = "PLDUvSiwQy5cEklxOj93LMaoqyjtoTr05t"
YOUTUBE_CHANNEL_ID_98 = "PLJK3tljUgjzI0EVB9IGOWT4Uhiz_f7HsT"
YOUTUBE_CHANNEL_ID_99 = "PL8snGkhBF7nhEc52y4C1S9yqjBQSLCmT4"
YOUTUBE_CHANNEL_ID_100 = "PL_o8kq_GWfOlkFJ7ugSjRQ_soFhluWbB_"
YOUTUBE_CHANNEL_ID_101 = "PL_o8kq_GWfOkin4jcvYdUTSP0x2XED8ll"
YOUTUBE_CHANNEL_ID_102 = "PLuff7HnBIm5V0ty1LNEQBoI9x34UpC4iF"
YOUTUBE_CHANNEL_ID_103 = "PLgK76qegaoMzghYeQ5xMyZK9bdFfMKvdd"
YOUTUBE_CHANNEL_ID_104 = "PLD-2f-nig1ajeEuckkeJOxyp2MctiVQcC"
YOUTUBE_CHANNEL_ID_105 = "PLD-2f-nig1ajD9pjWU-zpnAkudHqphTsE"
YOUTUBE_CHANNEL_ID_106 = "PL3BEF4668E8568186"
YOUTUBE_CHANNEL_ID_107 = "PLF457B8EA1B3039DB"
YOUTUBE_CHANNEL_ID_108 = "PLD-2f-nig1ajk15N3oKyMA9qrZirbjhzF"
YOUTUBE_CHANNEL_ID_109 = "PLeY6ZuXvnilX9p_XwmFsYbZm12IeEPF1E"
YOUTUBE_CHANNEL_ID_110 = "PLeY6ZuXvnilUOmxS5s_JmtBjeOrjp7nRg"
YOUTUBE_CHANNEL_ID_111 = "PLSyxqIHOw0ZMMjw741Pqn494SalYHVRMv"
YOUTUBE_CHANNEL_ID_112 = "LLK1i2UviaXLUNrZlAFpw_jA"
YOUTUBE_CHANNEL_ID_113 = "LLGkVdu_EVrqqxQ7OnLFK8RQ"
YOUTUBE_CHANNEL_ID_114 = "PLguZfwIrWHOZl5zCA8P4xNjFUMw4OjRHI"
YOUTUBE_CHANNEL_ID_115 = "PLguZfwIrWHOZnMgmt32VOetq3a_cSr7zs"
YOUTUBE_CHANNEL_ID_116 = "PLfVDJFxsvnTRdnn11-X_B8NvO4Lcn3uNG"
YOUTUBE_CHANNEL_ID_117 = "PLfVDJFxsvnTRi2fuVBjMK2RDhEbi9hFjJ"
YOUTUBE_CHANNEL_ID_118 = "PLfVDJFxsvnTRT0VbCB4wdIXUoQdFCKS3W"
YOUTUBE_CHANNEL_ID_119 = "LL_WjKI3-m_CLhx0gjctCSkQ"
YOUTUBE_CHANNEL_ID_120 = "PLl3ShNbWJXFBniubEJIefEswXiL5IP-f4"
YOUTUBE_CHANNEL_ID_121 = "PLEFC1282E4331AC14"
YOUTUBE_CHANNEL_ID_122 = "LLwDjQReLwrODEwY1qoE-wuA"
YOUTUBE_CHANNEL_ID_123 = "PLMeWlmsH8nbGVodj5zw-fsUoU8SaA54Vk"
YOUTUBE_CHANNEL_ID_124 = "PLz9jduKZZp17NLTiptvJ5tqfiJTTeUMvA"
YOUTUBE_CHANNEL_ID_125 = "LLe1T7EkHIHvOIWBG1Om8xHA"
YOUTUBE_CHANNEL_ID_126 = "PLi6wag8FdvTCGXRSWK7rHw-mmHBeiGW0U"
YOUTUBE_CHANNEL_ID_127 = "PLslpKpQmman7xcUdLadsWuj0ve4dv5sS_"
YOUTUBE_CHANNEL_ID_128 = "PLR6vyZ1nBsHReWClo7s2F9f6cB_GcTiqv"
YOUTUBE_CHANNEL_ID_129 = "PL3oAQyb9tbOccBDyYn9RLy-esks6i-EQU"
YOUTUBE_CHANNEL_ID_130 = "PLWCM1QJKbFLpT73U9zbj2Ys7mOV_3wnPA"
YOUTUBE_CHANNEL_ID_131 = "PLP7X5ycpylZiDWKqRorRJKDdUh73PzFsm"
YOUTUBE_CHANNEL_ID_132 = "PLA7cuYLKfPXTbOa4tPuVCPEDyXbroACJ2"
YOUTUBE_CHANNEL_ID_133 = "PLKXN6nw9Z7HuJcT7VTHYTsPMlfCxyN67s"
YOUTUBE_CHANNEL_ID_134 = "PLcx_TDPjWGai9JlLBLPjMLQ21P8xhOIxm"
YOUTUBE_CHANNEL_ID_135 = "PL_Z_xDpQRmANyf3RsW0Z5Uy-FhdT3yca9"
YOUTUBE_CHANNEL_ID_136 = "PLidbREU52rbfSxbiW0bvWmK-9_0-VmuAM"
YOUTUBE_CHANNEL_ID_137 = "PL1flQe3LmzxnT4zBwwCSnzJhZCYTzTyqa"
YOUTUBE_CHANNEL_ID_138 = "PLCF4P0UGv7KSEuRBVSboEXSl2syLUIfDS"
YOUTUBE_CHANNEL_ID_139 = "PLKXN6nw9Z7HvyXsGf3t_8-WriklrFSYPv"
YOUTUBE_CHANNEL_ID_140 = "PLnb4OlLvQaoNHrdsFBi9yKkztvaWjbiXM"
YOUTUBE_CHANNEL_ID_141 = "PLpSWLIHTG6idwDXwIm-7eaCpauPBw0vGf"
YOUTUBE_CHANNEL_ID_142 = "PLHyALu4MRWqPfYupZurrRsxlnNk8H4Bpu"
YOUTUBE_CHANNEL_ID_143 = "PLR6-4WNns-3ePydnoZTGb-uxmWfB4YAWk"
YOUTUBE_CHANNEL_ID_144 = "PLZ4POPAfakSGuNfFkFX3SvkrkOHVfDXNt"
YOUTUBE_CHANNEL_ID_145 = "PLNq2eaZvd5PumPjmilxrHpS0hrCZJQxZ5"
YOUTUBE_CHANNEL_ID_146 = "PLKXN6nw9Z7HvUXtDe7Qf8OalvSjhAo772"
YOUTUBE_CHANNEL_ID_147 = "PLNZOXjS7YP3VPHtavlxFXNjsX-xMfEH2p"
YOUTUBE_CHANNEL_ID_148 = "PLrHaiVR2iJBHfqrA3y9U0ouktuAH6Uxo-"
YOUTUBE_CHANNEL_ID_149 = "PLZ4POPAfakSFHusVG6FvI23LZu2J1cmUN"
YOUTUBE_CHANNEL_ID_150 = "PLBy6KvkIQY38_sZNfA-NOp6uvWmmlADFz"
# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))
	
    plugintools.add_item( 
        #action="", 
        title="Canta Juegos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://i.imgur.com/ruFEJtM.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Playmobil",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_20+"/",
        thumbnail="https://i.imgur.com/bL7pnh4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Barrio Sesamo",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_19+"/",
        thumbnail="https://i.imgur.com/yYgF0ek.jpg",
        folder=True )
	

    plugintools.add_item( 
        #action="", 
        title="Mundo Pin y Pon",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_18+"/",
        thumbnail="https://i.imgur.com/TWIjfE2.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Educativos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="https://i.imgur.com/E80XVuT.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Patrulla Canina",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="https://i.imgur.com/Ay5Vp1b.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Dibujos Animados",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://i.imgur.com/swiL1Bh.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Caillou",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="https://i.imgur.com/XyIcChc.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Poco Yo",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="https://i.imgur.com/6uZ2K8t.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Manualidades para peques",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="https://i.imgur.com/I9A9cfS.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Peppa Pig",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://i.imgur.com/aQZQrUP.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Popeye",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="https://i.imgur.com/wi4JIab.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Cocina para Niños",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_21+"/",
        thumbnail="https://i.imgur.com/btlJ9wo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Reciclamos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="https://i.imgur.com/qv5J7Eb.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Los Fraguel",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://i.imgur.com/SeBQID9.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Aprende Ingles",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="https://i.imgur.com/ef8CQoy.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="A Bailar Peque",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="https://i.imgur.com/Y1aBG3t.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Adornos Navidad",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="https://i.imgur.com/d8q9FWD.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Karaoke",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="https://i.imgur.com/8abDUzf.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Zootopia",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="https://i.imgur.com/SEdUNmc.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Juguetes",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="https://i.imgur.com/7uPNMRM.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Los Cuentos de Minie",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_22+"/",
        thumbnail="https://i.imgur.com/nkqQUOa.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Tarta de fresa",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_23+"/",
        thumbnail="https://i.imgur.com/QcRc3Wv.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Heidi",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_24+"/",
        thumbnail="https://i.imgur.com/vaIOnWZ.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Marco",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_25+"/",
        thumbnail="https://i.imgur.com/U5QS24P.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Los Baby Muppets",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_26+"/",
        thumbnail="https://i.imgur.com/FFqjmj0.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Vicky El Vikingo",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_27+"/",
        thumbnail="https://i.imgur.com/G1nvSX9.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Campeones Oliver y Benji",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_28+"/",
        thumbnail="https://i.imgur.com/RQMQyfb.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Las Aventuras de Tintin",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_29+"/",
        thumbnail="https://i.imgur.com/WUC9U8z.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Rin Tin Tin",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_30+"/",
        thumbnail="https://i.imgur.com/vn5IXzf.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="El Pajaro Loco",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_31+"/",
        thumbnail="https://i.imgur.com/5hboEJ3.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Pippi Calzas Largas",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_32+"/",
        thumbnail="https://i.imgur.com/VdvQwUB.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="El Inspector Gadget",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_33+"/",
        thumbnail="https://i.imgur.com/n8Z9FFq.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="David El Gnomo",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_34+"/",
        thumbnail="https://i.imgur.com/yTf55H9.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Las Aventuras de Winnie de Pooh",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_35+"/",
        thumbnail="https://i.imgur.com/vkmq3zb.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Serie En Busca del Valle Encantado",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_36+"/",
        thumbnail="https://i.imgur.com/ffe79dw.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Serlock Holmes",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_37+"/",
        thumbnail="https://i.imgur.com/CAA9H37.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Los Pitufos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_38+"/",
        thumbnail="https://i.imgur.com/yDqAoUQ.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Jorge El Curioso",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_39+"/",
        thumbnail="https://i.imgur.com/iX2Q4Oz.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Sylvan",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_40+"/",
        thumbnail="https://i.imgur.com/9kSYJGs.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Daniel El Travieso",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_41+"/",
        thumbnail="https://i.imgur.com/aQSApaG.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Los Ewoks",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_42+"/",
        thumbnail="https://i.imgur.com/SNWzssq.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Ana De Las Tejas Verdes",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_43+"/",
        thumbnail="https://i.imgur.com/gbEsica.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Dragones y Mazmorras",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_44+"/",
        thumbnail="https://i.imgur.com/LCYxqQ8.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Ulises 31",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_45+"/",
        thumbnail="https://i.imgur.com/eIEoQpC.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Calimero y Priscila",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_46+"/",
        thumbnail="https://i.imgur.com/E9erJXl.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="La Abeja Maya",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_47+"/",
        thumbnail="https://i.imgur.com/hBKkwix.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Los Diminutos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_48+"/",
        thumbnail="https://i.imgur.com/F7TojeA.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="El Perro de Flandes",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_49+"/",
        thumbnail="https://i.imgur.com/enPcnmz.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="La Banda de Mozart",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_50+"/",
        thumbnail="https://i.imgur.com/NPE5uCS.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="La Pantera Rosa",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_51+"/",
        thumbnail="https://i.imgur.com/E4kPLGu.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Jackie y Nuca",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_52+"/",
        thumbnail="https://i.imgur.com/6Jq63tC.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Chicho Terremoto",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_53+"/",
        thumbnail="https://i.imgur.com/HINgWNQ.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Bandolero",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_54+"/",
        thumbnail="https://i.imgur.com/UQIH4X7.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Trolls",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_55+"/",
        thumbnail="https://i.imgur.com/NlLC5i8.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Jelly Jamm",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_56+"/",
        thumbnail="https://i.imgur.com/B0RqRQ7.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Mickey Mouse",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_57+"/",
        thumbnail="https://i.imgur.com/b8Hs0Az.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Erase Una Vez El Espacio",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_58+"/",
        thumbnail="https://i.imgur.com/FQ1HE6f.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Erase Una Vez El Cuerpo Humano",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_59+"/",
        thumbnail="https://i.imgur.com/Fa4TViq.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Erase Una Vez Los Exploradores",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_60+"/",
        thumbnail="https://i.imgur.com/1FYy6IE.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Erase una Vez El Hombre",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_61+"/",
        thumbnail="https://i.imgur.com/XDleqMq.jpg",
        folder=True )
    plugintools.add_item( 
        #action="", 
        title="Erase Una Vez La Vida",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_62+"/",
        thumbnail="https://i.imgur.com/R6QU71P.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Delfy y Sus Amigos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_63+"/",
        thumbnail="https://i.imgur.com/h9CHmWa.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Banner y Flappy",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_64+"/",
        thumbnail="https://i.imgur.com/XvaWtG1.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Comando G",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_65+"/",
        thumbnail="https://i.imgur.com/VzOzYMs.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="El Conde Patula",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_66+"/",
        thumbnail="https://i.imgur.com/HslGfn3.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Vampirina",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_67+"/",
        thumbnail="https://i.imgur.com/NZP34zi.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Trenes",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_68+"/",
        thumbnail="https://i.imgur.com/PRjDB37.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Isidoro y Los Gatos Cadillac",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_69+"/",
        thumbnail="https://i.imgur.com/IWmDDcR.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Pororo El Pequeño Pinguino",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_70+"/",
        thumbnail="https://i.imgur.com/J3tj0nz.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="La Princesa Sofia",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_71+"/",
        thumbnail="https://i.imgur.com/70HBvxF.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Teen Titans Go",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_72+"/",
        thumbnail="https://i.imgur.com/DacDMol.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Mortadelo y Filemon",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_73+"/",
        thumbnail="https://i.imgur.com/o8s6qLw.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Los Backyardigans",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_74+"/",
        thumbnail="https://i.imgur.com/inS5pLh.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Henry El Monstruito Feliz",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_75+"/",
        thumbnail="https://i.imgur.com/vw1IgAu.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Los Trotamusicos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_76+"/",
        thumbnail="https://i.imgur.com/6PGjv7J.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Pinta y Colorea",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_77+"/",
        thumbnail="https://i.imgur.com/7fI2dyk.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Lola Y Virgimia",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_78+"/",
        thumbnail="https://i.imgur.com/LYDFFMR.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Blaze y Los Monster Machines",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_79+"/",
        thumbnail="https://i.imgur.com/pZn9A6u.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Las Aventuras De Tom Sawyer",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_80+"/",
        thumbnail="https://i.imgur.com/gfQfvop.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Little Treehouse Español - Canciones Infantiles",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_81+"/",
        thumbnail="https://i.imgur.com/QOeh1vP.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Luke and Lily Español - Canciones Infantiles",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_82+"/",
        thumbnail="https://i.imgur.com/e4GORQY.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Kids TV Channel Español - Canciones Infantiles",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_83+"/",
        thumbnail="https://i.imgur.com/3tkL7mU.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="guiainfantil",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_84+"/",
        thumbnail="https://i.imgur.com/Betmlmz.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Cosmic Kids Yoga - Kids yoga adventures starting from the beginning",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_85+"/",
        thumbnail="https://i.imgur.com/lpnZtR2.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Cosmic Kids Yoga - Our mindfulness for kids series",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_86+"/",
        thumbnail="https://i.imgur.com/lpnZtR2.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Muffalo Potato - Comics",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_87+"/",
        thumbnail="https://i.imgur.com/dn59edh.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Super Simple Songs",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_88+"/",
        thumbnail="https://i.imgur.com/DssrbEb.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Muffalo Potato - Animals",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_89+"/",
        thumbnail="https://i.imgur.com/dn59edh.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="ABC Song For Children",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_90+"/",
        thumbnail="https://i.imgur.com/1GOyVqz.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="LittleBabyBum Español",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_91+"/",
        thumbnail="https://i.imgur.com/KhtKS7C.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Gogo's Adventures with English",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_92+"/",
        thumbnail="https://i.imgur.com/w6uSClq.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="The Artful Parent - Action Art for Kids",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_93+"/",
        thumbnail="https://i.imgur.com/MApfFNw.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Muffalo Potato - Movies",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_94+"/",
        thumbnail="https://i.imgur.com/dn59edh.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Cortometrajes para educar en valores",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_95+"/",
        thumbnail="https://i.imgur.com/lKHpoUK.png",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Cosmic Kids Yoga - Peace Out Guided Relaxation for Kids",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_96+"/",
        thumbnail="https://i.imgur.com/lpnZtR2.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="The Artful Parent - Kids Science Activities",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_97+"/",
        thumbnail="https://i.imgur.com/MApfFNw.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Telmo y Tula, dibujos divertidos y educativos de manualidades y recetas",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_98+"/",
        thumbnail="https://i.imgur.com/R3Xn9Ei.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Cosmic Kids Yoga - Playlist for older kids",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_99+"/",
        thumbnail="https://i.imgur.com/lpnZtR2.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="LlegaExperimentos - Hazlo Tú Mismo",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_100+"/",
        thumbnail="https://i.imgur.com/JEuZMcX.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="LlegaExperimentos - Experimentos Caseros ",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_101+"/",
        thumbnail="https://i.imgur.com/JEuZMcX.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Hoy no hay cole",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_102+"/",
        thumbnail="https://i.imgur.com/SfFokXy.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Luli TV Español",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_103+"/",
        thumbnail="https://i.imgur.com/B7oNi9b.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="La Educoteca - Ciencias Naturales",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_104+"/",
        thumbnail="https://i.imgur.com/BkgGGPe.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="La Educoteca - Ciencias Sociales",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_105+"/",
        thumbnail="https://i.imgur.com/BkgGGPe.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="La Educoteca - Matematicas",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_106+"/",
        thumbnail="https://i.imgur.com/BkgGGPe.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="La Educoteca - Lengua y Literatura",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_107+"/",
        thumbnail="https://i.imgur.com/BkgGGPe.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="La Educoteca - El Gran Libro Viajero",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_108+"/",
        thumbnail="https://i.imgur.com/BkgGGPe.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Cantando Aprendo a Hablar",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_109+"/",
        thumbnail="https://i.imgur.com/kXnF3E1.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Cantando Aprendo a Hablar - Lenguaje de Signos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_110+"/",
        thumbnail="https://i.imgur.com/kXnF3E1.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="El Mundo de Luna",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_111+"/",
        thumbnail="https://i.imgur.com/anKZu7T.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="El reino infantil",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_112+"/",
        thumbnail="https://i.imgur.com/l69Pow1.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Happy Learning Español",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_113+"/",
        thumbnail="https://i.imgur.com/rb8docg.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Cosas de Peques - Cuentos infantiles animados en español",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_114+"/",
        thumbnail="https://i.imgur.com/JJpREB8.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Cosas de Peques - Manualidades faciles para niños",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_115+"/",
        thumbnail="https://i.imgur.com/JJpREB8.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Audicion y Lenguaje - Juegos Educativos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_116+"/",
        thumbnail="https://i.imgur.com/mPRS3EV.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Audicion y Lenguaje - Estimulación del Lenguaje de 3 a 6 años",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_117+"/",
        thumbnail="https://i.imgur.com/mPRS3EV.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Audicion y Lenguaje - Discriminacion Auditiva de Sonidos Cotidianos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_118+"/",
        thumbnail="https://i.imgur.com/mPRS3EV.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="guiainfantil",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_119+"/",
        thumbnail="https://i.imgur.com/iOtJzWE.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Canciones Infantiles en Lenguaje de Signos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_120+"/",
        thumbnail="https://i.imgur.com/dfE5Agj.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Disney Sing Along",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_121+"/",
        thumbnail="https://i.imgur.com/Gh9Kb8a.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Toys & happy kids",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_122+"/",
        thumbnail="https://i.imgur.com/NY98v0f.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Historias de Juguetes",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_123+"/",
        thumbnail="https://i.imgur.com/fnSpw6m.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Tremending girls",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_124+"/",
        thumbnail="https://i.imgur.com/MFQhLQo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="TOYS on the go!",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_125+"/",
        thumbnail="https://i.imgur.com/xKWeUW0.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Mejores Juguetes",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_126+"/",
        thumbnail="https://i.imgur.com/z4hX7sb.png",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Cuentos Infantiles",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_127+"/",
        thumbnail="https://i.imgur.com/K3Bg47D.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Audio Cuentos Infantiles",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_128+"/",
        thumbnail="https://i.imgur.com/1RGLpJe.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Mix Canciones Infantiles",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_129+"/",
        thumbnail="https://i.imgur.com/9dmKpXf.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Buenos Modales Para Niños",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_130+"/",
        thumbnail="https://i.imgur.com/ZWqDRIp.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Oddbods",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_131+"/",
        thumbnail="https://i.imgur.com/P8qD4GF.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="Canciones Preescolares",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_132+"/",
        thumbnail="https://i.imgur.com/Mwd54Li.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Pingus",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_133+"/",
        thumbnail="https://i.imgur.com/yCR9nQ6.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="El Asombroso Mundo De Gumball",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_134+"/",
        thumbnail="https://i.imgur.com/JBch8vx.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Ricky Zoom",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_135+"/",
        thumbnail="https://i.imgur.com/h1BaqAc.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Bing",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_136+"/",
        thumbnail="https://i.imgur.com/dw9QtPQ.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Canta Con Cleo y Cuquin",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_137+"/",
        thumbnail="https://i.imgur.com/uAeCkt0.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Momentos Looney Toons",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_138+"/",
        thumbnail="https://i.imgur.com/D4UJwaU.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Los Fruitis",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_139+"/",
        thumbnail="https://i.imgur.com/p5s2ChF.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Masha y El Oso",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_140+"/",
        thumbnail="https://i.imgur.com/5fDZ03n.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Dartacan",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_141+"/",
        thumbnail="https://i.imgur.com/K8m55ZK.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="La Hormiga y El Oso Hormiguero",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_142+"/",
        thumbnail="https://i.imgur.com/YW7ayMJ.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Fabulas",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_143+"/",
        thumbnail="https://i.imgur.com/0DLwGMM.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Fabulas Del Bosque Verde",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_144+"/",
        thumbnail="https://i.imgur.com/Xk5SJH8.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Peliculas y Cortos de Dibujos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_145+"/",
        thumbnail="https://i.imgur.com/EqcKPT2.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Loca Academia De Policia Dibujos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_146+"/",
        thumbnail="https://i.imgur.com/z5jDkYE.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="La Navidad en Dibujos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_147+"/",
        thumbnail="https://i.imgur.com/hYOcpVs.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Los Picapiedra",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_148+"/",
        thumbnail="https://i.imgur.com/HZeWEuh.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Los Animales Del Bosque",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_149+"/",
        thumbnail="https://i.imgur.com/mkypbQZ.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Flipper y Lopaka",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_150+"/",
        thumbnail="https://i.imgur.com/NQ9LlMH.jpg",
        folder=True )
		
run()