# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Thanks to the Authors of the base code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# modified by: MUSICHALL
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.SedalyPosta'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_search = "cGx1Z2luOi8vcGx1Z2luLnZpZGVvLnlvdXR1YmUva29kaW9uL3NlYXJjaC9saXN0Lw==".decode('base64') 
YOUTUBE_playlist_ID_0 = "PLSyCRkPeE-W2uUNk1vF-0qQzkz80EHphG"  
YOUTUBE_playlist_ID_1 = "PLWkSqIgqmYxY_6hDx6sZMxFZ0PWIKzYac"  
YOUTUBE_playlist_ID_2 = "PLRf6HoktifIGqK3hZZ6lPZ0laNoZvQ-Gn"   
YOUTUBE_playlist_ID_3 = "PLvZGX36TCSqDqsl4tpZKkC3LkCNKh4VpB"    
YOUTUBE_playlist_ID_4 = "PLcq_yO09ddUDg_nxMueZgpMFGHcbKoP0R"    
YOUTUBE_playlist_ID_5 = "PL7dsWn35XTXHQdYsbd61JU2iQVrnPaZgd"    
YOUTUBE_playlist_ID_6 = "PLWk0OcU1OK_Q6J_ZhWmMVeQ2C2K9cfspA"    
YOUTUBE_playlist_ID_7 = "PLdstBoUWYdEwth2X6YEp78smoBXCoxqKQ"    
YOUTUBE_playlist_ID_8 = "PL2J7PQ16gwwXD0lOr0FYL32iUguSxWpef"    
YOUTUBE_playlist_ID_9 = "PLXASeqZSjcxo2vQIze4gCqls9Pvlppwux"    
YOUTUBE_playlist_ID_10 = "PLxMVPqoiStVDROHAutAbLYP70C-aYx_57"   
YOUTUBE_playlist_ID_11 = "PL25RrJMQzDpTVedccuYrwOU8hLgH-3-JX"   
YOUTUBE_playlist_ID_12 = "PLtBm7HE4vHuGyVMFQ98yG1aPVl9eZWHIo"   
YOUTUBE_playlist_ID_13 = "PLainGAWRKTUX59Dw6ZXP8L9wFNWgwVJzc"   
YOUTUBE_playlist_ID_14 = "PLQLV3Hmisbij_5ylc9QdCAwwjtBlqa6Pz"   
YOUTUBE_playlist_ID_15 = "PLXeIfHlLiGVU9Q4m3NQ9UP2Iu52O13NrZ"   
YOUTUBE_playlist_ID_16 = "PLS1riLascrbKKEFu5QNEOFVJW3iju12iJ"   
YOUTUBE_playlist_ID_17 = "PLXmbAtL545WZHorTOLzgE8OpMOL9uaGON"   
YOUTUBE_playlist_ID_18 = "PLsfnjOmr3g7jMa22BfKLciPf_uWi7pvya"   
YOUTUBE_playlist_ID_19 = "PLKjRu571u6-AY7f5SUqmpUxZ0CQVRl8FS"   
YOUTUBE_playlist_ID_20 = "PL-PDfQgjlNuyPe86zOLT2SoGmWtiWGJf"   
YOUTUBE_playlist_ID_21 = "PL2x43d7O_HEOF9ddChRbOhV2hUdVIYzoP"   
YOUTUBE_playlist_ID_22 = "PLpwv-Mnsw8IOjCxPctpODNY91PS3OPvDI"   
YOUTUBE_playlist_ID_23 = "PL982Epyw3tYdNm_5ZwLy0Nnp6JVlhbPAm"   
YOUTUBE_playlist_ID_24 = "PLpwv-Mnsw8IOjCxPctpODNY91PS3OPvDI"   
YOUTUBE_playlist_ID_25 = "PL971f-4P5cMMDBZ4UDGnLaeFMrCgRMc8e"   
YOUTUBE_playlist_ID_26 = "PLRnKkxBDph6C-286Od7L2NpUZ5TpLTcbb"   
YOUTUBE_playlist_ID_27 = "PL7mRhwiE5YVBIsVqiJSYTwK7GgmpbZJMQ"   
YOUTUBE_playlist_ID_28 = "PLa4oHuCXnXRWrT_enQwPnx4SegDUuM0An"   
YOUTUBE_playlist_ID_29 = "PLdjA9Zqh0LcgoFyIAZcglTy3Oh5vFu8wJ"  
YOUTUBE_playlist_ID_30 = "PLdjA9Zqh0LchhS1YBD0yjs7V0zNdf2PQl"   
YOUTUBE_playlist_ID_31 = "PLgtMmNbKnT5yj8MTs7U02rrZ3w8gltE1-"   
YOUTUBE_playlist_ID_32 = "PL2J32U_mywtW_UoDO4s8q1zar5j99kk8n" 
YOUTUBE_playlist_ID_33 = "FLXOsDlyt9OZ-_16s4-B_Kqw"
YOUTUBE_playlist_ID_34 = "PLD0FAFCDAD290F64A"
YOUTUBE_playlist_ID_35 = "PLYrb5O7QbgD2F4cm_S7FhSFxnUAkWuk9y"
YOUTUBE_playlist_ID_36 = "PLR0UFwDJjIpWSP9gA5ViG6pcG-cE5qMVI"
YOUTUBE_playlist_ID_37 = "PLSYOVm2dLb6U666CVhsL_Lc02wi4pPcXS"
YOUTUBE_playlist_ID_38 = "PLFgJfgoU-r635W9RgZPuosy5r1dUfFHZP"
YOUTUBE_playlist_ID_39 = "PL9Ax_NuGIkeUuQNAIE2p3FuzEhiEf7k--"
YOUTUBE_playlist_ID_40 = "PLV7k8K1sta-WQ_YJbrSKeojrZCpLV_OwP"
YOUTUBE_playlist_ID_41 = "PL-PDfQgjlNuyPe86zOLT2SoGmWtiWGJfT"
YOUTUBE_playlist_ID_42 = "RDQMUx0d98dosI8"
YOUTUBE_playlist_ID_43 = "LL3VnU-n_kDqhYNUi3ARahuw"
YOUTUBE_playlist_ID_44 = "PLLtogDdWbh1fP1f2JiKprNUgfve3ac-B9"
YOUTUBE_playlist_ID_45 = "PLLtogDdWbh1cLugSpGZTLaeCF17QFNXNC"
YOUTUBE_playlist_ID_46 = "PL57hixRkd6kx2ra3yRD8pJosHlMrq3tnL"
YOUTUBE_playlist_ID_47 = "LLWJ8ZjK7MPGKH9rBVjflGUw" 
YOUTUBE_playlist_ID_48 = "PL2IPnorIh6PUfNiVvxTe91bFz6d-EOE1r"   
YOUTUBE_playlist_ID_49 = "PLFEKcZdMnFCU2SqhB1BwwaTnnQbAD4eIs"   
YOUTUBE_playlist_ID_50 = "PLjIgQHcRA-rFJfw5-2B_04izSxt7VHYk2"
YOUTUBE_playlist_ID_51 = "PL9JHsezdeKhKRp05ADxATZempO-Eo724O"   
YOUTUBE_playlist_ID_52 = "PLJzh6Cvw51ldFbGNfJMwTWwPBnL8IMuAF"   
YOUTUBE_playlist_ID_53 = "PLQ2rR07V_sC6EZPFUtHPZ5bjFYC2KoLvx"   
YOUTUBE_playlist_ID_54 = "PL5WFiN5sEovA613hBDgvtUJU23vQ1AIUf"   
YOUTUBE_playlist_ID_55 = "PLdMSkvJdgoCarkBxda7nbW9whG5MAimuM"   
YOUTUBE_playlist_ID_56 = "PL0y3XerjM2KPRCoT_STPcEDP7tGCrwca4"   
YOUTUBE_playlist_ID_57 = "PLT-n11zoefHtBUsG6McIVVhi2zO63CiDP"   
YOUTUBE_playlist_ID_58 = "PL-rHz-uurMwFjw4HBXrZzDP7QOVaWr1_R"   
YOUTUBE_playlist_ID_59 = "PLWsqmM7KxWcVGAnmWI1wFpuIq_j1WrjSS"   
YOUTUBE_playlist_ID_60 = "PLS2EFZ_MLM49_2tfSvpTufOerV1QtPtxF"  
YOUTUBE_playlist_ID_61 = "PL2IPnorIh6PVdw8AVeqYkMb_Cdsmdbti8"   
YOUTUBE_playlist_ID_62 = "PLcPf6zkpN3I7qI5wNKLEoqFiJ0SuB7k7W"   
YOUTUBE_playlist_ID_63 = "PLS2EFZ_MLM49_2tfSvpTufOerV1QtPtxF"   
YOUTUBE_playlist_ID_64 = "PLKjRu571u6-AY7f5SUqmpUxZ0CQVRl8FS"   
YOUTUBE_playlist_ID_65 = "PLmE_5yPQQmSYhwo7D111EzrTZJMAg0dcr"   
YOUTUBE_playlist_ID_66 = "PLf-MjXSExqSjZ8QZSZ78zeXEL3uG-DZVG"   
YOUTUBE_playlist_ID_67 = "PLNeqI-JsntvmjYtD4II8ptoW4LkdtxEVy"   
YOUTUBE_playlist_ID_68 = "PLiuhByXvxAoFb27ZhVVKNQXYVfBIdBta4"   
YOUTUBE_playlist_ID_69 = "PL4cyeacYClXtGcpFLACDVDp669rkkpL8P"   
YOUTUBE_playlist_ID_70 = "PLZw9ADTNB13-WzN4ypdyfHgv2M5N800Ak" 
YOUTUBE_playlist_ID_71 = "PLsWgO_0wBM-gqi6hKMW4mwYrmfOXIuO76"   
YOUTUBE_playlist_ID_72 = "PLRd4cRAzmq1Iz-Jeqb3tExnxVhvl8Ep-h"   
YOUTUBE_playlist_ID_73 = "PLpp9aSggw0IvHgrmX9sSbMYywIi43vz8X"   
YOUTUBE_playlist_ID_74 = "PLQajuvJgyGaXBaJvjd8RjqrpfJ8_5l6Ev"   
YOUTUBE_playlist_ID_75 = "PLxQ9vrDem2gSdnG6tltjrfa2O9f9NVdEE"   
YOUTUBE_playlist_ID_76 = "PLT-n11zoefHtBUsG6McIVVhi2zO63CiDP"   
YOUTUBE_playlist_ID_77 = "PLE7Mipk5dozZ26RlH239MI72lcsvmE89U"   
YOUTUBE_playlist_ID_78 = "PLf9oA_yob8tg68gi4T1SPQ9iS80TB1K2a"   
YOUTUBE_playlist_ID_79 = "PL8TB-GFt-STSyXoRusZgoj_a0iE8HoNp8"   
YOUTUBE_playlist_ID_80 = "PLmZcnf8WfMiIZXAfTaa-B1JlNWyasFfyd" 
YOUTUBE_playlist_ID_81 = "PLsfnjOmr3g7jMa22BfKLciPf_uWi7pvya"   
YOUTUBE_playlist_ID_82 = "PLsfnjOmr3g7jc5RXRGJLX5QeFLwJj-9Ey"   
YOUTUBE_playlist_ID_83 = "PLBLF7mUd94Z6DYuOt1pqa6Ezy-ngRumHU"   
YOUTUBE_playlist_ID_84 = "PLuE9iyrlTxD1do8nF0K9nRM7FASF2HDHp"   
YOUTUBE_playlist_ID_85 = "PLP_n01Cyf8hUD7trUOGIAR_BDWYke13OH"   
YOUTUBE_playlist_ID_86 = "PLOrtMCZT-ihf75xZUyIoZOH4IX0xFKaof"   
YOUTUBE_playlist_ID_87 = "PLXmbAtL545WYlRhXBJEjlS6XTUQZlabIz"   
YOUTUBE_playlist_ID_88 = "PLMAA6Pb8n2QuSB2gUNbBQ8Ii7Jo8DeVTp"   
YOUTUBE_playlist_ID_89 = "PLWmRMQhVPxMxc3X5UNuaqsL3vbDvw9_FW"   
YOUTUBE_playlist_ID_90 = "PLFUFgNA3fGAQOQTa9e4aYefz8kusKuqJS" 
YOUTUBE_playlist_ID_91 = "PLtT4BSyWsL_xFvycBrWt91mcjou6XEunB"   
YOUTUBE_playlist_ID_92 = "PLmZcnf8WfMiJG7ew-WGVH9OQ7-NHFp52O"   
YOUTUBE_playlist_ID_93 = "PLmZcnf8WfMiKf7btF627tPJiMEkZld-R6"   
YOUTUBE_playlist_ID_94 = "PLs4e5DStVdXJZOOmJI_zpZXG7ossaV00D"   
YOUTUBE_playlist_ID_95 = "PLcPf6zkpN3I7BWGTjK267N0RNcuataMAJ"   
YOUTUBE_playlist_ID_96 = "PLDJ-EuobjMSXkdBdeRDHPGzzm6IR2AzDZ"   
YOUTUBE_playlist_ID_97 = "PLsfnjOmr3g7gwRzW7x7dnl7gACGI9JtQm"   
YOUTUBE_playlist_ID_98 = "PLoKJ8R73Y7X_bfoUrFJ1I2fvD-mPKZ-Mn"   
YOUTUBE_playlist_ID_99 = "PLf9oA_yob8tgcwtptVdybU3CD3UMj3LNZ"   
YOUTUBE_playlist_ID_100 = "PLOrtMCZT-ihf13whBHMFB6vHdPEvVr9n7" 
# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Sedal y Posta Siguenos En El Grupo @AprendiendoKodi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_0+"/",
        thumbnail="https://i.imgur.com/3jtMDdm.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Buscador[/COLOR]",
        url=YOUTUBE_search,
        thumbnail="https://i.imgur.com/3jtMDdm.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Academia De Pesca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_61+"/",
        thumbnail="https://i.imgur.com/j2jbxGa.jpghttps://i.imgur.com/j2jbxGa.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Agua Dulce[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_62+"/",
        thumbnail="https://i.imgur.com/o10fATI.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Aguas Arriba[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_48+"/",
        thumbnail="https://i.imgur.com/h8vV43B.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Aimpoint[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_33+"/",
        thumbnail="https://i.imgur.com/gulCPRC.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )    	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Aparejos De Pesca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1+"/",
        thumbnail="https://i.imgur.com/sejsEOh.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Aparejos y Lineas De Pesca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_63+"/",
        thumbnail="https://i.imgur.com/ukZoEhJ.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Aprendiendo a Pescar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_2+"/",
        thumbnail="https://i.imgur.com/Do3fvRk.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Black Bass[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_49+"/",
        thumbnail="https://i.imgur.com/5aJJaQp.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Black Bass II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_65+"/",
        thumbnail="https://i.imgur.com/CVs4fOB.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Batidas de Jabalies y Corzos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_3+"/",
        thumbnail="https://i.imgur.com/KXjkMix.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Batidas y Lances Monteros[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_64+"/",
        thumbnail="https://i.imgur.com/rCpEyRO.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]BO Fishing[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_66+"/",
        thumbnail="https://i.imgur.com/JSOXAZw.png",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bricopesca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_67+"/",
        thumbnail="https://i.imgur.com/5YpU2Ca.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Calibre 7,62[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_68+"/",
        thumbnail="https://i.imgur.com/hKmqBUn.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Calibres[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_4+"/",
        thumbnail="https://i.imgur.com/QKQljSQ.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Canal Grupo Serbal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_7+"/",
        thumbnail="https://i.imgur.com/KIsWNDe.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Canal Caza 89[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_8+"/",
        thumbnail="https://i.imgur.com/5yYrLVn.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Caza Jara y Sedal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_44+"/",
        thumbnail="https://i.imgur.com/ySFXZox.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Caza Mayor En España[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_5+"/",
        thumbnail="https://i.imgur.com/jW31q7J.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Caza Menor[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_6+"/",
        thumbnail="https://i.imgur.com/rOdzYqe.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Caza Natura[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_37+"/",
        thumbnail="https://i.imgur.com/Qnttpbg.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Caza y Pesca Navarra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_47+"/",
        thumbnail="https://i.imgur.com/NgAbRMJ.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Caza y Pesca Nea[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_39+"/",
        thumbnail="https://i.imgur.com/b2nDxeE.png",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Caza y Pesca Roberto Peraza[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_40+"/",
        thumbnail="https://i.imgur.com/b2nDxeE.png",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cazando Aves[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_69+"/",
        thumbnail="https://i.imgur.com/Au4tSRb.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cetreria[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_9+"/",
        thumbnail="https://i.imgur.com/GK4BjHW.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Como Montar Aparejos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_60+"/",
        thumbnail="https://i.imgur.com/cSb8MPS.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Curso De Pesca Con Mosca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_70+"/",
        thumbnail="https://i.imgur.com/LqNF9MN.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Docupesca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_50+"/",
        thumbnail="https://i.imgur.com/4c1Q5l0.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]El Calamar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_10+"/",
        thumbnail="https://i.imgur.com/Rglugex.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]El Ricon Cinegetico[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_71+"/",
        thumbnail="https://i.imgur.com/IDe001a.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fly Fishing[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_72+"/",
        thumbnail="https://i.imgur.com/hOGDGEN.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fly Fishing Povs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_73+"/",
        thumbnail="https://i.imgur.com/ucgeBg0.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gescaza[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_74+"/",
        thumbnail="https://i.imgur.com/Bbb4Q2M.png",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hunters Video[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_35+"/",
        thumbnail="https://i.imgur.com/UVKoCY4.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jara Y sedal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_11+"/",
        thumbnail="https://i.imgur.com/S6XNADM.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Caza y Las Armas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_75+"/",
        thumbnail="https://i.imgur.com/xoA3ESm.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Hora Cazavision[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_36+"/",
        thumbnail="https://i.imgur.com/i5NJOYc.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Sacadera[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_12+"/",
        thumbnail="https://i.imgur.com/CWdvuC5.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Trucha[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_13+"/",
        thumbnail="https://i.imgur.com/TVFCKLh.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lances Y Aparejos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_14+"/",
        thumbnail="https://i.imgur.com/PyxxqgH.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo mejor de la Caza[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_46+"/",
        thumbnail="https://i.imgur.com/l0dfxAF.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Locos Por La Pesca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_15+"/",
        thumbnail="https://i.imgur.com/YALXd1f.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Ciprinidos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_16+"/",
        thumbnail="https://i.imgur.com/alR1jgW.png",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lucios Luciopercas y Black Bass[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_76+"/",
        thumbnail="https://i.imgur.com/cuQuef0.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Marba Caza[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_77+"/",
        thumbnail="https://i.imgur.com/g7ou4Cc.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Momentos De Pesca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_78+"/",
        thumbnail="https://i.imgur.com/09dtI4K.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Monte y Ribera[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_41+"/",
        thumbnail="https://i.imgur.com/b2nDxeE.png",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Monterias[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_17+"/",
        thumbnail="https://i.imgur.com/lR9IUDX.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Monterias II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_18+"/",
        thumbnail="https://i.imgur.com/BFw6H88.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Monterias III[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_19+"/",
        thumbnail="https://i.imgur.com/YnNMNTL.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Monterias En España[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_79+"/",
        thumbnail="https://i.imgur.com/2RPKA58.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Monterias Temporada 2017-2018[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_80+"/",
        thumbnail="https://i.imgur.com/CT1dKNH.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Monterias Temporada 2018-2019[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_81+"/",
        thumbnail="https://i.imgur.com/cX1SV1n.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Monterias Temporada 2019-2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_82+"/",
        thumbnail="https://i.imgur.com/0VCNKoh.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Monte Y Ribera[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_20+"/",
        thumbnail="https://i.imgur.com/HRom9TX.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Monstruos De Rio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_21+"/",
        thumbnail="https://i.imgur.com/NGzgPrM.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Oceano Tv[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_22+"/",
        thumbnail="https://i.imgur.com/0W2ys2M.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Oceano Visual[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_23+"/",
        thumbnail="https://i.imgur.com/iBu81b1.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pequeños Trucos De Pesca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_51+"/",
        thumbnail="https://i.imgur.com/MPpS7wS.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pesca Con Atarraya y Cucharilla[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_52+"/",
        thumbnail="https://i.imgur.com/jN9Hl8V.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pesca De La Carpa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_59+"/",
        thumbnail="https://i.imgur.com/vOJHgTA.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pesca Del Atun[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_54+"/",
        thumbnail="https://i.imgur.com/yufa6VB.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pesca Del Camaron[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_55+"/",
        thumbnail="https://i.imgur.com/naNLwvC.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pesca Del Lucio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_56+"/",
        thumbnail="https://i.imgur.com/3eNdco3.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pesca Deportiva[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_24+"/",
        thumbnail="https://i.imgur.com/7i095Ya.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pesca De Depredadores De Rio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_57+"/",
        thumbnail="https://i.imgur.com/Muhig4w.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pesca En Extremadura[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_83+"/",
        thumbnail="https://i.imgur.com/Oenbodg.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pesca En Kajak[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_84+"/",
        thumbnail="https://i.imgur.com/j4nD5kD.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pesca Extrema[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_25+"/",
        thumbnail="https://i.imgur.com/mi70gwv.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pesca Black Bass[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_38+"/",
        thumbnail="https://i.imgur.com/otTNPHR.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True ) 

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pesca Jara y Sedal[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_playlist_ID_45+"/",
        thumbnail="https://i.imgur.com/ySFXZox.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pesca a Mosca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_26+"/",
        thumbnail="https://i.imgur.com/0x4N8k3.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pesca Radical[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_42+"/",
        thumbnail="https://i.imgur.com/A4Qx7oZ.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pesca Submarina[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_27+"/",
        thumbnail="https://i.imgur.com/Jz186fd.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pescando Truchas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_85+"/",
        thumbnail="https://i.imgur.com/i1LPvoV.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pike Fishing[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_86+"/",
        thumbnail="https://i.imgur.com/riOg3Mx.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		
		
    plugintools.add_item(
	    #action="",
        title="[COLOR aqua]Producciones Villar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_43+"/",
        thumbnail="https://i.imgur.com/cMuIhUj.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rapalas y Señuelos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_28+"/",
        thumbnail="https://i.imgur.com/KanCc4f.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Reportajes Monteros[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_87+"/",
        thumbnail="https://i.imgur.com/A7ZW4gl.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rifles De Aire Comprimido[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_88+"/",
        thumbnail="https://i.imgur.com/bEyfHEY.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rifles De Caza[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_89+"/",
        thumbnail="https://i.imgur.com/TkzWIfH.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rifles y Proyectiles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_90+"/",
        thumbnail="https://i.imgur.com/YDseRdR.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rustical Fishing[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_91+"/",
        thumbnail="https://i.imgur.com/yMiXAGo.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sangre Montera[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_92+"/",
        thumbnail="https://i.imgur.com/ltPfmtS.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sangre Montera II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_93+"/",
        thumbnail="https://i.imgur.com/QiuLWvU.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sedientos de Pesca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_34+"/",
        thumbnail="https://i.imgur.com/fundpkc.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Senderos De Pesca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_29+"/",
        thumbnail="https://i.imgur.com/Nqml52l.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Señuelos De Pesca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_94+"/",
        thumbnail="https://i.imgur.com/ZUkvHp4.png",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sesiones De Pesca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_95+"/",
        thumbnail="https://i.imgur.com/CVvKabK.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Skyline Hunters[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_96+"/",
        thumbnail="https://i.imgur.com/wpDogeg.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sol Montero[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_97+"/",
        thumbnail="https://i.imgur.com/LmF3OiT.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sol Montero II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_98+"/",
        thumbnail="https://i.imgur.com/QdqYHzg.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Surfcasting[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_30+"/",
        thumbnail="https://i.imgur.com/OeedYZU.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Surfcasting II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_31+"/",
        thumbnail="https://i.imgur.com/k4uWsPq.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tailwalk[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_99+"/",
        thumbnail="https://i.imgur.com/rfNnLCh.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tecnopesca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_32+"/",
        thumbnail="https://i.imgur.com/aJioY1n.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Trucos y Tips De Pesca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_58+"/",
        thumbnail="https://i.imgur.com/LjIip4r.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tutoriales De Pesca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_100+"/",
        thumbnail="https://i.imgur.com/zsE9Euf.jpg",
		fanart="https://i.imgur.com/vb2fT2H.jpg",
        folder=True )	
		
run()