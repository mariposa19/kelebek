# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Thanks to the Authors of the base code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# modified by: MUSICHALL
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.BodyGym'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_search = "cGx1Z2luOi8vcGx1Z2luLnZpZGVvLnlvdXR1YmUva29kaW9uL3NlYXJjaC9saXN0Lw==".decode('base64')
YOUTUBE_playlist_ID_0 = "PLSyCRkPeE-W0-d3ALf-l-W-6t--2tw1Ch"
YOUTUBE_playlist_ID_1 = "PLrFkZrRQk9nlh4m37RhyVPcIXXRqjKGHb"    
YOUTUBE_playlist_ID_2 = "PLgw-IX-r_o5i16wMzWx38Pl4cqPWU27r6"   
YOUTUBE_playlist_ID_3 = "PLn0lBRjLQvKyvYnarOt1IKvzzSYRjNMl5"    
YOUTUBE_playlist_ID_4 = "PL39i3Vjpjb08Y_ZnIWAGlGIa4mAwT6H48"    
YOUTUBE_playlist_ID_5 = "PLzv0oBdePNMc4cXk0QneCRYkG96Wf3aiH"    
YOUTUBE_playlist_ID_6 = "PLsKsNq_6WouXGX0AHj14GI6bG0DYGcDrK"    
YOUTUBE_playlist_ID_7 = "PL-K6EIIBt9McPeR4kJjW6QMHD01Zt41RW"    
YOUTUBE_playlist_ID_8 = "PLn7X7_tj-QEcuRfDEkVsUNbU4g9LoIYx-"    
YOUTUBE_playlist_ID_9 = "PLbRtZNnbFbf7VlMLgvWnsZAYiz7fNKdyO"    
YOUTUBE_playlist_ID_10 = "PLWfhvETYMhMrTrSkCzQu-MdqMXVf9rDDM"   
YOUTUBE_playlist_ID_11 = "PLpHFmxgUdBGgT6rToIHoIevUtBxnP4f4H"   
YOUTUBE_playlist_ID_12 = "PL09C00CBF17D36B03"   
YOUTUBE_playlist_ID_13 = "PLzP6SQWaMdEa0iR0imrlgvgxrePV9bAYr"   
YOUTUBE_playlist_ID_14 = "PL3lkz80rnMQkI7KWXeDSVZgw5gmg0PyK-"   
YOUTUBE_playlist_ID_15 = "PLpttPcEO_QcIFQBlWstBMeeZSFJQ-kpN1"   
YOUTUBE_playlist_ID_16 = "PLxnLVl3jgijgabyOoboBuEhWE07nJpURH"   
YOUTUBE_playlist_ID_17 = "PLNH7cFJ42PKgf9p1MV74wgnLSHLORn88Y"   
YOUTUBE_playlist_ID_18 = "PLIJyn_tZQrGp8NljBPwNlncCzZTduRX1p"   
YOUTUBE_playlist_ID_19 = "PLS-3sw3QisKy4ommwriz3oL0-L6x5zF42"   
YOUTUBE_playlist_ID_20 = "PL-WHuiw9GA8AyFjQReW9UBhDJeiR-lOf4"   
YOUTUBE_playlist_ID_21 = "PLLDGR3oksU6-pFaGFWkIsYBxMLOqn9bf0"   
YOUTUBE_playlist_ID_22 = "PLNH7cFJ42PKioTF42lJeMblG9uTgs6cM8"   
YOUTUBE_playlist_ID_23 = "PLc6y_bIejLFGuGnkHi2RDgke4eGtJyhRE"   
YOUTUBE_playlist_ID_24 = "PLCBF6A72568A4CF5E"   
YOUTUBE_playlist_ID_25 = "PLReDUkUQG7xqf3F1wIvh9R88uj1Oo0KKc"   
YOUTUBE_playlist_ID_26 = "PLn7X7_tj-QEfFEgWt7yw5s6Su0eof2IRk"   
YOUTUBE_playlist_ID_27 = "PLReDUkUQG7xrb6vRzitNGqrkljvwZHV1G"   
YOUTUBE_playlist_ID_28 = "PLNH7cFJ42PKhZnASpf887GA2JOpPeFdqO"   
YOUTUBE_playlist_ID_29 = "PLRrRxpO0Dnz_7Tvy-wJ3edNzk8oZVmTau"  
YOUTUBE_playlist_ID_30 = "PLa8EHcfhW54T_Kpyzp3lDkLBsOdWYRfrc"
YOUTUBE_playlist_ID_31 = "PLY-df9CITWThfNOfmSUD3hyxiWRTBDhMM"   
YOUTUBE_playlist_ID_32 = "PLte_bhQL1wNKnSBKUF2xlVgjF9RuShrRS"  
YOUTUBE_playlist_ID_33 = "PLMBbhSHFpT53XFaPuaQ9IoUunng8ZtMYY"   
YOUTUBE_playlist_ID_34 = "PLlCzCgLagQzcZonGcO-LeMkumIoHGsUWw"   
YOUTUBE_playlist_ID_35 = "PLuB7IAg8o8f28041A_ojeahs0ko3ntC7j"   
YOUTUBE_playlist_ID_36 = "PLibxrrGuY6F3gKvT-ED4qYUtttyDDeSdS"   
YOUTUBE_playlist_ID_37 = "PLMtZWDHBg-nK0NEnXGZz2LotFnzU0a_4N"   
YOUTUBE_playlist_ID_38 = "PLNH7cFJ42PKgLjjX36-gC9-e47YtpTUik"   
YOUTUBE_playlist_ID_39 = "PLuB7IAg8o8f1VMAUTbtbaB5uDqIAArqgu"  
YOUTUBE_playlist_ID_40 = "PLvMfTblQXhEY8csdtSKOtge68K_O-tNXV"   
YOUTUBE_playlist_ID_41 = "PLnuO97a4tN8dAY869GUrk6BLOaMgb-tIE"   
YOUTUBE_playlist_ID_42 = "PL4TJ3zMgZrObnpP0O0GZxvR6fudXgEfcP"   
YOUTUBE_playlist_ID_43 = "PLWNdjXigLxSp3h6UwfE_UQZeK1-FIE99e"   
YOUTUBE_playlist_ID_44 = "PLoYH53Q5tOSwDFNjvN_geo6B0DsuNyy2r"   
YOUTUBE_playlist_ID_45 = "PLfuFELHuiQBJ-q6gHshaEEkiixFzeol3a"  
YOUTUBE_playlist_ID_46 = "PLHGzEmdHkckUwhjD7mkmvICQAeE_0ZTo4"   
YOUTUBE_playlist_ID_47 = "PL4RqReNb-NLYkcxtUTrr3XWutNlvcm_5y"   
YOUTUBE_playlist_ID_48 = "PLNH7cFJ42PKgzd6ZeKndUuMg62fM1hOfi"   
YOUTUBE_playlist_ID_49 = "PLhwSegX4_pptAL8OaTsHWo1dWGsHwe1VW"   
YOUTUBE_playlist_ID_50 = "PLU6SGFG-8lVnG_mkbs3c7KYyn8iKkPKeA"  
YOUTUBE_playlist_ID_51 = "PLlIiNdsyAwjsC5PhsjWshBqAfDM-sjVll"   
YOUTUBE_playlist_ID_52 = "PLFC7VxOiNi4j7EkEQeS8MMb3E8NOMXSf5"   
YOUTUBE_playlist_ID_53 = "PLFC7VxOiNi4i-DD_OUkrlhlzck26MqpW5"   
YOUTUBE_playlist_ID_54 = "PLAF1zXyqmF6Ylg0VteSh3YSv-CZtMR4q4"   
YOUTUBE_playlist_ID_55 = "PL9EFHeQqoLmt8V-D_CTzu4lXhKL3LyoTd"  
YOUTUBE_playlist_ID_56 = "PLd3iKwoSIi5Yvl4EKrDWHXkAE9Cb9zeJ7"   
YOUTUBE_playlist_ID_57 = "PLhqf8Cni5bsraFlM-hAN8UmD8e3tvwXWj"   
YOUTUBE_playlist_ID_58 = "PLsdhqmqbkMdEAK6-zM-IVASCRKFcG2_T-"   
YOUTUBE_playlist_ID_59 = "PLNH7cFJ42PKgukd310-JZFqohILOXScI4"   
YOUTUBE_playlist_ID_60 = "PLgLbVXgs4N17eiSx3de5XSu7q6ZPptLo_"  
YOUTUBE_playlist_ID_61 = "PLf4y2cZTKW4JXqaE-vkNwFIlOf_gxuMa8"   
YOUTUBE_playlist_ID_62 = "PLS7xNOzIsqIQZDt5vNTmnZIs-MdJgFAjv"   
YOUTUBE_playlist_ID_63 = "PLoA6ZoBxYdF9x4uL1txJugpO2QdvZ5a_N"   
YOUTUBE_playlist_ID_64 = "PLGwit9F_pH9BFy-VG8_1dtepdr-sjU6w5"   
YOUTUBE_playlist_ID_65 = "PL1wgvJyner4aTTn5_HK3HGYLPU1DicRTH"  
YOUTUBE_playlist_ID_66 = "PLQrAIBFp_iv10yybHxF7-e9cEi-X1PkJI"   
YOUTUBE_playlist_ID_67 = "PLXZJorHzsGsjTe7431_K5R1MGOEZKSAw4"   
YOUTUBE_playlist_ID_68 = "PLUlm2pjCVPNbM1D_Uow6Mj0spgjnc2A4g"   
YOUTUBE_playlist_ID_69 = "PL0WoqmqGDiNdeGvNA9fhq9eAHIXeNeZh-"   
YOUTUBE_playlist_ID_70 = "PLekHkzQwbibjMuxId917eLWQE_t3AlsE9"  
YOUTUBE_playlist_ID_71 = "PLPCD1DnZQLhUiAyKTN2xbobrpl10iRsy5"   
YOUTUBE_playlist_ID_72 = "PLMcSqLTyaVACpR3ZbVURfnt1zKLQvLyPZ"   
YOUTUBE_playlist_ID_73 = "PLvxN7DSD3ewFt2fkR7uPTYkRBOk7Dn21j"   
YOUTUBE_playlist_ID_74 = "PLHGzEmdHkckWkkNJF-c-fHP6k8P7a-d_6"   
YOUTUBE_playlist_ID_75 = "PL5762B6EA3B526A53"  
YOUTUBE_playlist_ID_76 = "PL1vILOKro2gqKDA7vOoNluAHgE5n5HyBA"   
YOUTUBE_playlist_ID_77 = "PL465EA5E34E024AC9"   
YOUTUBE_playlist_ID_78 = "PL2Kw1lrt7hG-YFN7IcTKmfFdlyDAfNNT1"   
YOUTUBE_playlist_ID_79 = "PL_-E0DxtnTcpezfE7BqIyEeunTDmqvdav"   
YOUTUBE_playlist_ID_80 = "PLKEYx2LBRBymM_vZXKHzmZ-52-_dF5yGu"   
# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Body Gym Siguenos En El Grupo Telegram @AprendiendoKodi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_0+"/",
        thumbnail="https://i.imgur.com/Cl7mCGK.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Buscador[/COLOR]",
        url=YOUTUBE_search,
        thumbnail="https://i.imgur.com/Cl7mCGK.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Activate Con Pilates[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1+"/",
        thumbnail="https://i.imgur.com/Fe3TI73.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Aprende Defensa Personal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_46+"/",
        thumbnail="https://i.imgur.com/COTFqoI.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Bicicleta Estatica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_2+"/",
        thumbnail="https://i.imgur.com/DXsKf6v.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Body Tonic[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_47+"/",
        thumbnail="https://i.imgur.com/y544y2e.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Buff Academy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_31+"/",
        thumbnail="https://i.imgur.com/jv4Ml1Z.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Calendario de Entrenamiento[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_3+"/",
        thumbnail="https://i.imgur.com/7assBmC.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Calistenia y Workout[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_32+"/",
        thumbnail="https://i.imgur.com/JHoH1Ff.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Casa y Gym[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_4+"/",
        thumbnail="https://i.imgur.com/6CkuUy6.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Capoeira[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_5+"/",
        thumbnail="https://i.imgur.com/VduGTiz.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Cervicales, Lumbares y Espalda[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_48+"/",
        thumbnail="https://i.imgur.com/MXh8tDt.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Controla El Estres[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_49+"/",
        thumbnail="https://i.imgur.com/0FzChlJ.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Cuerpo y Mente Sanos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_50+"/",
        thumbnail="https://i.imgur.com/9UOEAlP.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Curso de Fitness[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_6+"/",
        thumbnail="https://i.imgur.com/USENJp3.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Curso De Reiki Nivel 1[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_51+"/",
        thumbnail="https://i.imgur.com/aJJQ0a2.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Defensa Personal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_7+"/",
        thumbnail="https://i.imgur.com/DsjKag8.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Ejercicios Basicos En Casa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_35+"/",
        thumbnail="https://i.imgur.com/dePBrVs.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Ejercicios Completos Femeninos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_33+"/",
        thumbnail="https://i.imgur.com/7KIzkrB.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Ejercicios Con Pesas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_52+"/",
        thumbnail="https://i.imgur.com/TjD2aEE.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Ejercicios De Flexibilidad[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_53+"/",
        thumbnail="https://i.imgur.com/iDbbhNt.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Ejercicios De Piernas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_54+"/",
        thumbnail="https://i.imgur.com/8dzs8nG.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Ejercicios De Relajacion[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_55+"/",
        thumbnail="https://i.imgur.com/Y27ENP7.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Ejercicios En Casa II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_34+"/",
        thumbnail="https://i.imgur.com/gYevhfQ.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Ejercicios Para Marcar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_36+"/",
        thumbnail="https://i.imgur.com/dOxlpJz.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Ejercicios Para Mayores De 50 Años[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_37+"/",
        thumbnail="https://i.imgur.com/5ClcExW.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Entrena en Casa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_8+"/",
        thumbnail="https://i.imgur.com/uJJfVhr.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Entrenamiento Fisico Kung Fu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_56+"/",
        thumbnail="https://i.imgur.com/zAUFP9G.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Entrenamiento Funcional[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_9+"/",
        thumbnail="https://i.imgur.com/T8QOEJB.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Entrenos Artes Marciales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_57+"/",
        thumbnail="https://i.imgur.com/NZuV5pf.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Entrenos Efectivos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_10+"/",
        thumbnail="https://i.imgur.com/wJbbISx.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Ejercicios En Casa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_11+"/",
        thumbnail="https://i.imgur.com/H7ePABv.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Entrenamiento Para Principiantes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_12+"/",
        thumbnail="https://i.imgur.com/jAwRgMS.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Ejercicios Variados[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_13+"/",
        thumbnail="https://i.imgur.com/xrlnwma.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Fitness[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_14+"/",
        thumbnail="https://i.imgur.com/WeeDwgo.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Fitness II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_15+"/",
        thumbnail="https://i.imgur.com/cVm2TxS.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Fitball[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_16+"/",
        thumbnail="https://i.imgur.com/iBPLJEw.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Fitball II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_17+"/",
        thumbnail="https://i.imgur.com/rPFUFD8.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Gimnasia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_18+"/",
        thumbnail="https://i.imgur.com/WcPDC0Y.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Inicio Al Boxeo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_58+"/",
        thumbnail="https://i.imgur.com/ATSlXAY.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Krav Maga[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_19+"/",
        thumbnail="https://i.imgur.com/MRcOOwB.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Krav Maga II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_20+"/",
        thumbnail="https://i.imgur.com/XjHGro5.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Medio Ironman[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_21+"/",
        thumbnail="https://i.imgur.com/M9oZyjv.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Meditacion[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_59+"/",
        thumbnail="https://i.imgur.com/h0dSrOK.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Meditacion Guiada[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_60+"/",
        thumbnail="https://i.imgur.com/VSVroWu.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Mega 5 Semanas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_22+"/",
        thumbnail="https://i.imgur.com/LIQ4U6m.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Muevete En Casa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_23+"/",
        thumbnail="https://i.imgur.com/cWfMiS2.png",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Mujeres Artes Marciales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_61+"/",
        thumbnail="https://i.imgur.com/K8Ms4ve.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Pilates[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_24+"/",
        thumbnail="https://i.imgur.com/DvlUZrV.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Progama 30 Dias[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_38+"/",
        thumbnail="https://i.imgur.com/59B2nK4.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Ridu Fitness Para Adolescentes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_39+"/",
        thumbnail="https://i.imgur.com/dqqxw29.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Rutinas 50 Minutos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_40+"/",
        thumbnail="https://i.imgur.com/XJ0k6F7.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Rutinas Cuadriceps, Gluteos, etc[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_62+"/",
        thumbnail="https://i.imgur.com/mCpVFxW.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Rutinas Deportivas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_63+"/",
        thumbnail="https://i.imgur.com/MccLM1y.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Rutinas De Cardio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_25+"/",
        thumbnail="https://i.imgur.com/wRI4YA8.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Rutinas Ejercicios En Casa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_64+"/",
        thumbnail="https://i.imgur.com/Pjz6afP.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Rutinas En Casa Para Principiantes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_41+"/",
        thumbnail="https://i.imgur.com/Tgen5i0.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Rutinas Gym[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_42+"/",
        thumbnail="https://i.imgur.com/GxsyL01.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Rutinas Para Todo El Cuerpo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_43+"/",
        thumbnail="https://i.imgur.com/tlAJW94.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Rutinas Rapidas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_44+"/",
        thumbnail="https://i.imgur.com/FAJV1q2.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Rutinas Sin Implementos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_26+"/",
        thumbnail="https://i.imgur.com/x9D9z66.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Rutinas Total Body[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_27+"/",
        thumbnail="https://i.imgur.com/8Owj8oT.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Rutinas y Ejercicios De Calistenia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_45+"/",
        thumbnail="https://i.imgur.com/lv25hrj.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Sesiones Completas De Boxeo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_65+"/",
        thumbnail="https://i.imgur.com/YjCAhN5.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Tai Chi En Casa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_66+"/",
        thumbnail="https://i.imgur.com/oqLhZ5b.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Tai Chi y Chi Kung[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_67+"/",
        thumbnail="https://i.imgur.com/BmFs77b.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Tapout XT[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_68+"/",
        thumbnail="https://i.imgur.com/UljCA47.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Tecnica Boxing[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_69+"/",
        thumbnail="https://i.imgur.com/2r3IAcv.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Tecnica De Relajacion[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_70+"/",
        thumbnail="https://i.imgur.com/1yZC6QS.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Tecnica De Relajacion Jacobson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_71+"/",
        thumbnail="https://i.imgur.com/kn48J1o.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Tecnica De Respiracion[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_72+"/",
        thumbnail="https://i.imgur.com/JakcTwM.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Tecnica Shaolin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_73+"/",
        thumbnail="https://i.imgur.com/hKOI0VQ.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Tutoriales Artes Marciales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_74+"/",
        thumbnail="https://i.imgur.com/rpSi0y7.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Yoga Para Principiantes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_28+"/",
        thumbnail="https://i.imgur.com/xf3KzA7.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Yoga Para Embarazadas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_75+"/",
        thumbnail="https://i.imgur.com/KIlxhph.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Yoga Para Relajacion[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_76+"/",
        thumbnail="https://i.imgur.com/hTa9vbf.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Yoga Para Todos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_77+"/",
        thumbnail="https://i.imgur.com/O4YbbX1.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Yoga Postparto[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_78+"/",
        thumbnail="https://i.imgur.com/BKqqNtc.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Yuri Boyka[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_79+"/",
        thumbnail="https://i.imgur.com/gS7Zpje.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Zhineng QiGong[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_80+"/",
        thumbnail="https://i.imgur.com/FCaPGpC.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Zumba Strong[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_29+"/",
        thumbnail="https://i.imgur.com/pNRVGaX.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Zumba Strong II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_30+"/",
        thumbnail="https://i.imgur.com/ZmTlCaw.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )
		
run()