# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Thanks to the Authors of the base code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# modified by: MUSICHALL
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.BodyGym'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_playlist_ID_1 = "PLrFkZrRQk9nlh4m37RhyVPcIXXRqjKGHb"    
YOUTUBE_playlist_ID_2 = "PLgw-IX-r_o5i16wMzWx38Pl4cqPWU27r6"   
YOUTUBE_playlist_ID_3 = "PLn0lBRjLQvKyvYnarOt1IKvzzSYRjNMl5"    
YOUTUBE_playlist_ID_4 = "PL39i3Vjpjb08Y_ZnIWAGlGIa4mAwT6H48"    
YOUTUBE_playlist_ID_5 = "PLzv0oBdePNMc4cXk0QneCRYkG96Wf3aiH"    
YOUTUBE_playlist_ID_6 = "PLsKsNq_6WouXGX0AHj14GI6bG0DYGcDrK"    
YOUTUBE_playlist_ID_7 = "PL-K6EIIBt9McPeR4kJjW6QMHD01Zt41RW"    
YOUTUBE_playlist_ID_8 = "PLn7X7_tj-QEcuRfDEkVsUNbU4g9LoIYx-"    
YOUTUBE_playlist_ID_9 = "PLbRtZNnbFbf7VlMLgvWnsZAYiz7fNKdyO"    
YOUTUBE_playlist_ID_10 = "PLWfhvETYMhMrTrSkCzQu-MdqMXVf9rDDM"   
YOUTUBE_playlist_ID_11 = "PLpHFmxgUdBGgT6rToIHoIevUtBxnP4f4H"   
YOUTUBE_playlist_ID_12 = "PL09C00CBF17D36B03"   
YOUTUBE_playlist_ID_13 = "PLzP6SQWaMdEa0iR0imrlgvgxrePV9bAYr"   
YOUTUBE_playlist_ID_14 = "PL3lkz80rnMQkI7KWXeDSVZgw5gmg0PyK-"   
YOUTUBE_playlist_ID_15 = "PLpttPcEO_QcIFQBlWstBMeeZSFJQ-kpN1"   
YOUTUBE_playlist_ID_16 = "PLxnLVl3jgijgabyOoboBuEhWE07nJpURH"   
YOUTUBE_playlist_ID_17 = "PLNH7cFJ42PKgf9p1MV74wgnLSHLORn88Y"   
YOUTUBE_playlist_ID_18 = "PLIJyn_tZQrGp8NljBPwNlncCzZTduRX1p"   
YOUTUBE_playlist_ID_19 = "PLS-3sw3QisKy4ommwriz3oL0-L6x5zF42"   
YOUTUBE_playlist_ID_20 = "PL-WHuiw9GA8AyFjQReW9UBhDJeiR-lOf4"   
YOUTUBE_playlist_ID_21 = "PLLDGR3oksU6-pFaGFWkIsYBxMLOqn9bf0"   
YOUTUBE_playlist_ID_22 = "PLNH7cFJ42PKioTF42lJeMblG9uTgs6cM8"   
YOUTUBE_playlist_ID_23 = "PLc6y_bIejLFGuGnkHi2RDgke4eGtJyhRE"   
YOUTUBE_playlist_ID_24 = "PLCBF6A72568A4CF5E"   
YOUTUBE_playlist_ID_25 = "PLReDUkUQG7xqf3F1wIvh9R88uj1Oo0KKc"   
YOUTUBE_playlist_ID_26 = "PLn7X7_tj-QEfFEgWt7yw5s6Su0eof2IRk"   
YOUTUBE_playlist_ID_27 = "PLReDUkUQG7xrb6vRzitNGqrkljvwZHV1G"   
YOUTUBE_playlist_ID_28 = "PLNH7cFJ42PKhZnASpf887GA2JOpPeFdqO"   
YOUTUBE_playlist_ID_29 = "PLRrRxpO0Dnz_7Tvy-wJ3edNzk8oZVmTau"  
YOUTUBE_playlist_ID_30 = "PLa8EHcfhW54T_Kpyzp3lDkLBsOdWYRfrc"   
# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Activate Con Pilates[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1+"/",
        thumbnail="https://i.imgur.com/Fe3TI73.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Bicicleta Estatica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_2+"/",
        thumbnail="https://i.imgur.com/DXsKf6v.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Calendario de Entrenamiento[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_3+"/",
        thumbnail="https://i.imgur.com/7assBmC.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Casa y Gym[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_4+"/",
        thumbnail="https://i.imgur.com/6CkuUy6.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Capoeira[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_5+"/",
        thumbnail="https://i.imgur.com/VduGTiz.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Curso de Fitness[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_6+"/",
        thumbnail="https://i.imgur.com/USENJp3.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Defensa Personal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_7+"/",
        thumbnail="https://i.imgur.com/DsjKag8.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Entrena en Casa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_8+"/",
        thumbnail="https://i.imgur.com/uJJfVhr.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Entrenamiento Funcional[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_9+"/",
        thumbnail="https://i.imgur.com/T8QOEJB.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Entrenos Efectivos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_10+"/",
        thumbnail="https://i.imgur.com/wJbbISx.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Ejercicios En Casa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_11+"/",
        thumbnail="https://i.imgur.com/H7ePABv.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Entrenamiento Para Principiantes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_12+"/",
        thumbnail="https://i.imgur.com/jAwRgMS.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Ejercicios Variados[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_13+"/",
        thumbnail="https://i.imgur.com/xrlnwma.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Fitness[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_14+"/",
        thumbnail="https://i.imgur.com/WeeDwgo.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Fitness II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_15+"/",
        thumbnail="https://i.imgur.com/cVm2TxS.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Fitball[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_16+"/",
        thumbnail="https://i.imgur.com/iBPLJEw.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Fitball II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_17+"/",
        thumbnail="https://i.imgur.com/rPFUFD8.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Gimnasia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_18+"/",
        thumbnail="https://i.imgur.com/WcPDC0Y.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Krav Maga[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_19+"/",
        thumbnail="https://i.imgur.com/MRcOOwB.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Krav Maga II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_20+"/",
        thumbnail="https://i.imgur.com/XjHGro5.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Medio Ironman[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_21+"/",
        thumbnail="https://i.imgur.com/M9oZyjv.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Mega 5 Semanas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_22+"/",
        thumbnail="https://i.imgur.com/LIQ4U6m.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Muevete En Casa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_23+"/",
        thumbnail="https://i.imgur.com/cWfMiS2.png",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Pilates[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_24+"/",
        thumbnail="https://i.imgur.com/DvlUZrV.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Rutinas de Cardio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_25+"/",
        thumbnail="https://i.imgur.com/wRI4YA8.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Rutinas Sin Implementos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_26+"/",
        thumbnail="https://i.imgur.com/x9D9z66.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Rutinas Total Body[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_27+"/",
        thumbnail="https://i.imgur.com/8Owj8oT.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Yoga Para Principiantes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_28+"/",
        thumbnail="https://i.imgur.com/xf3KzA7.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Zumba Strong[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_29+"/",
        thumbnail="https://i.imgur.com/pNRVGaX.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR pink]Zumba Strong II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_30+"/",
        thumbnail="https://i.imgur.com/ZmTlCaw.jpg",
		fanart="https://i.imgur.com/jvGsrYC.jpg",
        folder=True )
		
run()