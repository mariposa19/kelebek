# plugin.program.iptv.merge

Easily merge multiple IPTV playlists &amp; EPGs from remote or local sources.

https://www.matthuisman.nz/2019/02/iptv-merge-kodi-add-on.html
