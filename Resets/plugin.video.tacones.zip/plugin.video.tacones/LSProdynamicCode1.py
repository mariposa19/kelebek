# -*- coding: utf-8 -*-
#$pyFunction
def GetLSProData(page_data,Cookie_Jar,m):
    import xbmcgui
    dialog = xbmcgui.Dialog()
    ret = dialog.select('Ver con:', ['Elementum' ,  'Quasar'])
    channels = [
'plugin://plugin.video.elementum/play?uri=magnet:?xt=urn:btih:e1becd1579016f615f122b127b25bf089940d909',
'plugin://plugin.video.quasar/play?uri=magnet:?xt=urn:btih:e1becd1579016f615f122b127b25bf089940d909'] 

    return channels[ret]
