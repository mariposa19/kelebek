# -*- coding: utf-8 -*-
#$pyFunction
import re,requests
def GetLSProData(page_data,Cookie_Jar,m):
  count=3;pn=1;data=[]
  while pn <= int(count):
     page='https://www.ojomovies.com/subcategoria/35/'+str(pn)+'';source=requests.get(page).content.decode('ascii','ignore')
     data +=re.findall('(?s)class="litodaspelis">.*?href="/pelicula/(.*?)">.*?title="(.*?)".*?original="(.*?)".*?',source);pn +=1
  return data
