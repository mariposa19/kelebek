# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Sourced From Online Templates And Guides
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Thanks To: Google Search For This Template
# Modified: Pulse
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.MusicHall'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

xbmc.executebuiltin('Container.SetViewMode(500)')

YOUTUBE_CHANNEL_ID_1 = "PLSyCRkPeE-W0Yd6UutqVt7jKgsrSWwBnc"
YOUTUBE_CHANNEL_ID_2 = "PLSyCRkPeE-W26b_hGZIoO7XfsH3licNU2"
YOUTUBE_CHANNEL_ID_3 = "PL4o29bINVT4EG_y-k5jGoOu3-Am8Nvi10"
YOUTUBE_CHANNEL_ID_4 = "PLMC9KNkIncKtPzgY-5rmhvj7fax8fdxoj"
YOUTUBE_CHANNEL_ID_5 = "PLe_mU5sgHnNTzIMMSz7JsyXLFDcrMW0Ep"
YOUTUBE_CHANNEL_ID_6 = "PLB8HqqmpyIBcPirb5lDm-ol01trE6dOuM"
YOUTUBE_CHANNEL_ID_7 = "PL3485902CC4FB6C67"
YOUTUBE_CHANNEL_ID_8 = "PLZN_exA7d4RVmCQrG5VlWIjMOkMFZVVOc"
YOUTUBE_CHANNEL_ID_9 = "PLhd1HyMTk3f5PzRjJzmzH7kkxjfdVoPPj"
YOUTUBE_CHANNEL_ID_10 = "PL6Lt9p1lIRZ311J9ZHuzkR5A3xesae2pk"
YOUTUBE_CHANNEL_ID_11 = "PL_86NZWyc0FsJF98CRytnzItb5EXMQOne"
YOUTUBE_CHANNEL_ID_12 = "PL7dWoRZfPDhp9Zh9hGlAM6uYn7QYz9zE"
YOUTUBE_CHANNEL_ID_13 = "PLT97TNIfVc4k6u4vhaUHlnejTwnCuCBCe"
YOUTUBE_CHANNEL_ID_14 = "PL7v1FHGMOadAnIzTEHrAaZhGyXzcDOk79"
YOUTUBE_CHANNEL_ID_15 = "PL4XLEC-MUq2uP2OhrGWdOErGUDrEquhqi"
YOUTUBE_CHANNEL_ID_16 = "PLOuAaPDGy5br7qCO28VX5AzTq4_hmGKDX"
YOUTUBE_CHANNEL_ID_17 = "PLo3pNg0eiPc_jQ_jhD8P4UoiOE6vmGdU6"
YOUTUBE_CHANNEL_ID_18 = "PLdS6GqghzS68QVNnOSU2_MSmTFbeLLMjp"
YOUTUBE_CHANNEL_ID_19 = "PLSYbV1H4VkCcHi33SC1mldSDi8vrYlfCm"
YOUTUBE_CHANNEL_ID_20 = "PL1av4CQniLB0dk5LnfWQhBUcRlzo2jBYB"
YOUTUBE_CHANNEL_ID_21 = "PLFE06A24F924AADB0"
YOUTUBE_CHANNEL_ID_22 = "PLw6p6PA8M2miu0w4K1g6vQ1BHUBeyM4"
YOUTUBE_CHANNEL_ID_23 = "PLNjVKDn-Jmf6MJ56EPkd0qtYjml3nkQ4X"
YOUTUBE_CHANNEL_ID_24 = "PL11Wnnyw47LpkF3McMjHwG0HZ23CcfYUX"
YOUTUBE_CHANNEL_ID_25 = "PLD15AF3F721D9841B"
YOUTUBE_CHANNEL_ID_26 = "PLA_I2ay5YcUUKiZshI4cgp9fTOS-Q6B1E"
YOUTUBE_CHANNEL_ID_27 = "PLGUwEHGA8vYx5f9h7kBX-7ajQ4l2dz5Np"
YOUTUBE_CHANNEL_ID_28 = "PLz1LeT5FVsBsZYX2J5yhW8tHuTsRdlAKb"
YOUTUBE_CHANNEL_ID_29 = "PL3eLsFJDQqDeoCf4U6v4WqJpIem9wPsuB"
YOUTUBE_CHANNEL_ID_30 = "PL3OPG8Q1fcHfckwr3RJjEFdC17plumnrk"
YOUTUBE_CHANNEL_ID_31 = "PL0cR6Rwd6cZ_NFddNfqUY9Pr-tdua1hH-"
YOUTUBE_CHANNEL_ID_32 = "PLdSAKz5rcwnzE7ahB8I1B1uf32ZcAA4Xp"
YOUTUBE_CHANNEL_ID_33 = "PL54835teYYB6TXx0j37rArlHeS2Nzi9Fw"
YOUTUBE_CHANNEL_ID_34 = "PLVwXkzK42QWpYvaIk_g7RpNyN0v_mDys1"
YOUTUBE_CHANNEL_ID_35 = "PLg0miFvQna78NnuHxMGgGomvhx7AzPsrq"
YOUTUBE_CHANNEL_ID_36 = "PLcM4ZwI542CriszmMjt8HSOJ-dVzKo3O3"
YOUTUBE_CHANNEL_ID_37 = "PL20422B75F11401A9"
YOUTUBE_CHANNEL_ID_38 = "PLC90FB71F6ECE17F3"
YOUTUBE_CHANNEL_ID_39 = "PL08MW4hWrm0IgjVeAiyONMnXGi6XIXX_8"
YOUTUBE_CHANNEL_ID_40 = "PLFB42B657AC475437"
YOUTUBE_CHANNEL_ID_41 = "PLi7ihgkEws7S0Dwxxyxb7SJyd2FU5VaoX"
YOUTUBE_CHANNEL_ID_42 = "PL4ED12F0E006F3FB5"
YOUTUBE_CHANNEL_ID_43 = "PLH3uWI-RMnujGh1_eWrxjeJlOs8LsFW2a"
YOUTUBE_CHANNEL_ID_44 = "PLUB47gDSghxHXzrES8stEO1IoUWNaDtjo"
YOUTUBE_CHANNEL_ID_45 = "PLoc2h0J0pKbjKURh9b0XGfHkMMQIEqx3j"
YOUTUBE_CHANNEL_ID_46 = "PLMdr_HKbn4ph0bMRzVkPdiLtPLC0xwHQv"
YOUTUBE_CHANNEL_ID_47 = "PLkqz3S84Tw-TgiHX8wa-bFAscdC-0pe1k"
YOUTUBE_CHANNEL_ID_48 = "PLlD0ifA9koz8HDvUpo3gE63iNYC_GPp4i"
YOUTUBE_CHANNEL_ID_49 = "PLSYbV1H4VkCcF4nR9pimgJl9n2YCtiJCm"
YOUTUBE_CHANNEL_ID_50 = "PLxI6IWh7Z6boU_sZm25NTBxPI2tS5ODko"
YOUTUBE_CHANNEL_ID_51 = "PL8F6B0753B2CCA128"
YOUTUBE_CHANNEL_ID_52 = "PL2140A0411C65DD13"
YOUTUBE_CHANNEL_ID_53 = "PLPbMT4wSxX88oU7uYThLcvUI98PUp1bQ2"
YOUTUBE_CHANNEL_ID_54 = "PLSYbV1H4VkCeCiimiKQ7VijAAHiDoE134"
YOUTUBE_CHANNEL_ID_55 = "PLTC7VQ12-9rZRMqzpt9t69WxbcBBcMA5N"
YOUTUBE_CHANNEL_ID_56 = "PLYAYp5OI4lRLf_oZapf5T5RUZeUcF9eRO"
YOUTUBE_CHANNEL_ID_57 = "PLOzQFWHEFankpJykvzRJ6W5mF81ojL9I5"
YOUTUBE_CHANNEL_ID_58 = "PLinS5uF49IBrTL7y97OOWRilvdv9RCtD5"
YOUTUBE_CHANNEL_ID_59 = "PLk-_AvR22RueziRgt5GVuirih223y1UNJ"
YOUTUBE_CHANNEL_ID_60 = "PLxhnpe8pN3TmtjcQM7zcYAKhQXPdOHS3Y"
YOUTUBE_CHANNEL_ID_61 = "PL_htyEpQ9NirGqcnTjexvkL1FgdAb1DIP"
YOUTUBE_CHANNEL_ID_62 = "PLKl-ToKj7DF79wPmya9szDKHU548iKw7N"
YOUTUBE_CHANNEL_ID_63 = "PLwY9l4M25GOJqIx-Dn-PmYs1KjPd80-1N"
YOUTUBE_CHANNEL_ID_64 = "PLYVjGTi85afrX2JuWV2_ylym4ykyguiSn"
YOUTUBE_CHANNEL_ID_65 = "PLuIIZwlpW-BDRwb_Djx47oKDPwSTo37il"
YOUTUBE_CHANNEL_ID_66 = "PLZ_Hv3CS1vLczLHKKZ-k-YAtt_BocRXjl"
YOUTUBE_CHANNEL_ID_67 = "PLUTHONkXwksFV41KpZRHS0g7wAUsXNWi1"
YOUTUBE_CHANNEL_ID_68 = "PLoSFsEOMUSmvu78SR8lpN9qPfhcWlJoh4"
YOUTUBE_CHANNEL_ID_69 = "PL5xAy4Ufl2T7W9KJHMIZ1zsyeKxFWF1WI"
YOUTUBE_CHANNEL_ID_70 = "PL6E0fb5idtvomtP6HmaXrIxQM_5dq1Ich"
# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))
	
    plugintools.add_item( 
        #action="", 
        title="Pide  Tu Cancion Aqui en MUSIC HALL",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Pide Tu Concierto aqui en Music Hall",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://i.imgur.com/6tbCPcq.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="POP Music  2020",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://i.imgur.com/bbN45sb.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Pop Music Lo Mejor de Todos los Tiempos 2020-2021",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://i.imgur.com/0eq7tXz.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Pop Latino Clasico",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="https://i.imgur.com/P5eJVmT.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Mix Internacional 2020-2021",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="https://i.imgur.com/i4avcbK.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="80s y 90s Rock",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="https://i.imgur.com/vOuU0yR.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Best Classic rock mix",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="https://i.imgur.com/ZvwVGKf.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Mejores Canciones Musica rock",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="https://i.imgur.com/iDA38r1.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Alternative rock of the 2000s",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="https://i.imgur.com/V1ZqiX9.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Clasicos del Rock en Español",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="https://i.imgur.com/KyVQSrI.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Chill Out",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="https://i.imgur.com/yTnsSPZ.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Chambao Chill Out",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="https://i.imgur.com/THq2a2S.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Mix Reggaeton 2020",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="https://i.imgur.com/G7HgD9Q.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Lo Mas Escuchado 2019-2020",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="https://i.imgur.com/AmoXCbH.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Musica Variada de Todo un Poco",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="https://i.imgur.com/RJ018Tm.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Musica Para Bailar",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="https://i.imgur.com/Ou7Kjmw.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Europa FM - Lista de Exitos 2020",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_18+"/",
        thumbnail="https://i.imgur.com/J75Rikb.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Top 50 España Exitos 2020",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_19+"/",
        thumbnail="https://i.imgur.com/OHUtwe0.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Pop Latino Mix 2020",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_20+"/",
        thumbnail="https://i.imgur.com/hcUe0tq.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Musica Clasica Instrumental",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_21+"/",
        thumbnail="https://i.imgur.com/VLFhuAJ.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Hard Rock 80s & 90s",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_22+"/",
        thumbnail="https://i.imgur.com/BlBjux5.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Lounge Music 2019",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_23+"/",
        thumbnail="https://i.imgur.com/JBBhJlm.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Chillout Lounge - Spotify",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_24+"/",
        thumbnail="https://i.imgur.com/CMhwl96.jpg",
        folder=True )
	
		
    plugintools.add_item( 
        #action="", 
        title="Guitarra Clasica Española",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_25+"/",
        thumbnail="https://i.imgur.com/HNHuitY.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="El mejor Flamenquito 2020",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_26+"/",
        thumbnail="https://i.imgur.com/r8XeyVC.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Mejores Canciones Rumba Flamenca Pop 2020-2021",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_27+"/",
        thumbnail="https://i.imgur.com/R5Cdma5.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Musica Española Flamenco Pop",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_28+"/",
        thumbnail="https://i.imgur.com/CPRNpCl.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Flamenco Pop Mix",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_29+"/",
        thumbnail="https://i.imgur.com/8OUagSi.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Cante Flamenco - Figuras del cante Jondo",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_30+"/",
        thumbnail="https://i.imgur.com/Tbi5AfE.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Fandangos y Cante Jondo",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_31+"/",
        thumbnail="https://i.imgur.com/Rf0hkuk.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Clasicos De La Musica Electronica",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_32+"/",
        thumbnail="https://i.imgur.com/GVH8gc0.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Conciertos en Directo",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_33+"/",
        thumbnail="https://i.imgur.com/D0e8euc.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Mejores Canciones de la Radio 2020",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_34+"/",
        thumbnail="https://i.imgur.com/s1eaBKA.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Spotify Playlist 2020",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_35+"/",
        thumbnail="https://i.imgur.com/MHnErB6.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Late 70s Soul Funk & Disco Music",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_36+"/",
        thumbnail="https://i.imgur.com/a1F1Guf.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Disco Funk Soul 70s 80s",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_37+"/",
        thumbnail="https://i.imgur.com/CEelwt2.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Disco Hits of the 70s 80s 90s",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_38+"/",
        thumbnail="https://i.imgur.com/Tp3VTg0.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Hits Dance 2020 2021 Classifica Mtv",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_39+"/",
        thumbnail="https://i.imgur.com/3ytyF7o.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Reggaeton Hits",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_40+"/",
        thumbnail="https://i.imgur.com/TRPvO7t.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Reggaeton 2019 Playlist & Latin Music",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_41+"/",
        thumbnail="https://i.imgur.com/L3SQ5YE.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Guitarra Clasica",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_42+"/",
        thumbnail="https://i.imgur.com/qWr7skf.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Los Mejores Exitos de Guitarra Española",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_43+"/",
        thumbnail="https://i.imgur.com/StuplSO.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Rock Instrumental de Guitarra Electrica",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_44+"/",
        thumbnail="https://i.imgur.com/j2skU30.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Musica Italiana top 80s-90s-00s",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_45+"/",
        thumbnail="https://i.imgur.com/15I8Syb.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Top Musica Italiana del Momento",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_46+"/",
        thumbnail="https://i.imgur.com/NP8qwiG.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Novedades POP en ESPAÑOL",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_47+"/",
        thumbnail="https://i.imgur.com/5Em3PAr.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Grandes Exitos de la Musica Indie en Español",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_48+"/",
        thumbnail="https://i.imgur.com/SgDCIxN.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Top Trap España 2020",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_49+"/",
        thumbnail="https://i.imgur.com/92HJf5u.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Top Mejores Canciones Español 2020",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_50+"/",
        thumbnail="https://i.imgur.com/X1fPsK3.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Top Jazz Classics Songs of All Time",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_51+"/",
        thumbnail="https://i.imgur.com/ThRjE2R.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Top Mejores Blues Blues-Rock  Jazz All Time",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_52+"/",
        thumbnail="https://i.imgur.com/nkIeyUi.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Best Women Jazz Music of All Time",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_53+"/",
        thumbnail="https://i.imgur.com/qPgX7rO.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Pop Español",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_54+"/",
        thumbnail="https://i.imgur.com/RBQnFAW.jpg",
        folder=True )
	
	
    plugintools.add_item( 
        #action="", 
        title="Lo Mejor del Reggae",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_56+"/",
        thumbnail="https://i.imgur.com/MLHdoft.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Reggae En Español",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_57+"/",
        thumbnail="https://i.imgur.com/XJzhCnd.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Musica Brasilera 2020 Lo Mas Escuchado",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_58+"/",
        thumbnail="https://i.imgur.com/ihMknfV.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Bossanova Canciones en Acustico",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_59+"/",
        thumbnail="https://i.imgur.com/d3kFnc1.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="MTV Greatest Hits",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_61+"/",
        thumbnail="https://i.imgur.com/77rD8gZ.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="MTV Top Hits",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_62+"/",
        thumbnail="https://i.imgur.com/I1ZjuSS.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Reggae Playlist",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_63+"/",
        thumbnail="https://i.imgur.com/RwoHeoK.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Boleros",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_64+"/",
        thumbnail="https://i.imgur.com/52v0FZO.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Las Mejores Rancheras",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_66+"/",
        thumbnail="https://i.imgur.com/g3D7PdH.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Rancheras Para El Recuerdo",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_67+"/",
        thumbnail="https://i.imgur.com/KT3IJGx.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Lo Mejor de La Zarzuela",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_68+"/",
        thumbnail="https://i.imgur.com/nhq4fNY.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Los Mejores Boleros de Todos los Tiempos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_65+"/",
        thumbnail="https://i.imgur.com/7B9EKjJ.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Pasodobles",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_69+"/",
        thumbnail="https://i.imgur.com/QBhm3w9.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Pop Rock Best of 1990 2020",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_55+"/",
        thumbnail="https://i.imgur.com/CFbI5Lb.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Copla Española",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_70+"/",
        thumbnail="https://i.imgur.com/FnIz7PG.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Mtv Top Songs 2020",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_60+"/",
        thumbnail="https://i.imgur.com/9W3ieuN.jpg",
        folder=True )		
run()