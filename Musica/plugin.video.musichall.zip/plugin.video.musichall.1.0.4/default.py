# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Thanks to the Authors of the base code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# modified by: MUSICHALL
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.musichall'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_playlist_ID_1 = "PLSyCRkPeE-W0Yd6UutqVt7jKgsrSWwBnc"    
YOUTUBE_playlist_ID_2 = "PLSyCRkPeE-W26b_hGZIoO7XfsH3licNU2"    
YOUTUBE_playlist_ID_3 = "PL4o29bINVT4EG_y-k5jGoOu3-Am8Nvi10"    
YOUTUBE_playlist_ID_4 = "PLMC9KNkIncKtPzgY-5rmhvj7fax8fdxoj"    
YOUTUBE_playlist_ID_5 = "PLe_mU5sgHnNTzIMMSz7JsyXLFDcrMW0Ep"    
YOUTUBE_playlist_ID_6 = "PLB8HqqmpyIBcPirb5lDm-ol01trE6dOuM"   
YOUTUBE_playlist_ID_7 = "PL3485902CC4FB6C67"    
YOUTUBE_playlist_ID_8 = "PLZN_exA7d4RVmCQrG5VlWIjMOkMFZVVOc"   
YOUTUBE_playlist_ID_9 = "PLhd1HyMTk3f5PzRjJzmzH7kkxjfdVoPPj"    
YOUTUBE_playlist_ID_10 = "PL6Lt9p1lIRZ311J9ZHuzkR5A3xesae2pk" 
YOUTUBE_playlist_ID_11 = "PL_86NZWyc0FsJF98CRytnzItb5EXMQOne"  
YOUTUBE_playlist_ID_12 = "PL7dWoRZfPDhp9Zh9hGlAM6uYn7QYz9zE"   
YOUTUBE_playlist_ID_13 = "PLT97TNIfVc4k6u4vhaUHlnejTwnCuCBCe"  
YOUTUBE_playlist_ID_14 = "PL7v1FHGMOadAnIzTEHrAaZhGyXzcDOk79"  
YOUTUBE_playlist_ID_15 = "PL4XLEC-MUq2uP2OhrGWdOErGUDrEquhqi"  
YOUTUBE_playlist_ID_16 = "PLOuAaPDGy5br7qCO28VX5AzTq4_hmGKDX"  
YOUTUBE_playlist_ID_17 = "PLo3pNg0eiPc_jQ_jhD8P4UoiOE6vmGdU6"  
YOUTUBE_playlist_ID_18 = "PLdS6GqghzS68QVNnOSU2_MSmTFbeLLMjp"  
YOUTUBE_playlist_ID_19 = "PLSYbV1H4VkCcHi33SC1mldSDi8vrYlfCm"   
YOUTUBE_playlist_ID_20 = "PL1av4CQniLB0dk5LnfWQhBUcRlzo2jBYB"   
YOUTUBE_playlist_ID_21 = "PLFE06A24F924AADB0"   
YOUTUBE_playlist_ID_22 = "PLw6p6PA8M2miu0w4K1g6vQ1BHUBeyM4"   
YOUTUBE_playlist_ID_23 = "PLNjVKDn-Jmf6MJ56EPkd0qtYjml3nkQ4X"  
YOUTUBE_playlist_ID_24 = "PL11Wnnyw47LpkF3McMjHwG0HZ23CcfYUX"  
YOUTUBE_playlist_ID_25 = "PLD15AF3F721D9841B"  
YOUTUBE_playlist_ID_26 = "PLA_I2ay5YcUUKiZshI4cgp9fTOS-Q6B1E"  
YOUTUBE_playlist_ID_27 = "PLGUwEHGA8vYx5f9h7kBX-7ajQ4l2dz5Np"  
YOUTUBE_playlist_ID_28 = "PLz1LeT5FVsBsZYX2J5yhW8tHuTsRdlAKb"  
YOUTUBE_playlist_ID_29 = "PL3eLsFJDQqDeoCf4U6v4WqJpIem9wPsuB"   
YOUTUBE_playlist_ID_30 = "PL3OPG8Q1fcHfckwr3RJjEFdC17plumnrk"   
YOUTUBE_playlist_ID_31 = "PL0cR6Rwd6cZ_NFddNfqUY9Pr-tdua1hH-"   
YOUTUBE_playlist_ID_32 = "PLdSAKz5rcwnzE7ahB8I1B1uf32ZcAA4Xp"  
YOUTUBE_playlist_ID_33 = "PL54835teYYB6TXx0j37rArlHeS2Nzi9Fw"  
YOUTUBE_playlist_ID_34 = "PLVwXkzK42QWpYvaIk_g7RpNyN0v_mDys1"   
YOUTUBE_playlist_ID_35 = "PLg0miFvQna78NnuHxMGgGomvhx7AzPsrq"  
YOUTUBE_playlist_ID_36 = "PLcM4ZwI542CriszmMjt8HSOJ-dVzKo3O3"   
YOUTUBE_playlist_ID_37 = "PL20422B75F11401A9"  
YOUTUBE_playlist_ID_38 = "PLC90FB71F6ECE17F3"  
YOUTUBE_playlist_ID_39 = "PL08MW4hWrm0IgjVeAiyONMnXGi6XIXX_8" 
YOUTUBE_playlist_ID_40 = "PLFB42B657AC475437"   
YOUTUBE_playlist_ID_41 = "PLi7ihgkEws7S0Dwxxyxb7SJyd2FU5VaoX"  
YOUTUBE_playlist_ID_42 = "PL4ED12F0E006F3FB5"  
YOUTUBE_playlist_ID_43 = "PLH3uWI-RMnujGh1_eWrxjeJlOs8LsFW2a"  
YOUTUBE_playlist_ID_44 = "PLUB47gDSghxHXzrES8stEO1IoUWNaDtjo"   
YOUTUBE_playlist_ID_45 = "PLoc2h0J0pKbjKURh9b0XGfHkMMQIEqx3j"  
YOUTUBE_playlist_ID_46 = "PLMdr_HKbn4ph0bMRzVkPdiLtPLC0xwHQv"  
YOUTUBE_playlist_ID_47 = "PLkqz3S84Tw-TgiHX8wa-bFAscdC-0pe1k"  
YOUTUBE_playlist_ID_48 = "PLlD0ifA9koz8HDvUpo3gE63iNYC_GPp4i"   
YOUTUBE_playlist_ID_49 = "PLSYbV1H4VkCcF4nR9pimgJl9n2YCtiJCm"  
YOUTUBE_playlist_ID_50 = "PLxI6IWh7Z6boU_sZm25NTBxPI2tS5ODko"  
YOUTUBE_playlist_ID_51 = "PL8F6B0753B2CCA128"  
YOUTUBE_playlist_ID_52 = "PL2140A0411C65DD13"   
YOUTUBE_playlist_ID_53 = "PLPbMT4wSxX88oU7uYThLcvUI98PUp1bQ2"   
YOUTUBE_playlist_ID_54 = "PLSYbV1H4VkCeCiimiKQ7VijAAHiDoE134"  
YOUTUBE_playlist_ID_55 = "PLTC7VQ12-9rZRMqzpt9t69WxbcBBcMA5N"  
YOUTUBE_playlist_ID_56 = "PLYAYp5OI4lRLf_oZapf5T5RUZeUcF9eRO"   
YOUTUBE_playlist_ID_57 = "PLOzQFWHEFankpJykvzRJ6W5mF81ojL9I5"   
YOUTUBE_playlist_ID_58 = "PLinS5uF49IBrTL7y97OOWRilvdv9RCtD5"  
YOUTUBE_playlist_ID_59 = "PLk-_AvR22RueziRgt5GVuirih223y1UNJ"  
YOUTUBE_playlist_ID_60 = "PLxhnpe8pN3TmtjcQM7zcYAKhQXPdOHS3Y"   
YOUTUBE_playlist_ID_61 = "PL_htyEpQ9NirGqcnTjexvkL1FgdAb1DIP"  
YOUTUBE_playlist_ID_62 = "PLKl-ToKj7DF79wPmya9szDKHU548iKw7N"   
YOUTUBE_playlist_ID_63 = "PLwY9l4M25GOJqIx-Dn-PmYs1KjPd80-1N"  
YOUTUBE_playlist_ID_64 = "PLYVjGTi85afrX2JuWV2_ylym4ykyguiSn"   
YOUTUBE_playlist_ID_65 = "PLuIIZwlpW-BDRwb_Djx47oKDPwSTo37il"  
YOUTUBE_playlist_ID_66 = "PLZ_Hv3CS1vLczLHKKZ-k-YAtt_BocRXjl"  
YOUTUBE_playlist_ID_67 = "PLUTHONkXwksFV41KpZRHS0g7wAUsXNWi1"   
YOUTUBE_playlist_ID_68 = "PLoSFsEOMUSmvu78SR8lpN9qPfhcWlJoh4"  
YOUTUBE_playlist_ID_69 = "PL5xAy4Ufl2T7W9KJHMIZ1zsyeKxFWF1WI"  
YOUTUBE_playlist_ID_70 = "PL6E0fb5idtvomtP6HmaXrIxQM_5dq1Ich"  
YOUTUBE_playlist_ID_71 = "PLA_I2ay5YcUVJbVT8tb-cZQ6pGJHWlnHH"  
YOUTUBE_playlist_ID_72 = "PLSYbV1H4VkCclm8e7Aa3eWFOv6fo7FA_N"   
YOUTUBE_playlist_ID_73 = "PL7D7DF7BCD7BB6397"  
YOUTUBE_playlist_ID_74 = "PLa0YPE0ViQnTWP80UMzn7cVVwuQDijNmf"   
YOUTUBE_playlist_ID_75 = "PLq3UZa7STrbq6UOCFWEHDCbJTgCzSJOqp"  
YOUTUBE_playlist_ID_76 = "PL1A37E3EDA9CEA8D8"   
YOUTUBE_playlist_ID_77 = "PL9mzuSwws3ukqDOPHXTWT92wUJalcg00f"  
YOUTUBE_playlist_ID_78 = "PLXl9q53Jut6nqEPU4yf1F4FTDeQpe32RU"   
YOUTUBE_playlist_ID_79 = "PLK43LLsFwaZl5st2nzGGTimDPmSsngmrY"  
YOUTUBE_playlist_ID_80 = "PLA_I2ay5YcUV2lA5AgUvJZIh-1z0k4s0U" 
YOUTUBE_playlist_ID_81 = "PL3io0GaKtmBZH3DStmaT_2ausUWfA205A"  
YOUTUBE_playlist_ID_82 = "PL64G6j8ePNur3kXmRujUMAJBqcIf3Ru_L"  
YOUTUBE_playlist_ID_83 = "PL26411A62E4BD430F"  
YOUTUBE_playlist_ID_84 = "PLJu1mQyIUo9vv7pr-_kAJhw8Zq7EpWnlC"   
YOUTUBE_playlist_ID_85 = "PL3FGWwglq6wYrwFDDqVVhZMhWsGJyKxxS"   
YOUTUBE_playlist_ID_86 = "PL6ll17AuXo1LdCKcxyVUPKmcWpASnHbAE"  
YOUTUBE_playlist_ID_87 = "PLX5GPCxRpKOSYvZ864eNlH_q5IStw3fBq"   
YOUTUBE_playlist_ID_88 = "PLSYbV1H4VkCczQ9RIAjx_0EZunWjDB6xy"   
YOUTUBE_playlist_ID_89 = "PL7VzovHQUUKo0dOMY90BdBhJGVYlU1BfY"  
YOUTUBE_playlist_ID_90 = "PLxT_qtS_HofDRJpNAuruxYJ7eXQ17MMfD"  
YOUTUBE_playlist_ID_91 = "PLQkQfzsIUwRYxu4vbVopqbcuudw0G1R2e"   
YOUTUBE_playlist_ID_92 = "PLCHaaulQJI-ys37w4ctXmDboYBWoF1mmm"  
YOUTUBE_playlist_ID_93 = "PLm7wnjUQm_FAMNxPGqLKZnuu5PAMhHkb-" 
YOUTUBE_playlist_ID_94 = "PLw6p6PA8M2miu0w4K1g6vQ1BHUBeyM4_-" 
YOUTUBE_playlist_ID_95 = "PLvLB0DOy9-LdCFQPgiizgdLcd0Vxfb4h1"   
YOUTUBE_playlist_ID_96 = "PLEegDkopZ-SrsOX75F__4rdER10UYFH8H"   
YOUTUBE_playlist_ID_97 = "PL84EC9ACDAF6B300C"  
YOUTUBE_playlist_ID_98 = "PL2E6D867EB67A3481" 
YOUTUBE_playlist_ID_99 = "PLA_I2ay5YcUUKiZshI4cgp9fTOS-Q6B1E"   
YOUTUBE_playlist_ID_100 = "PLeC7VLq1hoVxXVp5Lzu9LyMppHSq5koXw"  
YOUTUBE_playlist_ID_101 = "PLnOSH5j1sQh_y5ig-oAjet8VrsQnYnY9P"   
YOUTUBE_playlist_ID_102 = "PL9KifGoS3P-TWwlbEx7OYjstrBHgpdm7z"  
YOUTUBE_playlist_ID_103 = "PL3B47D2B724FD4824"  
YOUTUBE_playlist_ID_104 = "PLukp_BtPsQyUdtHQOYvbCESjXu73Mc2Pd"  
YOUTUBE_playlist_ID_105 = "PLJmzdqLGl_E7CbbYpSgH3Gi-rZyvgxr-6"   
YOUTUBE_playlist_ID_106 = "PLhEeP9J9zuhQxeDJhV-5wWEkqzWQpLZK8"  
YOUTUBE_playlist_ID_107 = "PLC-4Xib-LOrcAzmtQmQTI1ofQajX3Lapr"   
YOUTUBE_playlist_ID_108 = "PLFgm_LJYNEttRTuvpr2qnZ3n697sWcHli"  
YOUTUBE_playlist_ID_109 = "PLzkJGO1JtnC7dI3u-LeREsxuJPiAjJimm"  
YOUTUBE_playlist_ID_110 = "PLBA986EF6C0FAA1D9"  
YOUTUBE_playlist_ID_111 = "PLVQ2GDDQBo9UFH9gPlAmEaMDmY6YsbANf"   
YOUTUBE_playlist_ID_112 = "PL388C6956B2EE2189"   
YOUTUBE_playlist_ID_113 = "PL370681250BF00BC3"  
YOUTUBE_playlist_ID_114 = "PL_XY-y6Et_zw1LyZn8hoSGLfmQ5n5QTKn"   
YOUTUBE_playlist_ID_115 = "PLmo4pBukfRoN8SB5RKvfiY9CTl9pI_IFc"   
YOUTUBE_playlist_ID_116 = "PLabJQI0gItOgdGnnxZ5cnww8zYVYSblNH"  
YOUTUBE_playlist_ID_117 = "PL91801CA691D86F9B"   
YOUTUBE_playlist_ID_118 = "PL5D52CC59B62A204A"  
YOUTUBE_playlist_ID_119 = "PL4QNnZJr8sRNKjKzArmzTBAlNYBDN2h-J"  
YOUTUBE_playlist_ID_120 = "PLwWVOy05xAK-px3Z5tWq3NV_5Qp0AEk6b"  
YOUTUBE_playlist_ID_121 = "PLt0efFL_7wt-O5zIYMNphKfGPQi6P9DUt"  
YOUTUBE_playlist_ID_122 = "PLNRm4Qyy2MDWV2xY_K_7kUzcCcv8yrBJg"  
YOUTUBE_playlist_ID_123 = "PLX9U3Rv7Wy7Wbi3iV2uxFo8BOVHjIehUc"   
YOUTUBE_playlist_ID_124 = "PLSRh2BX6ao7P7E0KVcyZ-rYqhTaVVoZrW"   
YOUTUBE_playlist_ID_125 = "PL0C258FE8916ECCB1"   
YOUTUBE_playlist_ID_126 = "PLmS86t_jmQvbpeehASz2Tosvj7d1VN-ZE"  
YOUTUBE_playlist_ID_127 = "PLSt6PZ2gsMLLa4kUHAJxEqaiBzv6lKp4v"  
YOUTUBE_playlist_ID_128 = "PLnUDHJz-31cHA_wlL6dx2mtS23_iqQBGj"   
YOUTUBE_playlist_ID_129 = "PLic91mhoPnxHgzij9We-plBNJo3j1rd8B"   
YOUTUBE_playlist_ID_130 = "PLFR04WQ_ARyQ-xzAX1dJXOUEdsHM9Sr"   
YOUTUBE_playlist_ID_131 = "PLIVbZhwLbExKoDlYntZV_Y1c3bZYz7hAs"   
YOUTUBE_playlist_ID_132 = "PLsC90_43kf5UB_wuLYrtRLG-J8YAPgMCh"  
YOUTUBE_playlist_ID_133 = "PLyUKaKIB05bQuG4s7AgxZ7-j04Ct_Nw82"  
YOUTUBE_playlist_ID_134 = "PLlYKDqBVDxX0Qzmoi2-vvHJjOAy3tRPQ_"   
YOUTUBE_playlist_ID_135 = "PLGBuKfnErZlDI1LRP7ANgsa09x0CrIT6b"   
YOUTUBE_playlist_ID_136 = "PL6EF50C0B0EE0394B"   
YOUTUBE_playlist_ID_137 = "PLcUqPeI0P9OzpYK1UBbeAApBHkEXONi5K"   
YOUTUBE_playlist_ID_138 = "PLyORnIW1xT6wBFoOxTh__8a3dFzbgHYrw"   
YOUTUBE_playlist_ID_139 = "PL1dawt09wsD2gWUa25VF-o2VM8xFisn9r"  
YOUTUBE_playlist_ID_140 = "PLJd7utaEK5kCa1WNGqAFKxgf0MLVegthK"   
YOUTUBE_playlist_ID_141 = "PLmdwo0nDs2HnT8BlW8MuPJ9a9xthJjOvo"   
YOUTUBE_playlist_ID_142 = "PLqc7q6_aVtEedhZhephOsn3lYeoGTdb45"   
YOUTUBE_playlist_ID_143 = "PLDIoUOhQQPlXr63I_vwF9GD8sAKh77dWU"   
YOUTUBE_playlist_ID_144 = "PL1C555E0FCE0DE629"   
YOUTUBE_playlist_ID_145 = "PLqGkpApxFsX_jRp4sDFz9_gwztqqpDZ2U"   
YOUTUBE_playlist_ID_146 = "PL47423FF1E03177A8"   
YOUTUBE_playlist_ID_147 = "PLGtW_kt2Ks8Kv1dBqJjTVlCOBVBN0jR2x"   
YOUTUBE_playlist_ID_148 = "PLaLWNpJCbH_r_0jG3o4r_kUtLB1gUFUdX"  
YOUTUBE_playlist_ID_149 = "PLyjgHc47unfT3BIZo5uEt2a-2TWKy54sU"  
YOUTUBE_playlist_ID_150 = "PLyDDMmF7xacYISTUmhO3bW1A5eaTqqQLU"   
YOUTUBE_playlist_ID_151 = "PLI_7Mg2Z_-4IzxbySOWX5xNT7vDV2HCgG"   
YOUTUBE_playlist_ID_152 = "PLgP_WFDJWjxSgClOt0zBSwiofDIbTLjFj"   
YOUTUBE_playlist_ID_153 = "PL0Ea63JLhmBZFPgxGlOa_QqnR02YYIbxj"   
YOUTUBE_playlist_ID_154 = "PLT0PWRx_9kWsZNX5Rgf8DDFcyAu-zP7C9"   
YOUTUBE_playlist_ID_155 = "PLD58ECddxRngHs9gZPQWOCAKwV1hTtYe4" 
YOUTUBE_playlist_ID_156 = "PLcUqPeI0P9OzpYK1UBbeAApBHkEXONi5K"   
YOUTUBE_playlist_ID_157 = "PLnMN8r-C6UXvv4G6u_MlUoyHLSV2pExKt"   
YOUTUBE_playlist_ID_158 = "PLFoFu8Ubv_K9xY_uhIgPlTCE9YJTeD7Yv"   
YOUTUBE_playlist_ID_159 = "PL539EAB0AAC7115D6"   
YOUTUBE_playlist_ID_160 = "PLVyGBw9rxZW5TdmxxIcbFdwIvDzL9hmTv"
YOUTUBE_playlist_ID_161 = "PLSrd6av4d9FB38oJzinkYo8pKKy75BB75"   
YOUTUBE_playlist_ID_162 = "PL1391237437761842"   
YOUTUBE_playlist_ID_163 = "PLFNoV4a_DdP9B7nKmHzai4ISsN2eqE8qd"   
YOUTUBE_playlist_ID_164 = "PL6F2E55E6C55E3D5C"   
YOUTUBE_playlist_ID_165 = "PL00406755CBB598E4"
YOUTUBE_playlist_ID_166 = "PLop8VH45f9THwLpL0k5E0YJLK6OJRVAzX"   
YOUTUBE_playlist_ID_167 = "PLp5Ie3eol3uMHxW3X2Hai286cbRz9Ieox"   
YOUTUBE_playlist_ID_168 = "PLUFcxlFae4DnP9NIQQ5LQLg4Mx7gwg3XS"   
YOUTUBE_playlist_ID_169 = "PLkpBMluoHSysEDsA9EqpuUSrCHonWYTCx"   
YOUTUBE_playlist_ID_170 = "PLE95D2AF80B98128A"
YOUTUBE_playlist_ID_171 = "PLrnf2axPSKTczDHyYHh1IjNwRdBsqtNUc"   
YOUTUBE_playlist_ID_172 = "PLEXox2R2RxZJwar7F90A4myvLFaNnAbF8"   
YOUTUBE_playlist_ID_173 = "PL1s6OeN3vk7tizc6Aw_X9E41KB0rMZaun"   
YOUTUBE_playlist_ID_174 = "PLgP_WFDJWjxTRPJtV4DV99lGB92rq5we_"   
YOUTUBE_playlist_ID_175 = "PLLDlq9PuU6JfoK6hgy1dmGMdfRLjs8CsJ"
# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="[COLOR gold]Pide Tu Cancion MusicHall en el Grupo Telegram @AprendiendoKodi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1+"/",
        thumbnail="https://i.imgur.com/yr7txZt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR gold]Pide Tu Concierto aqui en Music Hall en el Grupo Telegram @AprendiendoKodi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_2+"/",
        thumbnail="https://i.imgur.com/6tbCPcq.jpg",
		fanart="https://i.imgur.com/6tbCPcq.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Acid House Groovy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_111+"/",
        thumbnail="https://i.imgur.com/eRy3y8x.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]African Hits Song 2019[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_123+"/",
        thumbnail="https://i.imgur.com/GDCmvY8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Aires De Cuba[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_146+"/",
        thumbnail="https://i.imgur.com/ba6b0aX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alternative rock of the 2000s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_10+"/",
        thumbnail="https://i.imgur.com/V1ZqiX9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alucinante Canto Gregoriano Pop Rock[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_147+"/",
        thumbnail="https://i.imgur.com/TezNQwI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bachata[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_156+"/",
        thumbnail="https://i.imgur.com/eiLCAU9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Baladas De Ayer Hoy y Siempre[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_106+"/",
        thumbnail="https://i.imgur.com/JYDY7w6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Baladas Pop En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_83+"/",
        thumbnail="https://i.imgur.com/WOJzJbw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bast Boosted[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_167+"/",
        thumbnail="https://i.imgur.com/uN5VVWA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Best Classic rock mix[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_8+"/",
        thumbnail="https://i.imgur.com/ZvwVGKf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Best Women Jazz Music of All Time[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_53+"/",
        thumbnail="https://i.imgur.com/qPgX7rO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Big Room[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_175+"/",
        thumbnail="https://i.imgur.com/9QYu2LG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Billboard 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_143+"/",
        thumbnail="https://i.imgur.com/0HzRnK7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Boleros[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_64+"/",
        thumbnail="https://i.imgur.com/52v0FZO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bossanova Canciones en Acustico[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_59+"/",
        thumbnail="https://i.imgur.com/d3kFnc1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Boys Band[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_138+"/",
        thumbnail="https://i.imgur.com/y075DdT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]BSO Canciones De Peliculas Famosas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_84+"/",
        thumbnail="https://i.imgur.com/X0Jm2xZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Canciones Romanticas en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_105+"/",
        thumbnail="https://i.imgur.com/RpbOayc.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Canciones Spot Publicitarios[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_129+"/",
        thumbnail="https://i.imgur.com/G47GcR6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cante Flamenco - Figuras del cante Jondo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_30+"/",
        thumbnail="https://i.imgur.com/Tbi5AfE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chambao Chill Out[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_13+"/",
        thumbnail="https://i.imgur.com/THq2a2S.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chill Out[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_12+"/",
        thumbnail="https://i.imgur.com/yTnsSPZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chillout Lounge - Spotify[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_24+"/",
        thumbnail="https://i.imgur.com/CMhwl96.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chirigotas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_127+"/",
        thumbnail="https://i.imgur.com/ABRt8SO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Clasicos Del Funk[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_110+"/",
        thumbnail="https://i.imgur.com/992TtX4.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Clasicos De La Musica Electronica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_32+"/",
        thumbnail="https://i.imgur.com/GVH8gc0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Clasicos del Rap Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_73+"/",
        thumbnail="https://i.imgur.com/RMZ0aXQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Clasicos del Rock en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_11+"/",
        thumbnail="https://i.imgur.com/KyVQSrI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Conciertos en Directo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_33+"/",
        thumbnail="https://i.imgur.com/D0e8euc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Copla Española[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_70+"/",
        thumbnail="https://i.imgur.com/FnIz7PG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Country De Los 70 80[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_135+"/",
        thumbnail="https://i.imgur.com/Je1f67V.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cumbia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_151+"/",
        thumbnail="https://i.imgur.com/OaVd21R.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Disco Funk Soul 70s 80s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_37+"/",
        thumbnail="https://i.imgur.com/CEelwt2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Disco Hits of the 70s 80s 90s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_38+"/",
        thumbnail="https://i.imgur.com/Tp3VTg0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]El mejor Flamenquito 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_26+"/",
        thumbnail="https://i.imgur.com/r8XeyVC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Europa FM - Lista de Exitos 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_18+"/",
        thumbnail="https://i.imgur.com/J75Rikb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Euskal Musik[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_80+"/",
        thumbnail="https://i.imgur.com/XVeJXCt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Eurovision[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_102+"/",
        thumbnail="https://i.imgur.com/mEDVpJV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ganadores Eurovision 1956-2019[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_103+"/",
        thumbnail="https://i.imgur.com/Qly45Xg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Exitos Radio Ole[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_120+"/",
        thumbnail="https://i.imgur.com/7tNHdSK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fandangos y Cante Jondo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_31+"/",
        thumbnail="https://i.imgur.com/Rf0hkuk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fado Portugues[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_165+"/",
        thumbnail="https://i.imgur.com/9HD48Br.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Flamenco Pop Mix[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_29+"/",
        thumbnail="https://i.imgur.com/8OUagSi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Flashback Romantico Internacional[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_107+"/",
        thumbnail="https://i.imgur.com/8TIN5ff.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Folk Mexicano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_96+"/",
        thumbnail="https://i.imgur.com/PIBo335.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Garaje Rock[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_154+"/",
        thumbnail="https://i.imgur.com/MtZWQ9b.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Girls Power[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_139+"/",
        thumbnail="https://i.imgur.com/vqDri8j.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Glam And Hair Metal de Los 80[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_98+"/",
        thumbnail="https://i.imgur.com/MSfTpef.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Goguettes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_166+"/",
        thumbnail="https://i.imgur.com/2wBrN7y.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gospel Hits 2019[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_131+"/",
        thumbnail="https://i.imgur.com/6jMAiVH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Grandes Exitos de la Musica Indie en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_48+"/",
        thumbnail="https://i.imgur.com/SgDCIxN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Grunge The Best[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_155+"/",
        thumbnail="https://i.imgur.com/qztwyR3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Guitarra Clasica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_42+"/",
        thumbnail="https://i.imgur.com/qWr7skf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Guitarra Clasica Española[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_25+"/",
        thumbnail="https://i.imgur.com/HNHuitY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hard Rock 80s & 90s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_22+"/",
        thumbnail="https://i.imgur.com/BlBjux5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hard Rock 2 De Los 80 y 90[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_94+"/",
        thumbnail="https://i.imgur.com/j106577.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hard Rock Woman Singers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_140+"/",
        thumbnail="https://i.imgur.com/I7xcyNo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hilo Musical Canciones Para Recordar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_87+"/",
        thumbnail="https://i.imgur.com/Ehbz3nY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hilo Musical En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_86+"/",
        thumbnail="https://i.imgur.com/wvT1oqu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hilo Musical Internacional[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_85+"/",
        thumbnail="https://i.imgur.com/q4edbhf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hits Dance 2020 2021 Classifica Mtv[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_39+"/",
        thumbnail="https://i.imgur.com/3ytyF7o.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Humppa Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_168+"/",
        thumbnail="https://i.imgur.com/VQhEqJP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Indian American Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_124+"/",
        thumbnail="https://i.imgur.com/JS8p1k5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jesucristo Super Star Camilo Sesto[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_118+"/",
        thumbnail="https://i.imgur.com/B1iJrPR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Joropo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_164+"/",
        thumbnail="https://i.imgur.com/gTEWlax.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Karaoke En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_144+"/",
        thumbnail="https://i.imgur.com/07zHCNa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Karaoke Internacional[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_145+"/",
        thumbnail="https://i.imgur.com/72SbWDP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kiss Fm Radio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_122+"/",
        thumbnail="https://i.imgur.com/zgtcvHY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]KPOP 2020 2021 Korean Pop Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_119+"/",
        thumbnail="https://i.imgur.com/2dH0kMC.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Las Mejores Rancheras[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_66+"/",
        thumbnail="https://i.imgur.com/g3D7PdH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Latino Total 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_82+"/",
        thumbnail="https://i.imgur.com/U7wOsZk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Late 70s Soul Funk & Disco Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_36+"/",
        thumbnail="https://i.imgur.com/a1F1Guf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mas Escuchado 2019-2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_15+"/",
        thumbnail="https://i.imgur.com/AmoXCbH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mas Nuevo Del Rap Y Hip Hop En Español 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_75+"/",
        thumbnail="https://i.imgur.com/j2rpjC7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Mejores Boleros de Todos los Tiempos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_65+"/",
        thumbnail="https://i.imgur.com/7B9EKjJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Mejores Exitos de Guitarra Española[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_43+"/",
        thumbnail="https://i.imgur.com/StuplSO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mejor Del Country[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_134+"/",
        thumbnail="https://i.imgur.com/urbBmOZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mejor de la Opera Lirica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_116+"/",
        thumbnail="https://i.imgur.com/FAyOGUX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mejor del Reggae[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_56+"/",
        thumbnail="https://i.imgur.com/MLHdoft.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mejor de La Zarzuela[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_68+"/",
        thumbnail="https://i.imgur.com/nhq4fNY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lounge Music 2019[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_23+"/",
        thumbnail="https://i.imgur.com/JBBhJlm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]M80 Serie Oro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_121+"/",
        thumbnail="https://i.imgur.com/RnSB4FW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Marchas Militares Españolas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_170+"/",
        thumbnail="https://i.imgur.com/xZiu8gV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Marchas Nupciales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_161+"/",
        thumbnail="https://i.imgur.com/IZA7IYc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Marchas De Procesiones y Cofrades[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_128+"/",
        thumbnail="https://i.imgur.com/v4pa3vM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mariachi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_97+"/",
        thumbnail="https://i.imgur.com/UNxdqB1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mejores Canciones Rumba Flamenca Pop 2020-2021[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_27+"/",
        thumbnail="https://i.imgur.com/R5Cdma5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mejores Canciones de la Radio 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_34+"/",
        thumbnail="https://i.imgur.com/s1eaBKA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mejores Canciones Musica rock[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_9+"/",
        thumbnail="https://i.imgur.com/iDA38r1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Merengue[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_153+"/",
        thumbnail="https://i.imgur.com/8JKJzpo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mento Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_163+"/",
        thumbnail="https://i.imgur.com/wDfVaG1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Metal Sinfonico Gotico[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_113+"/",
        thumbnail="https://i.imgur.com/WNCPlsd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Milongas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_169+"/",
        thumbnail="https://i.imgur.com/1wQ3gBu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mix Internacional 2020-2021[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_6+"/",
        thumbnail="https://i.imgur.com/i4avcbK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mix Reggaeton 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_14+"/",
        thumbnail="https://i.imgur.com/G7HgD9Q.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]MTV Greatest Hits[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_61+"/",
        thumbnail="https://i.imgur.com/77rD8gZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mtv Top Songs 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_60+"/",
        thumbnail="https://i.imgur.com/9W3ieuN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]MTV Top Hits[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_62+"/",
        thumbnail="https://i.imgur.com/I1ZjuSS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Barroca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_125+"/",
        thumbnail="https://i.imgur.com/RyYkttl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Brasilera 2020 Lo Mas Escuchado[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_58+"/",
        thumbnail="https://i.imgur.com/ihMknfV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Canaria[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_101+"/",
        thumbnail="https://i.imgur.com/YB2VTF5.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Celta Epica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_81+"/",
        thumbnail="https://i.imgur.com/iYn8iZ5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Clasica Instrumental[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_21+"/",
        thumbnail="https://i.imgur.com/VLFhuAJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Del Alma Kundalini Yoga[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_92+"/",
        thumbnail="https://i.imgur.com/9JId3Um.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Española Flamenco Pop[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_28+"/",
        thumbnail="https://i.imgur.com/CPRNpCl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Folk Latina[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_95+"/",
        thumbnail="https://i.imgur.com/6uOvnoq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Gallega[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_104+"/",
        thumbnail="https://i.imgur.com/XikeTkl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Italiana top 80s-90s-00s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_45+"/",
        thumbnail="https://i.imgur.com/15I8Syb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Navideña Internacional[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_88+"/",
        thumbnail="https://i.imgur.com/SILxjqZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Para Bailar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_17+"/",
        thumbnail="https://i.imgur.com/Ou7Kjmw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Retro Disco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_109+"/",
        thumbnail="https://i.imgur.com/qMTvcIo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Variada de Todo un Poco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_16+"/",
        thumbnail="https://i.imgur.com/RJ018Tm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]New Age[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_159+"/",
        thumbnail="https://i.imgur.com/HxZwpcm.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]New Metal Songs 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_93+"/",
        thumbnail="https://i.imgur.com/QRSyQMA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nightcore 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_148+"/",
        thumbnail="https://i.imgur.com/2c70Ajm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Novedades POP en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_47+"/",
        thumbnail="https://i.imgur.com/5Em3PAr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Opera Rock The Best Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_117+"/",
        thumbnail="https://i.imgur.com/AKDIKiL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pasodobles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_69+"/",
        thumbnail="https://i.imgur.com/QBhm3w9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_54+"/",
        thumbnail="https://i.imgur.com/RBQnFAW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Latino Clasico[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_5+"/",
        thumbnail="https://i.imgur.com/P5eJVmT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Latino Mix 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_20+"/",
        thumbnail="https://i.imgur.com/hcUe0tq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]POP Music  2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_3+"/",
        thumbnail="https://i.imgur.com/bbN45sb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Music Lo Mejor de Todos los Tiempos 2020-2021[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_4+"/",
        thumbnail="https://i.imgur.com/0eq7tXz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Rock En Catala 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_78+"/",
        thumbnail="https://i.imgur.com/a5G4AC0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Punk Rock En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_79+"/",
        thumbnail="https://i.imgur.com/dJwMB0Q.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Rock Best of 1990 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_55+"/",
        thumbnail="https://i.imgur.com/CFbI5Lb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rancheras Para El Recuerdo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_67+"/",
        thumbnail="https://i.imgur.com/KT3IJGx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rap Conciencia Hip -Hop en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_76+"/",
        thumbnail="https://i.imgur.com/0jz5zlD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rap Hip Hop en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_71+"/",
        thumbnail="https://i.imgur.com/IDjIjyC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Reggaeton Hits[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_40+"/",
        thumbnail="https://i.imgur.com/TRPvO7t.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Reggaeton 2019 Playlist & Latin Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_41+"/",
        thumbnail="https://i.imgur.com/L3SQ5YE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Reggae En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_57+"/",
        thumbnail="https://i.imgur.com/XJzhCnd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Reggae Playlist[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_63+"/",
        thumbnail="https://i.imgur.com/RwoHeoK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Retro Disco Infierno[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_132+"/",
        thumbnail="https://i.imgur.com/2Egvoiz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Road Trip Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_150+"/",
        thumbnail="https://i.imgur.com/wIKuXVQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rock A Violin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_114+"/",
        thumbnail="https://i.imgur.com/GPlojss.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]80s y 90s Rock[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_7+"/",
        thumbnail="https://i.imgur.com/vOuU0yR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rockabilly Boogie Woogie[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_133+"/",
        thumbnail="https://i.imgur.com/tVfeXT5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rock Instrumental de Guitarra Electrica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_44+"/",
        thumbnail="https://i.imgur.com/j2skU30.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rock Sinfonico[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_112+"/",
        thumbnail="https://i.imgur.com/eCAqWKM.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rumbas 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_99+"/",
        thumbnail="https://i.imgur.com/YPim42g.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ruta Del Bacalao[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_100+"/",
        thumbnail="https://i.imgur.com/Fokvewf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sintonias TV[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_130+"/",
        thumbnail="https://i.imgur.com/waFnhGS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ska Songs All Time[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_152+"/",
        thumbnail="https://i.imgur.com/bp8CADg.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sophistic Pop[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_172+"/",
        thumbnail="https://i.imgur.com/rCgSu9P.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Spotify Playlist 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_35+"/",
        thumbnail="https://i.imgur.com/MHnErB6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Surf Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_160+"/",
        thumbnail="https://i.imgur.com/33CbTO0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tandas de Tango[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_142+"/",
        thumbnail="https://i.imgur.com/ZV4GxzF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Beatles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_115+"/",
        thumbnail="https://i.imgur.com/COHYV3N.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Third Stream Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_173+"/",
        thumbnail="https://i.imgur.com/0cElGqF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Throwback Exitos de 1990 a 2000[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_149+"/",
        thumbnail="https://i.imgur.com/z19nx22.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Timeless Dance Bachata[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_137+"/",
        thumbnail="https://i.imgur.com/wyhNR9g.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top 50 España Exitos 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_19+"/",
        thumbnail="https://i.imgur.com/OHUtwe0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Best Rhythm aquas & Soul 60s 70s 80s & 90s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_108+"/",
        thumbnail="https://i.imgur.com/vVB0s2n.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Mejores aquas aquas-Rock  Jazz All Time[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_52+"/",
        thumbnail="https://i.imgur.com/nkIeyUi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Mejores Canciones Español 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_50+"/",
        thumbnail="https://i.imgur.com/X1fPsK3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Hip Hop Español 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_72+"/",
        thumbnail="https://i.imgur.com/yRggM5p.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Jazz Classics Songs of All Time[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_51+"/",
        thumbnail="https://i.imgur.com/ThRjE2R.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Las 50 Mejores Canciones del Rap en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_74+"/",
        thumbnail="https://i.imgur.com/u2zu8el.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Musica Italiana del Momento[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_46+"/",
        thumbnail="https://i.imgur.com/NP8qwiG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Musica Piano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_126+"/",
        thumbnail="https://i.imgur.com/RGcOde6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Todo Retro En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_141+"/",
        thumbnail="https://i.imgur.com/jHumbuT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Trap España 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_49+"/",
        thumbnail="https://i.imgur.com/92HJf5u.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Trova[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_157+"/",
        thumbnail="https://i.imgur.com/QKqCmE7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Urban[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_158+"/",
        thumbnail="https://i.imgur.com/XgfVp4C.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Vallenato[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_136+"/",
        thumbnail="https://i.imgur.com/eP5NkL4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Valses[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_162+"/",
        thumbnail="https://i.imgur.com/ZkTTIeU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]VaporWave Best Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_174+"/",
        thumbnail="https://i.imgur.com/bF6lgYm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Villancicos en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_89+"/",
        thumbnail="https://i.imgur.com/yYtbToH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Villancicos Heavy Metal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_90+"/",
        thumbnail="https://i.imgur.com/qvbZxjf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Wednesday Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_77+"/",
        thumbnail="https://i.imgur.com/fQZunsr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Yaravis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_171+"/",
        thumbnail="https://i.imgur.com/qYElmVv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Zen Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_91+"/",
        thumbnail="https://i.imgur.com/Vmg7Kz2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
run()