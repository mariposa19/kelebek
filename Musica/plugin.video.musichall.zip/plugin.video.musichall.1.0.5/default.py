# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Thanks to the Authors of the base code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# modified by: MUSICHALL
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.musichall'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_playlist_ID_1 = "PLSyCRkPeE-W0Yd6UutqVt7jKgsrSWwBnc"    
YOUTUBE_playlist_ID_2 = "PLSyCRkPeE-W26b_hGZIoO7XfsH3licNU2"    
YOUTUBE_playlist_ID_3 = "PL4o29bINVT4EG_y-k5jGoOu3-Am8Nvi10"    
YOUTUBE_playlist_ID_4 = "PLMC9KNkIncKtPzgY-5rmhvj7fax8fdxoj"    
YOUTUBE_playlist_ID_5 = "PLe_mU5sgHnNTzIMMSz7JsyXLFDcrMW0Ep"    
YOUTUBE_playlist_ID_6 = "PLB8HqqmpyIBcPirb5lDm-ol01trE6dOuM"   
YOUTUBE_playlist_ID_7 = "PL3485902CC4FB6C67"    
YOUTUBE_playlist_ID_8 = "PLZN_exA7d4RVmCQrG5VlWIjMOkMFZVVOc"   
YOUTUBE_playlist_ID_9 = "PLhd1HyMTk3f5PzRjJzmzH7kkxjfdVoPPj"    
YOUTUBE_playlist_ID_10 = "PL6Lt9p1lIRZ311J9ZHuzkR5A3xesae2pk" 
YOUTUBE_playlist_ID_11 = "PL_86NZWyc0FsJF98CRytnzItb5EXMQOne"  
YOUTUBE_playlist_ID_12 = "PL7dWoRZfPDhp9Zh9hGlAM6uYn7QYz9zE"   
YOUTUBE_playlist_ID_13 = "PLT97TNIfVc4k6u4vhaUHlnejTwnCuCBCe"  
YOUTUBE_playlist_ID_14 = "PL7v1FHGMOadAnIzTEHrAaZhGyXzcDOk79"  
YOUTUBE_playlist_ID_15 = "PL4XLEC-MUq2uP2OhrGWdOErGUDrEquhqi"  
YOUTUBE_playlist_ID_16 = "PLOuAaPDGy5br7qCO28VX5AzTq4_hmGKDX"  
YOUTUBE_playlist_ID_17 = "PLo3pNg0eiPc_jQ_jhD8P4UoiOE6vmGdU6"  
YOUTUBE_playlist_ID_18 = "PLdS6GqghzS68QVNnOSU2_MSmTFbeLLMjp"  
YOUTUBE_playlist_ID_19 = "PLSYbV1H4VkCcHi33SC1mldSDi8vrYlfCm"   
YOUTUBE_playlist_ID_20 = "PL1av4CQniLB0dk5LnfWQhBUcRlzo2jBYB"   
YOUTUBE_playlist_ID_21 = "PLFE06A24F924AADB0"   
YOUTUBE_playlist_ID_22 = "PLw6p6PA8M2miu0w4K1g6vQ1BHUBeyM4"   
YOUTUBE_playlist_ID_23 = "PLNjVKDn-Jmf6MJ56EPkd0qtYjml3nkQ4X"  
YOUTUBE_playlist_ID_24 = "PL11Wnnyw47LpkF3McMjHwG0HZ23CcfYUX"  
YOUTUBE_playlist_ID_25 = "PLD15AF3F721D9841B"  
YOUTUBE_playlist_ID_26 = "PLA_I2ay5YcUUKiZshI4cgp9fTOS-Q6B1E"  
YOUTUBE_playlist_ID_27 = "PLGUwEHGA8vYx5f9h7kBX-7ajQ4l2dz5Np"  
YOUTUBE_playlist_ID_28 = "PLz1LeT5FVsBsZYX2J5yhW8tHuTsRdlAKb"  
YOUTUBE_playlist_ID_29 = "PL3eLsFJDQqDeoCf4U6v4WqJpIem9wPsuB"   
YOUTUBE_playlist_ID_30 = "PL3OPG8Q1fcHfckwr3RJjEFdC17plumnrk"   
YOUTUBE_playlist_ID_31 = "PL0cR6Rwd6cZ_NFddNfqUY9Pr-tdua1hH-"   
YOUTUBE_playlist_ID_32 = "PLdSAKz5rcwnzE7ahB8I1B1uf32ZcAA4Xp"  
YOUTUBE_playlist_ID_33 = "PL54835teYYB6TXx0j37rArlHeS2Nzi9Fw"  
YOUTUBE_playlist_ID_34 = "PLVwXkzK42QWpYvaIk_g7RpNyN0v_mDys1"   
YOUTUBE_playlist_ID_35 = "PLg0miFvQna78NnuHxMGgGomvhx7AzPsrq"  
YOUTUBE_playlist_ID_36 = "PLcM4ZwI542CriszmMjt8HSOJ-dVzKo3O3"   
YOUTUBE_playlist_ID_37 = "PL20422B75F11401A9"  
YOUTUBE_playlist_ID_38 = "PLC90FB71F6ECE17F3"  
YOUTUBE_playlist_ID_39 = "PL08MW4hWrm0IgjVeAiyONMnXGi6XIXX_8" 
YOUTUBE_playlist_ID_40 = "PLFB42B657AC475437"   
YOUTUBE_playlist_ID_41 = "PLi7ihgkEws7S0Dwxxyxb7SJyd2FU5VaoX"  
YOUTUBE_playlist_ID_42 = "PL4ED12F0E006F3FB5"  
YOUTUBE_playlist_ID_43 = "PLH3uWI-RMnujGh1_eWrxjeJlOs8LsFW2a"  
YOUTUBE_playlist_ID_44 = "PLUB47gDSghxHXzrES8stEO1IoUWNaDtjo"   
YOUTUBE_playlist_ID_45 = "PLoc2h0J0pKbjKURh9b0XGfHkMMQIEqx3j"  
YOUTUBE_playlist_ID_46 = "PLMdr_HKbn4ph0bMRzVkPdiLtPLC0xwHQv"  
YOUTUBE_playlist_ID_47 = "PLkqz3S84Tw-TgiHX8wa-bFAscdC-0pe1k"  
YOUTUBE_playlist_ID_48 = "PLlD0ifA9koz8HDvUpo3gE63iNYC_GPp4i"   
YOUTUBE_playlist_ID_49 = "PLSYbV1H4VkCcF4nR9pimgJl9n2YCtiJCm"  
YOUTUBE_playlist_ID_50 = "PLxI6IWh7Z6boU_sZm25NTBxPI2tS5ODko"  
YOUTUBE_playlist_ID_51 = "PL8F6B0753B2CCA128"  
YOUTUBE_playlist_ID_52 = "PL2140A0411C65DD13"   
YOUTUBE_playlist_ID_53 = "PLPbMT4wSxX88oU7uYThLcvUI98PUp1bQ2"   
YOUTUBE_playlist_ID_54 = "PLSYbV1H4VkCeCiimiKQ7VijAAHiDoE134"  
YOUTUBE_playlist_ID_55 = "PLTC7VQ12-9rZRMqzpt9t69WxbcBBcMA5N"  
YOUTUBE_playlist_ID_56 = "PLYAYp5OI4lRLf_oZapf5T5RUZeUcF9eRO"   
YOUTUBE_playlist_ID_57 = "PLOzQFWHEFankpJykvzRJ6W5mF81ojL9I5"   
YOUTUBE_playlist_ID_58 = "PLinS5uF49IBrTL7y97OOWRilvdv9RCtD5"  
YOUTUBE_playlist_ID_59 = "PLk-_AvR22RueziRgt5GVuirih223y1UNJ"  
YOUTUBE_playlist_ID_60 = "PLxhnpe8pN3TmtjcQM7zcYAKhQXPdOHS3Y"   
YOUTUBE_playlist_ID_61 = "PL_htyEpQ9NirGqcnTjexvkL1FgdAb1DIP"  
YOUTUBE_playlist_ID_62 = "PLKl-ToKj7DF79wPmya9szDKHU548iKw7N"   
YOUTUBE_playlist_ID_63 = "PLwY9l4M25GOJqIx-Dn-PmYs1KjPd80-1N"  
YOUTUBE_playlist_ID_64 = "PLYVjGTi85afrX2JuWV2_ylym4ykyguiSn"   
YOUTUBE_playlist_ID_65 = "PLuIIZwlpW-BDRwb_Djx47oKDPwSTo37il"  
YOUTUBE_playlist_ID_66 = "PLZ_Hv3CS1vLczLHKKZ-k-YAtt_BocRXjl"  
YOUTUBE_playlist_ID_67 = "PLUTHONkXwksFV41KpZRHS0g7wAUsXNWi1"   
YOUTUBE_playlist_ID_68 = "PLoSFsEOMUSmvu78SR8lpN9qPfhcWlJoh4"  
YOUTUBE_playlist_ID_69 = "PL5xAy4Ufl2T7W9KJHMIZ1zsyeKxFWF1WI"  
YOUTUBE_playlist_ID_70 = "PL6E0fb5idtvomtP6HmaXrIxQM_5dq1Ich"  
YOUTUBE_playlist_ID_71 = "PLA_I2ay5YcUVJbVT8tb-cZQ6pGJHWlnHH"  
YOUTUBE_playlist_ID_72 = "PLSYbV1H4VkCclm8e7Aa3eWFOv6fo7FA_N"   
YOUTUBE_playlist_ID_73 = "PL7D7DF7BCD7BB6397"  
YOUTUBE_playlist_ID_74 = "PLa0YPE0ViQnTWP80UMzn7cVVwuQDijNmf"   
YOUTUBE_playlist_ID_75 = "PLq3UZa7STrbq6UOCFWEHDCbJTgCzSJOqp"  
YOUTUBE_playlist_ID_76 = "PL1A37E3EDA9CEA8D8"   
YOUTUBE_playlist_ID_77 = "PL9mzuSwws3ukqDOPHXTWT92wUJalcg00f"  
YOUTUBE_playlist_ID_78 = "PLXl9q53Jut6nqEPU4yf1F4FTDeQpe32RU"   
YOUTUBE_playlist_ID_79 = "PLK43LLsFwaZl5st2nzGGTimDPmSsngmrY"  
YOUTUBE_playlist_ID_80 = "PLA_I2ay5YcUV2lA5AgUvJZIh-1z0k4s0U" 
YOUTUBE_playlist_ID_81 = "PL3io0GaKtmBZH3DStmaT_2ausUWfA205A"  
YOUTUBE_playlist_ID_82 = "PL64G6j8ePNur3kXmRujUMAJBqcIf3Ru_L"  
YOUTUBE_playlist_ID_83 = "PL26411A62E4BD430F"  
YOUTUBE_playlist_ID_84 = "PLJu1mQyIUo9vv7pr-_kAJhw8Zq7EpWnlC"   
YOUTUBE_playlist_ID_85 = "PL3FGWwglq6wYrwFDDqVVhZMhWsGJyKxxS"   
YOUTUBE_playlist_ID_86 = "PL6ll17AuXo1LdCKcxyVUPKmcWpASnHbAE"  
YOUTUBE_playlist_ID_87 = "PLX5GPCxRpKOSYvZ864eNlH_q5IStw3fBq"   
YOUTUBE_playlist_ID_88 = "PLSYbV1H4VkCczQ9RIAjx_0EZunWjDB6xy"   
YOUTUBE_playlist_ID_89 = "PL7VzovHQUUKo0dOMY90BdBhJGVYlU1BfY"  
YOUTUBE_playlist_ID_90 = "PLxT_qtS_HofDRJpNAuruxYJ7eXQ17MMfD"  
YOUTUBE_playlist_ID_91 = "PLQkQfzsIUwRYxu4vbVopqbcuudw0G1R2e"   
YOUTUBE_playlist_ID_92 = "PLCHaaulQJI-ys37w4ctXmDboYBWoF1mmm"  
YOUTUBE_playlist_ID_93 = "PLm7wnjUQm_FAMNxPGqLKZnuu5PAMhHkb-" 
YOUTUBE_playlist_ID_94 = "PLw6p6PA8M2miu0w4K1g6vQ1BHUBeyM4_-" 
YOUTUBE_playlist_ID_95 = "PLvLB0DOy9-LdCFQPgiizgdLcd0Vxfb4h1"   
YOUTUBE_playlist_ID_96 = "PLEegDkopZ-SrsOX75F__4rdER10UYFH8H"   
YOUTUBE_playlist_ID_97 = "PL84EC9ACDAF6B300C"  
YOUTUBE_playlist_ID_98 = "PL2E6D867EB67A3481" 
YOUTUBE_playlist_ID_99 = "PLA_I2ay5YcUUKiZshI4cgp9fTOS-Q6B1E"   
YOUTUBE_playlist_ID_100 = "PLeC7VLq1hoVxXVp5Lzu9LyMppHSq5koXw"  
YOUTUBE_playlist_ID_101 = "PLnOSH5j1sQh_y5ig-oAjet8VrsQnYnY9P"   
YOUTUBE_playlist_ID_102 = "PL9KifGoS3P-TWwlbEx7OYjstrBHgpdm7z"  
YOUTUBE_playlist_ID_103 = "PL3B47D2B724FD4824"  
YOUTUBE_playlist_ID_104 = "PLukp_BtPsQyUdtHQOYvbCESjXu73Mc2Pd"  
YOUTUBE_playlist_ID_105 = "PLJmzdqLGl_E7CbbYpSgH3Gi-rZyvgxr-6"   
YOUTUBE_playlist_ID_106 = "PLhEeP9J9zuhQxeDJhV-5wWEkqzWQpLZK8"  
YOUTUBE_playlist_ID_107 = "PLC-4Xib-LOrcAzmtQmQTI1ofQajX3Lapr"   
YOUTUBE_playlist_ID_108 = "PLFgm_LJYNEttRTuvpr2qnZ3n697sWcHli"  
YOUTUBE_playlist_ID_109 = "PLzkJGO1JtnC7dI3u-LeREsxuJPiAjJimm"  
YOUTUBE_playlist_ID_110 = "PLBA986EF6C0FAA1D9"  
YOUTUBE_playlist_ID_111 = "PLVQ2GDDQBo9UFH9gPlAmEaMDmY6YsbANf"   
YOUTUBE_playlist_ID_112 = "PL388C6956B2EE2189"   
YOUTUBE_playlist_ID_113 = "PL370681250BF00BC3"  
YOUTUBE_playlist_ID_114 = "PL_XY-y6Et_zw1LyZn8hoSGLfmQ5n5QTKn"   
YOUTUBE_playlist_ID_115 = "PLmo4pBukfRoN8SB5RKvfiY9CTl9pI_IFc"   
YOUTUBE_playlist_ID_116 = "PLabJQI0gItOgdGnnxZ5cnww8zYVYSblNH"  
YOUTUBE_playlist_ID_117 = "PL91801CA691D86F9B"   
YOUTUBE_playlist_ID_118 = "PL5D52CC59B62A204A"  
YOUTUBE_playlist_ID_119 = "PL4QNnZJr8sRNKjKzArmzTBAlNYBDN2h-J"  
YOUTUBE_playlist_ID_120 = "PLwWVOy05xAK-px3Z5tWq3NV_5Qp0AEk6b"  
YOUTUBE_playlist_ID_121 = "PLt0efFL_7wt-O5zIYMNphKfGPQi6P9DUt"  
YOUTUBE_playlist_ID_122 = "PLNRm4Qyy2MDWV2xY_K_7kUzcCcv8yrBJg"  
YOUTUBE_playlist_ID_123 = "PLX9U3Rv7Wy7Wbi3iV2uxFo8BOVHjIehUc"   
YOUTUBE_playlist_ID_124 = "PLSRh2BX6ao7P7E0KVcyZ-rYqhTaVVoZrW"   
YOUTUBE_playlist_ID_125 = "PL0C258FE8916ECCB1"   
YOUTUBE_playlist_ID_126 = "PLmS86t_jmQvbpeehASz2Tosvj7d1VN-ZE"  
YOUTUBE_playlist_ID_127 = "PLSt6PZ2gsMLLa4kUHAJxEqaiBzv6lKp4v"  
YOUTUBE_playlist_ID_128 = "PLnUDHJz-31cHA_wlL6dx2mtS23_iqQBGj"   
YOUTUBE_playlist_ID_129 = "PLic91mhoPnxHgzij9We-plBNJo3j1rd8B"   
YOUTUBE_playlist_ID_130 = "PLFR04WQ_ARyQ-xzAX1dJXOUEdsHM9Sr"   
YOUTUBE_playlist_ID_131 = "PLIVbZhwLbExKoDlYntZV_Y1c3bZYz7hAs"   
YOUTUBE_playlist_ID_132 = "PLsC90_43kf5UB_wuLYrtRLG-J8YAPgMCh"  
YOUTUBE_playlist_ID_133 = "PLyUKaKIB05bQuG4s7AgxZ7-j04Ct_Nw82"  
YOUTUBE_playlist_ID_134 = "PLlYKDqBVDxX0Qzmoi2-vvHJjOAy3tRPQ_"   
YOUTUBE_playlist_ID_135 = "PLGBuKfnErZlDI1LRP7ANgsa09x0CrIT6b"   
YOUTUBE_playlist_ID_136 = "PL6EF50C0B0EE0394B"   
YOUTUBE_playlist_ID_137 = "PLcUqPeI0P9OzpYK1UBbeAApBHkEXONi5K"   
YOUTUBE_playlist_ID_138 = "PLyORnIW1xT6wBFoOxTh__8a3dFzbgHYrw"   
YOUTUBE_playlist_ID_139 = "PL1dawt09wsD2gWUa25VF-o2VM8xFisn9r"  
YOUTUBE_playlist_ID_140 = "PLJd7utaEK5kCa1WNGqAFKxgf0MLVegthK"   
YOUTUBE_playlist_ID_141 = "PLmdwo0nDs2HnT8BlW8MuPJ9a9xthJjOvo"   
YOUTUBE_playlist_ID_142 = "PLqc7q6_aVtEedhZhephOsn3lYeoGTdb45"   
YOUTUBE_playlist_ID_143 = "PLDIoUOhQQPlXr63I_vwF9GD8sAKh77dWU"   
YOUTUBE_playlist_ID_144 = "PL1C555E0FCE0DE629"   
YOUTUBE_playlist_ID_145 = "PLqGkpApxFsX_jRp4sDFz9_gwztqqpDZ2U"   
YOUTUBE_playlist_ID_146 = "PL47423FF1E03177A8"   
YOUTUBE_playlist_ID_147 = "PLGtW_kt2Ks8Kv1dBqJjTVlCOBVBN0jR2x"   
YOUTUBE_playlist_ID_148 = "PLaLWNpJCbH_r_0jG3o4r_kUtLB1gUFUdX"  
YOUTUBE_playlist_ID_149 = "PLyjgHc47unfT3BIZo5uEt2a-2TWKy54sU"  
YOUTUBE_playlist_ID_150 = "PLyDDMmF7xacYISTUmhO3bW1A5eaTqqQLU"   
YOUTUBE_playlist_ID_151 = "PLI_7Mg2Z_-4IzxbySOWX5xNT7vDV2HCgG"   
YOUTUBE_playlist_ID_152 = "PLgP_WFDJWjxSgClOt0zBSwiofDIbTLjFj"   
YOUTUBE_playlist_ID_153 = "PL0Ea63JLhmBZFPgxGlOa_QqnR02YYIbxj"   
YOUTUBE_playlist_ID_154 = "PLT0PWRx_9kWsZNX5Rgf8DDFcyAu-zP7C9"   
YOUTUBE_playlist_ID_155 = "PLD58ECddxRngHs9gZPQWOCAKwV1hTtYe4" 
YOUTUBE_playlist_ID_156 = "PLcUqPeI0P9OzpYK1UBbeAApBHkEXONi5K"   
YOUTUBE_playlist_ID_157 = "PLnMN8r-C6UXvv4G6u_MlUoyHLSV2pExKt"   
YOUTUBE_playlist_ID_158 = "PLFoFu8Ubv_K9xY_uhIgPlTCE9YJTeD7Yv"   
YOUTUBE_playlist_ID_159 = "PL539EAB0AAC7115D6"   
YOUTUBE_playlist_ID_160 = "PLVyGBw9rxZW5TdmxxIcbFdwIvDzL9hmTv"
YOUTUBE_playlist_ID_161 = "PLSrd6av4d9FB38oJzinkYo8pKKy75BB75"   
YOUTUBE_playlist_ID_162 = "PL1391237437761842"   
YOUTUBE_playlist_ID_163 = "PLFNoV4a_DdP9B7nKmHzai4ISsN2eqE8qd"   
YOUTUBE_playlist_ID_164 = "PL6F2E55E6C55E3D5C"   
YOUTUBE_playlist_ID_165 = "PL00406755CBB598E4"
YOUTUBE_playlist_ID_166 = "PLop8VH45f9THwLpL0k5E0YJLK6OJRVAzX"   
YOUTUBE_playlist_ID_167 = "PLp5Ie3eol3uMHxW3X2Hai286cbRz9Ieox"   
YOUTUBE_playlist_ID_168 = "PLUFcxlFae4DnP9NIQQ5LQLg4Mx7gwg3XS"   
YOUTUBE_playlist_ID_169 = "PLkpBMluoHSysEDsA9EqpuUSrCHonWYTCx"   
YOUTUBE_playlist_ID_170 = "PLE95D2AF80B98128A"
YOUTUBE_playlist_ID_171 = "PLrnf2axPSKTczDHyYHh1IjNwRdBsqtNUc"   
YOUTUBE_playlist_ID_172 = "PLEXox2R2RxZJwar7F90A4myvLFaNnAbF8"   
YOUTUBE_playlist_ID_173 = "PL1s6OeN3vk7tizc6Aw_X9E41KB0rMZaun"   
YOUTUBE_playlist_ID_174 = "PLgP_WFDJWjxTRPJtV4DV99lGB92rq5we_"   
YOUTUBE_playlist_ID_175 = "PLLDlq9PuU6JfoK6hgy1dmGMdfRLjs8CsJ"
YOUTUBE_playlist_ID_176 = "PL463FB203BC5D8EC5"   
YOUTUBE_playlist_ID_177 = "PL8C21E6E62BC8A8A5"   
YOUTUBE_playlist_ID_178 = "PL1z-GMlijJafEHDMomXf6XOZGI5t1F5MW"   
YOUTUBE_playlist_ID_179 = "PLu9Vz-S8dcTFRigm63_S_bIQ3z_NvdOX9"   
YOUTUBE_playlist_ID_180 = "PLovpXliBbRss40lCvrKevsLcWgcE-xuZM"   
YOUTUBE_playlist_ID_181 = "PL366DECE00BAB19C3"   
YOUTUBE_playlist_ID_182 = "PL8VbTOsQGdVX1Tudt0UOPXmHVwiNIM65z"   
YOUTUBE_playlist_ID_183 = "PL4gRHIfKL8DQya0XJzTkvBCFfklFpEWBd"   
YOUTUBE_playlist_ID_184 = "PL57F368ABE19E6FF2"   
YOUTUBE_playlist_ID_185 = "PLj9Qm0ntwRlIkVaCDDkJu4GZViNmL6Fhl"   
YOUTUBE_playlist_ID_186 = "PL12A5B8B4A1F506DB"
YOUTUBE_playlist_ID_187 = "PL15DB3F186EC6E958"   
YOUTUBE_playlist_ID_188 = "PLRgFSnfiHYbISNOAmZaTuycFRBC8gLguz"   
YOUTUBE_playlist_ID_189 = "PLMEZyDHJojxOOz4VZh2Gt5QQaK8bAxQlM"   
YOUTUBE_playlist_ID_190 = "PLpMUJrYyZ562siCuou1Yh-99IhCgmXFAE"   
YOUTUBE_playlist_ID_191 = "PLAE767E2C26EB00D0"   
YOUTUBE_playlist_ID_192 = "PLRIBrCahDV_OEFbTncTT07nFscbBjdBNz"   
YOUTUBE_playlist_ID_193 = "PLllUJyv_BmsswsoCB35HGvZdIDgvpyX-9"   
YOUTUBE_playlist_ID_194 = "PL0584DD2033D1086E"   
YOUTUBE_playlist_ID_195 = "PL9CE015AC978E88FE"   
YOUTUBE_playlist_ID_196 = "PL7E0B0B126525E358"   
YOUTUBE_playlist_ID_197 = "PLeC3KXKbXai6aTB6cU9em_7GRkFg7juDg"   
YOUTUBE_playlist_ID_198 = "PLC0DD13A1FB960F3B"   
YOUTUBE_playlist_ID_199 = "PLA9iOvQBvAVku6TCer7bVojGprtMK2vt7"   
YOUTUBE_playlist_ID_200 = "PLC440F892363574D8" 
YOUTUBE_playlist_ID_201 = "PLrKtgKTQpf4N-SgnWulfsb2t_a7_hAQLz"   
YOUTUBE_playlist_ID_202 = "PLH22-xSMERQpEWdqQbcaCP0kNutOr1Az8"   
YOUTUBE_playlist_ID_203 = "PL_imCSk1tVkrvmt9sRXjC0qNAWHfMTd2S"   
YOUTUBE_playlist_ID_204 = "PLAAB4A49331A7D7E7"   
YOUTUBE_playlist_ID_205 = "PL0LafXFmvfJxn4Dj-NlP3lKa_WBXE1b9u"   
YOUTUBE_playlist_ID_206 = "PL1D3254DC1A2192DB"   
YOUTUBE_playlist_ID_207 = "PLgpb1OoASakpNUwnJyUbbHtOwDWEg3F6"   
YOUTUBE_playlist_ID_208 = "PLED03B2E1FC47994B"   
YOUTUBE_playlist_ID_209 = "PLZJclMlxrlQjZbdnrfdHnybQkfcxuYrrv"   
YOUTUBE_playlist_ID_210 = "PLtgmCD5wbB8NGQQ5Qqth9uWIvvgpvHV4n"   
YOUTUBE_playlist_ID_211 = "PLB88AE4A3A7B45DB8"
YOUTUBE_playlist_ID_2112 = "PL5BNaoYrNzWOPFmlg5F7TA9mFVn42RSER"
YOUTUBE_playlist_ID_212 = "PLVMTgzzMzyq_PidMRACn-ifykQxR4IlUR"   
YOUTUBE_playlist_ID_213 = "PL79E4245F0137AA18"   
YOUTUBE_playlist_ID_214 = "PL6CD0C8E936F9D2B1"   
YOUTUBE_playlist_ID_215 = "PLE572452B578F4B90"   
YOUTUBE_playlist_ID_216 = "PL702C290EA963E487"   
YOUTUBE_playlist_ID_217 = "PLfWVgaByq8qnE-XgmxPaa_F0uEsbex_mv"   
YOUTUBE_playlist_ID_218 = "PLcWc2gCo2k_b22siNj8Mueh8IGCwB1SlJ"   
YOUTUBE_playlist_ID_219 = "PL5B408043A1CBA476"   
YOUTUBE_playlist_ID_220 = "PLVgGT_m10yKIIcafib3W7rSDYLxQMgBMB"   
YOUTUBE_playlist_ID_221 = "PLriE5FcoFSQ5Xd-cz_qVpFuxCMIzAQ3l8"   
YOUTUBE_playlist_ID_222 = "PLZNjddY6GSNMONX0iQvtAff3w5B5hSYpU"   
YOUTUBE_playlist_ID_223 = "PLA50904415C9A55C7"   
YOUTUBE_playlist_ID_224 = "PLbfluqsV6sopOQ-6UUBR84LH5CJOJ-Qrj"   
YOUTUBE_playlist_ID_225 = "PLniulnHY2D_tc_BMPmhWFpOSKO0DL1KyC" 
YOUTUBE_playlist_ID_226 = "PL3C91B863301E250F"   
YOUTUBE_playlist_ID_227 = "PL574FBF341B72DAD5"   
YOUTUBE_playlist_ID_228 = "PLZEQ-5ryd32SZE2qS_9vHcUy64j-VNvBI"   
YOUTUBE_playlist_ID_229 = "PLvz78UNxtDruCicAvERgXFk2XVgiBn_4y"   
YOUTUBE_playlist_ID_230 = "PLCD354CC986E6EEFB"   
YOUTUBE_playlist_ID_231 = "PLgO5hdZN3QEezisE8Yh8DoLo7AKa7iU5V"   
YOUTUBE_playlist_ID_232 = "PLaLEDUEJDVW7v9K_DVjh0Ztr3xStkusFd"   
YOUTUBE_playlist_ID_233 = "PLC787958DD0D029F7"   
YOUTUBE_playlist_ID_234 = "PLIhLN7Z5xAvFXp0cqoWPHYt2XR4Q9o_RQ"   
YOUTUBE_playlist_ID_235 = "PL54D3F57300A406FA"   
YOUTUBE_playlist_ID_236 = "PL9A75E2D7D7F7EDB0"
YOUTUBE_playlist_ID_237 = "PLDulVecyRMFu-dHBbG2Q34VbwGJFJi1a6"   
YOUTUBE_playlist_ID_238 = "PL9O0WzI1PE_kRQAmirYyAZZmB4efi5y47"   
YOUTUBE_playlist_ID_239 = "PLNGA8uZjCGaVwUsHIV_KODTptbIfLSNTj"   
YOUTUBE_playlist_ID_240 = "PLAtuHZ7V5lmvmLtBmU8fQ8rOKLoJz39s4"   
YOUTUBE_playlist_ID_241 = "PLcVBgoDlDE9Zk_EZTFeEghMgMm-Lrqvbs"   
YOUTUBE_playlist_ID_242 = "PLAED3B191D3475000"   
YOUTUBE_playlist_ID_2421 = "PLmkVH97Tfm54Mnh89A1spmdcMAaoTU2ML" 
YOUTUBE_playlist_ID_243 = "PLer6HEZnCnBsDub85LC8JqpD-5Z0cn5BN"   
YOUTUBE_playlist_ID_244 = "PL61E0653CBB2EE166"   
YOUTUBE_playlist_ID_245 = "PL3CF12D3F9D2AF98C"   
YOUTUBE_playlist_ID_246 = "PLB4A16B73E6B770F8"   
YOUTUBE_playlist_ID_247 = "PLReI40KGodv4AQ6_v7gO92ezfX81kFSYy"   
YOUTUBE_playlist_ID_248 = "PLwph6LWZvBqV0gO08ymr_z-2YQinmPAe0"   
YOUTUBE_playlist_ID_249 = "PL1MMYn9UvtEDeIizXwFs22wQ-9M-pPtzP"   
YOUTUBE_playlist_ID_250 = "PLQsoGpd-IvXDsEZpwiMkm0gy8LNY2SZMG" 
YOUTUBE_playlist_ID_251 = "PL-hvaaoSDXQJpFhQYRkEjc_Zh4Sd65c-e"   
YOUTUBE_playlist_ID_252 = "PLQGrRTjQT3n8i34NHwvBVkgVDFW7yWLJP"   
YOUTUBE_playlist_ID_253 = "PLH6S8OjNLi-IRZYaUcmgCxmjiATDJQgqc"   
YOUTUBE_playlist_ID_254 = "PL9tY0BWXOZFtSsWJiobWz7RJuNpyGem5o"   
YOUTUBE_playlist_ID_255 = "PL5viewcavnJRLBTzfr2lotjfbBec_WfsO"   
YOUTUBE_playlist_ID_256 = "PLRBqtmUVTq9ojbbWzzPUYRbbE_KiolSmN"   
YOUTUBE_playlist_ID_257 = "PL8384361C552AE037"   
YOUTUBE_playlist_ID_258 = "PL9tY0BWXOZFv7G2CZp_v2rD-YxoFek5mw"   
YOUTUBE_playlist_ID_259 = "PLdv4Q1bUw92mbNJaH2ZfxstbT3yzg5TSf"   
YOUTUBE_playlist_ID_260 = "PLqRG33kmyQ-bQh1h_xu2A3iGlAIXtLBIC"   
YOUTUBE_playlist_ID_261 = "PLMCTxUMSkPJvmJdn46YSM9ON1ZJnDWsaE"
YOUTUBE_playlist_ID_262 = "PLVgGT_m10yKI5TeXQSaolhacnaRrPYAgU"   
YOUTUBE_playlist_ID_263 = "PL4471CADD811E98AC"   
YOUTUBE_playlist_ID_264 = "PLX8S4ptxX3CHezw1JDnwAH7CZLFGpj0z-"   
YOUTUBE_playlist_ID_265 = "PLkQgYGT4OQxQepqr92Fq2WPZoGPLSzn4v"   
YOUTUBE_playlist_ID_266 = "PL1D12230C0AB77258"   
YOUTUBE_playlist_ID_267 = "PLA5C96BE314DFBFE1"   
YOUTUBE_playlist_ID_268 = "PLUjtkJHrtwwMZhO_wzqqRqTU6dxHfda48"   
YOUTUBE_playlist_ID_269 = "PL1315ADEE7591C789"   
YOUTUBE_playlist_ID_270 = "PLcrQPzTzzkny2fYRlkhcFaCP6dlIyWYla"   
YOUTUBE_playlist_ID_271 = "PLSSFaMhDbnSgZif1XFj9DoLBM8nXI-VaV"   
YOUTUBE_playlist_ID_272 = "PL46F0DA8FEE3D05EC"   
YOUTUBE_playlist_ID_273 = "PL356E76935BD3436D"   
YOUTUBE_playlist_ID_274 = "PLluQRbJkwPWLDgzdDq7B7G-_QgKJNRxyH"   
YOUTUBE_playlist_ID_275 = "PLH583WMsSz85HljEkmsdJeF4-OWjwg6By" 
YOUTUBE_playlist_ID_276 = "PLkjxy7rAU7-fmfF6v-uJ1GlLk8WQv7M7U"   
YOUTUBE_playlist_ID_277 = "PLeOrAymWvmKv0pIEiWQIghn8j20Tk4qh_"   
YOUTUBE_playlist_ID_278 = "PLED95D4508CADA5BD"   
YOUTUBE_playlist_ID_279 = "PL_JoceHzJP227aLkv3lxDEI-_pgWJoGP1"   
YOUTUBE_playlist_ID_280 = "PLXLXo07HMXlj6swhszmAX54CNYWRONg76"   
YOUTUBE_playlist_ID_281 = "PL8Lpw39GxwbN5LUfSWw6l1zk-0x9qdoU6"   
YOUTUBE_playlist_ID_282 = "PLA910D381CD5AF74E"   
YOUTUBE_playlist_ID_283 = "PLVsyHu2yDLkzdYcDjz8yqw84CmcYZGCIt"   
YOUTUBE_playlist_ID_284 = "PL686F2F3A5367E6AF"   
YOUTUBE_playlist_ID_285 = "PL6AA65AC8EF2C778A"   
YOUTUBE_playlist_ID_286 = "PLognobB2_kXNs0xgH6wuhs2NfY4SxuOo4"
YOUTUBE_playlist_ID_287 = "PL8966944989656177"   
YOUTUBE_playlist_ID_288 = "PL4637097E6C3B9FFA"   
YOUTUBE_playlist_ID_289 = "PL1B208F7389718B08"   
YOUTUBE_playlist_ID_290 = "PL3DF195124B30541F"   
YOUTUBE_playlist_ID_291 = "PL8i09dj_8lqJFAqzj-HC65_PflY4fXZBe"   
YOUTUBE_playlist_ID_292 = "PLbfvV7Jk4y2GN1LMUijSaEcpmJCgShESI"   
YOUTUBE_playlist_ID_293 = "PLbAXYi_3XRupWmH2RsJhVSxUyDrgxiMzo"   
YOUTUBE_playlist_ID_294 = "PLYl_uowvUetAztlFeZE246wLsMhAt20T3"   
YOUTUBE_playlist_ID_295 = "PL9EA66637B199D004"   
YOUTUBE_playlist_ID_296 = "PL297bVu19DjKWZ-FL4bS9yoTRahZ7r0tf"   
YOUTUBE_playlist_ID_297 = "PLkvGdzRIKQcHNQFDtxv_e9s2ztevQlTIp"   
YOUTUBE_playlist_ID_298 = "PL72D7EDFFBD267A94"   
YOUTUBE_playlist_ID_299 = "PL4X0crpaJ94UK9iL_IFKcgpQkjwoP_TG5"   
YOUTUBE_playlist_ID_300 = "PLHjrfqfZxtq8Dq2PU3fWn8zK2clcduzfH" 
YOUTUBE_playlist_ID_301 = "PLE0FDCC00FF662791"   
YOUTUBE_playlist_ID_302 = "PL3ZhygAxAIEKh_uDisE_YTzMgkHSI2ADP"   
YOUTUBE_playlist_ID_303 = "PLA621DF4DA8243B5A"   
YOUTUBE_playlist_ID_304 = "PLtclzMEXudoOKKQkaoZ2S5-NY023gzFIR"   
YOUTUBE_playlist_ID_305 = "PLCnZ3VflDNT8TiIZwzSaU3sht2sgsr0w-"   
YOUTUBE_playlist_ID_306 = "PL2761826E95AA8627"   
YOUTUBE_playlist_ID_307 = "PL08713D57D31A4EC2"   
YOUTUBE_playlist_ID_308 = "PL2YQ9CDud0V6fc9xvSveHKd969jPUG8HH"   
YOUTUBE_playlist_ID_309 = "PLETRs3ajB8Y66Lq829xq-0grC8P0_k7hg"   
YOUTUBE_playlist_ID_310 = "PLtiMAzVCLC1CZhSwPdysLeB-KLMemRU_A"   
YOUTUBE_playlist_ID_311 = "PLLVPM-EDnX_kqmoIisQKs1ZNzGlQkddPH"
YOUTUBE_playlist_ID_312 = "PL282E56F9AEB053AD"   
YOUTUBE_playlist_ID_313 = "PL1F9mvbjP-UKdjsIf1-_CKPwmYDbJrgzU"   
YOUTUBE_playlist_ID_314 = "PLVT2cNxYuqywN78mv0rW6WVNa5C00QZOD"   
YOUTUBE_playlist_ID_315 = "PLEoQn-F0DgbCp0rWizm5H9jmzetBS-Z3v"   
YOUTUBE_playlist_ID_316 = "PLA8ACC4996D23A2D1"   
YOUTUBE_playlist_ID_317 = "PLelje9VYgWJxeAGveMKFFMHeDjhBHWm6w"   
YOUTUBE_playlist_ID_318 = "PLM2u4LcB9Qs8jxo1g9MJq-jRTKY4-V78e"   
YOUTUBE_playlist_ID_319 = "PL1223A48250584FA6"   
YOUTUBE_playlist_ID_320 = "PLPk5QlXG46mOxwuS6sq_4GxPa2IBVdCcw"   
YOUTUBE_playlist_ID_321 = "PLnb8ASKvc3bqQ7-jtO6L8OBjstvcAyCOU"   
YOUTUBE_playlist_ID_322 = "PLA0291DBAF0331F72"   
YOUTUBE_playlist_ID_323 = "PLMEZyDHJojxMYcmDeTKrusu36pheSLe_e"   
YOUTUBE_playlist_ID_324 = "PLnb8ASKvc3bqDw5KhlqvG87O8qM_kxwAw"   
YOUTUBE_playlist_ID_325 = "PLMEZyDHJojxOivUPWX1aasnKcpau8WZfP" 
YOUTUBE_playlist_ID_326 = "PL33B94EFA1AC7B225"   
YOUTUBE_playlist_ID_327 = "PLrf3rQKRuYFsX8EDIFODvmFC3655vTGbc"   
YOUTUBE_playlist_ID_328 = "PLIM_aEL234yTWEQcrqBWzdk_Ey6K05c2U"   
YOUTUBE_playlist_ID_329 = "PLX5_So5n4FY8zDaePEDZckealfQGlM3CW"   
YOUTUBE_playlist_ID_330 = "PLgaFNC_I_Zkl_-m5UgZVHNCekltAPm4ZI"   
YOUTUBE_playlist_ID_331 = "PLq3UZa7STrbpK7EpASU0uS4cx9g1if1ar"   
YOUTUBE_playlist_ID_332 = "PLby7aGz-99NE3LzT--kcwrJLq84RQV8Qj"   
YOUTUBE_playlist_ID_333 = "PLA2FC1F0D486E46CD"   
YOUTUBE_playlist_ID_334 = "PLaymMHeZocbZoudV5AhAsPMj2LYziFUvi"   
YOUTUBE_playlist_ID_335 = "PL73A333D40E72257B"   
YOUTUBE_playlist_ID_336 = "PLAE1CBD6C535383E7"
YOUTUBE_playlist_ID_337 = "PL6BTofJsuqJqvlhSM-YqEc93VvPMB3QWI"   
YOUTUBE_playlist_ID_338 = "PLC9FA360F254A23DB"   
YOUTUBE_playlist_ID_339 = "PLk6PQK9TLQcjGx57PPCj-rtbbxoHSgKBN"   
YOUTUBE_playlist_ID_340 = "PLRaF-uDStGYKfmsCeTNwrvrD8ou8nJXS0"   
YOUTUBE_playlist_ID_341 = "PLMKA5kzkfqk2GEImRCIqGqWmQvKYygUhG"   
YOUTUBE_playlist_ID_342 = "PLDAD12B2D8D1A6F27"   
YOUTUBE_playlist_ID_343 = "PLOtQlPby_DM9wyWgSsbYtLXcgDlobHvCg"   
YOUTUBE_playlist_ID_344 = "PL9t6nPQdrrKydft7kSeJ_LcVogfMqBj-v"   
YOUTUBE_playlist_ID_345 = "PL23A11132CD8400CD"   
YOUTUBE_playlist_ID_346 = "PL_UCDs2ps_73D9qOeYUE36HvGd4wyrG40"   
YOUTUBE_playlist_ID_347 = "PLAADGdv4DJW5e0O_RwmRUZDCRJU8rSwfG"   
YOUTUBE_playlist_ID_348 = "PLcVBgoDlDE9a-n25UuoASV2yKH-PRRUTT"   
YOUTUBE_playlist_ID_349 = "PLACC1097D7C4230C3"   
YOUTUBE_playlist_ID_350 = "PL6570579D0CF62486" 
YOUTUBE_playlist_ID_351 = "PLCCAB3C8590D69DC1"   
YOUTUBE_playlist_ID_352 = "PLIhLN7Z5xAvEURXboGP6niaIzlcw-o9Dd"   
YOUTUBE_playlist_ID_353 = "PL9RNWjHqrSKn75gfF9Hpg_xFfrCdJvBKC"   
YOUTUBE_playlist_ID_354 = "PLXhfRoiJBIisw1fw-lXan125yhXkwcIT8"   
YOUTUBE_playlist_ID_355 = "PLA06D691B470692F7"   
YOUTUBE_playlist_ID_356 = "PL71A9E09DEF0CE017"   
YOUTUBE_playlist_ID_357 = "PLAB88CF3B8B281FBE"   
YOUTUBE_playlist_ID_358 = "PLYAgTyCt4-2Y2PHuvfkMsJ51rReesuATp"   
YOUTUBE_playlist_ID_359 = "PLEc7XU_sm7I_43VFm5WQXJRbMiHgQVbjw"   
YOUTUBE_playlist_ID_360 = "PL2E846F203F5D963F"   
YOUTUBE_playlist_ID_361 = "PL4NdvF1C74HSXGbM02yrbzQHE9bGB-zVP"
YOUTUBE_playlist_ID_362 = "PLF4BDF2E98AC6ACD2"   
YOUTUBE_playlist_ID_363 = "PLB78DD4B32344E269"   
YOUTUBE_playlist_ID_364 = "PLWSt2DnFGE9s6xFE6t30MRqupz5-VD1ql"   
YOUTUBE_playlist_ID_365 = "PLC8198E08BB1AB8AA"   
YOUTUBE_playlist_ID_366 = "PLmBrIbV68uaA1fMSSGV0JBznRV5WIlrvn"   
YOUTUBE_playlist_ID_367 = "PL9tY0BWXOZFtEo1b8IQpwQ1g775FIYh7r"   
YOUTUBE_playlist_ID_368 = "PLp3o6lwxnqMkm9dUECwqVBQY0IN6n1wH_"   
YOUTUBE_playlist_ID_369 = "PLL1g3RhI-vhlLejU0uTYgzpvomdsqmBQH"   
YOUTUBE_playlist_ID_370 = "PLfIsADRe5x-mcah6DL3B_IVfl8K6R_0QX"   
YOUTUBE_playlist_ID_371 = "PLh_5LL6VRZMYElA9INhiLJyy9zL2icHTc"   
YOUTUBE_playlist_ID_372 = "PL119816F23E12BCCB"   
YOUTUBE_playlist_ID_373 = "PLE5E950E00A8A23C2"   
YOUTUBE_playlist_ID_374 = "PL301D7644A9253C61"   
YOUTUBE_playlist_ID_375 = "PLWdWnbKPnT0R0I7GEP73-rHSz4qTuDsyt" 
YOUTUBE_playlist_ID_376 = "PL5D7C0F235DD66CEB"   
YOUTUBE_playlist_ID_377 = "PL21tX2h3EFZcoAvEITJnImhomzSdCj__O"   
YOUTUBE_playlist_ID_378 = "PL7C80D90FB59806FE"   
YOUTUBE_playlist_ID_379 = "PL82D5EAE2E85B22DA"   
YOUTUBE_playlist_ID_380 = "PLC6707556C37C4FDF"   
YOUTUBE_playlist_ID_381 = "PL_yH9Q5syvqhPtzRtUO-H3wKvl7EcdjMT"   
YOUTUBE_playlist_ID_382 = "PLqRDo7HR1AcyCNef39aYYsQhgFKMr7FpW"   
YOUTUBE_playlist_ID_383 = "PLbnF-C61Hi8u5fS2TGhp-nT62GOHTCpZR"   
YOUTUBE_playlist_ID_384 = "PL84EDE1A11AEFCCB8"   
YOUTUBE_playlist_ID_385 = "PLeU-9LrH2xOFXTREjOECDc9ViPQJwSvti"   
YOUTUBE_playlist_ID_386 = "PLDFot90ZSkC_sZIpSGGSoqkd0lvsipn6K"
YOUTUBE_playlist_ID_387 = "PLBiUXsOXYmCbx0FGEbR3i_yWOx2iOBRvf"   
YOUTUBE_playlist_ID_388 = "PL6vqo3BZ396WARJmJZbkhKsYzGrhCA9Rj"   
YOUTUBE_playlist_ID_389 = "PLLsIO2RaTOnWg3COG30DB36Rm19Ro9393"   
YOUTUBE_playlist_ID_390 = "PL545EBEA68E51289A"   
YOUTUBE_playlist_ID_391 = "PL49DB01A161111570"   
YOUTUBE_playlist_ID_392 = "PLvu8wCghVq058TUcWJATbEVA6yPjZsA1r"   
YOUTUBE_playlist_ID_393 = "PLQ7GKO_eJjw04rj-RmtZiJfbys0romkWi"   
YOUTUBE_playlist_ID_394 = "PLeiUnYpf86URvNV3UlXmJonVbgnJKlvrc"   
YOUTUBE_playlist_ID_395 = "PLBFE3CE3C9D2DA2A4"   
YOUTUBE_playlist_ID_396 = "PLrTrS3x8ShRI-ztkAewW2g57ukRbJuPG-"   
YOUTUBE_playlist_ID_397 = "PLZo-SRqPbntvkbMnWv1lsIqG6JH5oB3-n"   
YOUTUBE_playlist_ID_398 = "PLCF5A3089449F9206"   
YOUTUBE_playlist_ID_399 = "PL8269CD636FCD1878"   
YOUTUBE_playlist_ID_400 = "PL9FFC42356C3C87AD" 
YOUTUBE_playlist_ID_401 = "PL490CD25236E0824B"   
YOUTUBE_playlist_ID_402 = "PLGYE0BUUzhDPmao2ALIrr1j2rd9abHMKP"   
YOUTUBE_playlist_ID_403 = "PL94DC2785DB5D6889"   
YOUTUBE_playlist_ID_404 = "PLwMXTH80keS57IiavZq18PutbObtWpwfI"   
YOUTUBE_playlist_ID_405 = "PL3036C05CC3EC0FEF"   
YOUTUBE_playlist_ID_406 = "PLfqlpuz-LWL28EHinbSqNhj2nFZS-WQ-I"   
YOUTUBE_playlist_ID_407 = "PLBF29177C5D2545EF"   
YOUTUBE_playlist_ID_408 = "PLB507CC895F31BE07"   
YOUTUBE_playlist_ID_409 = "PLgAQes15lM1NSkDXTnvA6zeubQ94b3CTi"   
YOUTUBE_playlist_ID_410 = "PLE5C271899AE85D68"   
YOUTUBE_playlist_ID_411 = "PLo_h4k58Suz-PUA7LJE9qZEAGy0gkn15r"
YOUTUBE_playlist_ID_412 = "PLB94D721E8C56F510"   
YOUTUBE_playlist_ID_413 = "PL2E258831F7A321F3"   
YOUTUBE_playlist_ID_414 = "PL5m2xEMryylqPLhfTaQbuQv0I4Rj96qzE"   
YOUTUBE_playlist_ID_415 = "PLCB1D33824DF694EC"   
YOUTUBE_playlist_ID_416 = "PLPsC4EHY8H1yyHNqF0tThrGvtlnYDevio"   
YOUTUBE_playlist_ID_417 = "PL01704F707A55EF79"   
YOUTUBE_playlist_ID_418 = "PLPbCXiOeC78fFoikLvKKPHduJTYy46md6"   
YOUTUBE_playlist_ID_419 = "PL-wcKZ0usf2xRzGG2nFH9GNJSmsiWY01W"   
YOUTUBE_playlist_ID_420 = "PL30490FAADC79FBDA"   
YOUTUBE_playlist_ID_421 = "PLDE7406D26D7C0C45"   
YOUTUBE_playlist_ID_422 = "PLq3UZa7STrbpBjxItYWh2ezQj3kwoSA8s"   
YOUTUBE_playlist_ID_423 = "PL4q5myTDSpAsg_UMr1QbrGRDeAH4bnUX6"   
YOUTUBE_playlist_ID_424 = "PLF1D793B61571DD4A"   
YOUTUBE_playlist_ID_425 = "PL03DC1B33BDAE6A67" 
YOUTUBE_playlist_ID_426 = "PLzrRkSuSpF2Oaq2yKAkq4EopHiInxFszR"   
YOUTUBE_playlist_ID_427 = "PLgzm-4W_Rws2PG-qWHcssGXvJz_3Gcu9M"   
YOUTUBE_playlist_ID_428 = "PLIISIRE_qI9vZfOX6iOgoyky3veBeOkKe"   
YOUTUBE_playlist_ID_429 = "PLBeeiCx5Kc2uJ7TjYPpQyLaNkHDKegMBB"   
YOUTUBE_playlist_ID_430 = "PLuGTG9Jnl26qNO_wSkjs5-wncuApSEdyJ"   
YOUTUBE_playlist_ID_431 = "PL-HTuqRSXexeuHyM1D9OBvsog2eNzpEkv"   
YOUTUBE_playlist_ID_432 = "PLVKyRPHlceGv2coExv4wXgRdaKvt_HaDF"   
YOUTUBE_playlist_ID_433 = "PL_NbILIrNQ3MDuKA9jF43aDdglBgFG4qk"   
YOUTUBE_playlist_ID_434 = "PLEWdEuIEMHXXqXTVlfAVhEnmZUByluv_T"   
YOUTUBE_playlist_ID_435 = "PLQtqTMmRSduu0x0hD-jZUUWiagB6SoIXr"   
YOUTUBE_playlist_ID_436 = "PLYq7ixysvQ8qac-3tCYdt9Ckzc-B_g01L"
YOUTUBE_playlist_ID_437 = "PLzAzZbNGlKlo5o1r0SoUUwcSymGy7eQrg"   
YOUTUBE_playlist_ID_438 = "PLzaV6_B-O2YMUHCmY0cklUs_MVwqc480-"   
YOUTUBE_playlist_ID_439 = "PLSL9DB9AUS4NXYjaIqcEBfqk0plJpupQO"   
YOUTUBE_playlist_ID_440 = "PLM9IqydaE5Qg-5QGk9hZzxFFc0qDAlk2u"   
YOUTUBE_playlist_ID_441 = "PL5E298F634DE0F5BE"   
YOUTUBE_playlist_ID_442 = "PL0eheHgLSuZC2mpgfwskVw1UqC-isnatw"   
YOUTUBE_playlist_ID_443 = "PL616EA300F070272C"   
YOUTUBE_playlist_ID_444 = "PL1FEA41C25BA65D50"   
YOUTUBE_playlist_ID_445 = "PL0DB47430DB7B19DD"   
YOUTUBE_playlist_ID_446 = "PLE85CC75CADDAC253"   
YOUTUBE_playlist_ID_447 = "PL5yKAm2KCmJf-nK6ffTgtBE9ZtknLzblr"   
YOUTUBE_playlist_ID_448 = "PLdfPuC71j6-92mJwCB59NfOPQxB-WWgg7"   
YOUTUBE_playlist_ID_449 = "PLw1nLsex_Q8K2Q-K9mq6nUKQw6osrHaN9"   
YOUTUBE_playlist_ID_450 = "PLE1179D279C08BE4A" 
YOUTUBE_playlist_ID_451 = "PL_KyKlouByE9b3jTxWwwy2kvQnVX9NnFd"   
YOUTUBE_playlist_ID_452 = "PL8xUXGytbOQmRs2kqId8UiFB8gEdQ8ojR"   
YOUTUBE_playlist_ID_453 = "PLJ5cGDOKPw72LWDHjlfcwjnAiKvxOSa-C"   
YOUTUBE_playlist_ID_454 = "PL4iSbgi3WlCqFsEwfbun3ZquM-MPznJaR"   
YOUTUBE_playlist_ID_455 = "PLq3UZa7STrbpX13PljcNH6hmyrSbcMYK8"   
YOUTUBE_playlist_ID_456 = "PL4pGkk3QBW28n6QCBWcmE76Ro7ONEzlMG"   
YOUTUBE_playlist_ID_457 = "PLpXA1IqBgeZTdZRUjM1kfLYxozJu6Wqvu"   
YOUTUBE_playlist_ID_458 = "PLF10CD8DBC7E24650"   
YOUTUBE_playlist_ID_459 = "PLM3BWIah4Jd6juUG678HMNG-METNTarmg"   
YOUTUBE_playlist_ID_460 = "PLtNMkp_GwStcR3Z6iOGj5pElWIlTU9xVh"   
YOUTUBE_playlist_ID_461 = "PLU7AqrWILU6U4r-u2p3Awynx7zK9OUprh"
YOUTUBE_playlist_ID_462 = "PLrwXzbX3SWnu1H2yesZA0-28anAKGK6ZE"   
YOUTUBE_playlist_ID_463 = "PLqss3L6F2c-fdGzpvsTvNx6jBxfCYfZY_"   
YOUTUBE_playlist_ID_464 = "PLYynWIEvzrvJz47wIwnvITIgRId3F5FtP"   
YOUTUBE_playlist_ID_465 = "PLeoBVKHKNsGrwPxGPZjVGWBOoXJARe5Ca"   
YOUTUBE_playlist_ID_466 = "PL0D4AA1524FE41E11"   
YOUTUBE_playlist_ID_467 = "PLTc5tHPDpnJ__Ne9Z3aCQ_Oq91-CNaku3"   
YOUTUBE_playlist_ID_468 = "PL-yLAUhj7Tv0dspscFI7asl3U8UdF4XqG"   
YOUTUBE_playlist_ID_469 = "PLakVP-Hif-xGA-VFwYubSNfbnUZdLvDh4"   
YOUTUBE_playlist_ID_470 = "PLE722D7508EB8E461"   
YOUTUBE_playlist_ID_471 = "PLbXEBkoCkCnZ6U8KlTRi8I6qNtqbIQTW1"   
YOUTUBE_playlist_ID_472 = "PLOUzUrKhNae51rhMgkY_v1BWWISuvjmkk"   
YOUTUBE_playlist_ID_473 = "PLEC4A6ACBA34E2600"   
YOUTUBE_playlist_ID_474 = "PL4iSbgi3WlCpM2bG4ybcZdttLzyWxbEzf"   
YOUTUBE_playlist_ID_475 = "PLTc5tHPDpnJ-p7MZIpeIvLiHbE7gZfz66" 
YOUTUBE_playlist_ID_476 = "PLF70335554080E22E"   
YOUTUBE_playlist_ID_477 = "PLD96DBE7E46FAD03E"   
YOUTUBE_playlist_ID_478 = "PL18F13283F8B68C2D"   
YOUTUBE_playlist_ID_479 = "PLE1CBD1B33B341143"   
YOUTUBE_playlist_ID_480 = "PL68G3OPRSzPpitH3oximIlV5gXQStNWpv"   
YOUTUBE_playlist_ID_481 = "PLv-V6tGqeV2cBboliakj1lN292CgqDGea"   
YOUTUBE_playlist_ID_482 = "PL3MTqeAZhHKD5Ht0pfOKdwhq2tOYKqChg"   
YOUTUBE_playlist_ID_483 = "PL800877997FBC02C2"   
YOUTUBE_playlist_ID_484 = "PLwMXTH80keS6zjxCrvGfzci6tmbHK6tu8"   
YOUTUBE_playlist_ID_485 = "PL5F82E94EFA6258C9"   
YOUTUBE_playlist_ID_486 = "PLF3158488184AA928"
YOUTUBE_playlist_ID_487 = "PLUhqFX6g_9NenFieBfcTO67pamzG7dKVc"   
YOUTUBE_playlist_ID_488 = "PLP02sRgldWRb9LjuQgJ4AfxCd4cxygDrA"   
YOUTUBE_playlist_ID_489 = "PL5rodSuroR-AG4gzm8gmIsB6qVeOMukrm"   
YOUTUBE_playlist_ID_490 = "PLCSfalJkj4wGOm8ZpwhJbr7ZugcqKy-u0"   
YOUTUBE_playlist_ID_491 = "PLUhqFX6g_9Nd-MBiK9eYPz8wpqU4oKrO7"   
YOUTUBE_playlist_ID_492 = "PLnIc8l-6P2z5EQ4soX1AnbH_kp3P_auAK"   
YOUTUBE_playlist_ID_493 = "PLAJtD5xn2t_V2OnzOn3zNnKX9djzIbjnv"   
YOUTUBE_playlist_ID_494 = "PLlHc5zP6BMBjWNs3hHzXsZuLdAYUCqUkN"   
YOUTUBE_playlist_ID_495 = "PL6CB08BA1FA4C3E44"   
YOUTUBE_playlist_ID_496 = "PLkc_Bfs9bx0K3C4H0QQ_9sii9-JRmBLfj"   
YOUTUBE_playlist_ID_497 = "PLBED3EC3449AC0A5E"   
YOUTUBE_playlist_ID_498 = "PLxllXQXRDRfOWXH64yHRIjJPboXmfn7Cd"   
YOUTUBE_playlist_ID_499 = "PLKa5Nd1o-qEQNm3c1phEKUjpQUGdfcyjj"   
YOUTUBE_playlist_ID_500 = "PLVMTgzzMzyq-vOMOXjhUMVjhBSYNMYBlx" 
YOUTUBE_playlist_ID_501 = "PL83C0CF3A66952878"   
YOUTUBE_playlist_ID_502 = "PLB92C37331CFA7BF1"   
YOUTUBE_playlist_ID_503 = "PLMEZyDHJojxNCL2xZLRNpI_5JPScffvB2"   
YOUTUBE_playlist_ID_504 = "PL9309F6E6083B49D5"   
YOUTUBE_playlist_ID_505 = "PLuBXV0aI8TzvQEQQ_l4QmskB7QprT-vsF"   
YOUTUBE_playlist_ID_506 = "PLE926440DD5594B6C"   
YOUTUBE_playlist_ID_507 = "PLBB4F6C1BDF5A66E2"   
YOUTUBE_playlist_ID_508 = "PLc9n2mgXOm-6UEALuKaPDHZZwPJbEHFes"   
YOUTUBE_playlist_ID_509 = "PLZPH1jRsbZrzxXxi-5Hk3V4V0-rzHyz34"   
YOUTUBE_playlist_ID_510 = "PLjzB8TMjdjwN6Uq86_557_NRuP_iLrOiA"   
YOUTUBE_playlist_ID_511 = "PLBjpeVsxVzrcKdaytaNsr9mZvezjc6uQY"
YOUTUBE_playlist_ID_512 = "PL1NQLkz_HA9-zL8gcTlVmGoWoSMXy-V34"   
YOUTUBE_playlist_ID_513 = "PL44808552AB3C4296"   
YOUTUBE_playlist_ID_514 = "PL7zrnXIkwlVypkCzwbSBpSIrdNWPDqfe1"   
YOUTUBE_playlist_ID_515 = "PLMhCGv0XCuctYxpwhcIEeP7uRy3ba1WqQ"   
YOUTUBE_playlist_ID_516 = "PLC6F132BA6B6AF92E"   
YOUTUBE_playlist_ID_517 = "PLrmTe5LGdXcOXW6ohTxWSaNmi68rRLNip"   
YOUTUBE_playlist_ID_518 = "PLB739CB9E62F387E0"   
YOUTUBE_playlist_ID_519 = "PLwyIC8LoPNoVzex4xc6JxessapdR-H6j0"   
YOUTUBE_playlist_ID_520 = "PLAB3B1E4C92BDC0A4"   
YOUTUBE_playlist_ID_521 = "PLDAc319-LXupaLibqGVJf0J_kbj3A1XCM"   
YOUTUBE_playlist_ID_522 = "PLVMTgzzMzyq-v9t0-XKf1s8GnY8ugO_Wn"   
YOUTUBE_playlist_ID_523 = "PL44EBB23ADA2F36A0"   
YOUTUBE_playlist_ID_524 = "PL_71SYGvVoCFfYPAxL08amtC_2GGCvmz-"   
YOUTUBE_playlist_ID_525 = "PLfEbmmnuSabeg5MS-4f1fPod3zsjOQNMQ" 
YOUTUBE_playlist_ID_526 = "PL7B88D80D895B45A2"   
YOUTUBE_playlist_ID_527 = "PLB6D1882930F82ABA"   
YOUTUBE_playlist_ID_528 = "PLvuNxZXOp0VQxcQdwxk8WbgxKBTHGXr8D"   
YOUTUBE_playlist_ID_529 = "PL3DD77D6194A5DE66"   
YOUTUBE_playlist_ID_530 = "PLUhqFX6g_9Ne0ck9QhOViDrIMD_-6Wk17"   
YOUTUBE_playlist_ID_531 = "PL88B438D3A5B7DE84"   
YOUTUBE_playlist_ID_532 = "PLxhfCY00zUPAYUkapGvjIv2dhFVFCc9rP"   
YOUTUBE_playlist_ID_533 = "PLRrqhqzwiJr2fUJ8yxXCyOJpCCQrxbYUS"   
YOUTUBE_playlist_ID_534 = "PLUwpNLwMcwiToue5SLpweK7Zdwhd6AhWn"   
YOUTUBE_playlist_ID_535 = "PLH_DvgjXDIqeg86pPXncSLHCMpq3do0oF" 
YOUTUBE_playlist_ID_536 = "PLDDD50B2632AE928B"   
YOUTUBE_playlist_ID_537 = "PL2PI3BtEVzA7TfhMFjeseXkYvVJpx__ia"   
YOUTUBE_playlist_ID_538 = "PLYq_mcte9NvDA2Xi5Qjl1DrH5LuDKDlAI"   
YOUTUBE_playlist_ID_539 = "PL4sfVCWR8nGI2dS8kus2BjgqmIPKas5Ar"   
YOUTUBE_playlist_ID_540 = "PL162DF0A1EA635492"   
YOUTUBE_playlist_ID_541 = "PLki40DkF9sdieNYY089rxtvBsQe8UMo3C"   
YOUTUBE_playlist_ID_542 = "PLN0pon2Ar7AbZj860kaXa2EuQm5_aK_5J"   
YOUTUBE_playlist_ID_543 = "PLBB9F6B341EBE788E"   
YOUTUBE_playlist_ID_544 = "PLrmTe5LGdXcPr80ekQ0DDY1GPPogYm0b6"   
YOUTUBE_playlist_ID_545 = "PLyQy-tokPWDCSgygKenf1V5Ldgk4W5hO-" 
YOUTUBE_playlist_ID_546 = "PLEB981E95D02EE8E0"   
YOUTUBE_playlist_ID_547 = "PLDABF14A93B588ECD"   
YOUTUBE_playlist_ID_548 = "PLA52A4666DF8787DD"   
YOUTUBE_playlist_ID_549 = "PL36494E8634856791"   
YOUTUBE_playlist_ID_550 = "PL53r_72HW2Gq7W1aLfdnh-J0ebbcMxn_x"   
YOUTUBE_playlist_ID_551 = "PL10697307553142B4"   
YOUTUBE_playlist_ID_552 = "PL0FM4Hk88HorNIaqTP5RdMFWHfEguknkb"   
YOUTUBE_playlist_ID_553 = "PLSoDfeucGhYhdj8-xYdGMvpLhSW1_c6_1"   
YOUTUBE_playlist_ID_554 = "PL10ADF05EDE138B93"   
YOUTUBE_playlist_ID_555 = "PLdyoht_ygUufhezMUCgHWa4OBQETAznQZ" 
YOUTUBE_playlist_ID_556 = "PLuiHoY-HuNM9ynybRD776aJHVbNyRUb_p"   
YOUTUBE_playlist_ID_557 = "PL9tY0BWXOZFtfXKVAXqyTjl3cJddXO7Ci"   
YOUTUBE_playlist_ID_558 = "PL55Ni-v_oWPdjDMp0E5zt-GlqgFCWy95m"   
YOUTUBE_playlist_ID_559 = "PLy6515vXiQhOrkoPQqYQL-T0GR7eTbHvJ"   
YOUTUBE_playlist_ID_560 = "PLEEE0FC03B2C11631"   
YOUTUBE_playlist_ID_561 = "PL11AE103796E8D14F"   
YOUTUBE_playlist_ID_562 = "PLEgIGDMaPLry3vDpLplgdbdG_wQboT3mu"   
YOUTUBE_playlist_ID_563 = "PLaQH-0rR7Mhs5GJ9nBpA2SAytWGCTMwmP"   
YOUTUBE_playlist_ID_564 = "PLqmSVzIbYy5p7j4XxMK4yGCTlAee0in7b"   
YOUTUBE_playlist_ID_565 = "PL659998B48AFDF694" 
YOUTUBE_playlist_ID_566 = "PLUhqFX6g_9NcTrAFbLsz97uRhBZIfBa1K"   
YOUTUBE_playlist_ID_567 = "PL5151B3326274A0C9"   
YOUTUBE_playlist_ID_568 = "PL5yGB_eqIALRfoednx480iOjvXjmIG1Em"   
YOUTUBE_playlist_ID_569 = "PLeChJ_avuyOgP3Me-pg-qkftETsTXQ-8w"   
YOUTUBE_playlist_ID_570 = "PL227EEB7C9E1B7F6B"   
YOUTUBE_playlist_ID_571 = "PL8yDMPBV36b-4VHjgeY7X9YOwoI0qmSiP"   
YOUTUBE_playlist_ID_572 = "PLDX2jvORHkAbf8EIdFF_8lO1AwS_n9Zeq"   
YOUTUBE_playlist_ID_573 = "PLYXC8wAPyQ-t2evU4cNbcw0j4LCFOacCu"   
YOUTUBE_playlist_ID_574 = "PLyACOLem3DUNm_oSlQx52F2adZp87bfDn"   
YOUTUBE_playlist_ID_575 = "PL29662FBF0FC8F98D" 
YOUTUBE_playlist_ID_576 = "PLD8F8D858996445F4"   
YOUTUBE_playlist_ID_577 = "PLDhVYwv-_6NNVVGjCuVywQr_eKY4OKYgc"   
YOUTUBE_playlist_ID_578 = "PLMKA5kzkfqk2RxeZv-vv9yOAYb-W6MNuF"   
YOUTUBE_playlist_ID_579 = "PLLdhG8CrtPg6BYtlLj6_YDc1TYnMb6JAb"   
YOUTUBE_playlist_ID_580 = "PLx4lUNYIahP0bTBZTqTp97YNzzrHscl-b"   
YOUTUBE_playlist_ID_581 = "PLUhqFX6g_9NeuCVJ_sRtTwGaN9MVtoFM7"   
YOUTUBE_playlist_ID_582 = "PLC1760F50DD217D23"   
YOUTUBE_playlist_ID_583 = "PLA5yV_uAHZxGsmcyYOdNeZxd_BMUPdvnG"   
YOUTUBE_playlist_ID_584 = "PL9FOcjmiWH2NjRxjeV7jGPakWDAMrlygp"   
YOUTUBE_playlist_ID_585 = "PLcqF11LIymWl0cFtebuisw1NLzK67eVJr"
YOUTUBE_playlist_ID_586 = "PL5C8EB872CBF1D6A0"   
YOUTUBE_playlist_ID_587 = "PLD77AA07B082B59D3"   
YOUTUBE_playlist_ID_588 = "PLXSlB4yMaoJt0a3U3L0mCfkBl8E9Fb80e"   
YOUTUBE_playlist_ID_589 = "PLp_iBccYqoUnWmePmcEpwcAlZspGcns2x"   
YOUTUBE_playlist_ID_590 = "PL6AePG2tb9je-vw8-DJLzDAjFKcKJSyw4"   
YOUTUBE_playlist_ID_591 = "PLYIuiP4eVykBlqBTPMJr5PT4cweeE-00Y"   
YOUTUBE_playlist_ID_592 = "PL61B14D1DE8E273C2"   
YOUTUBE_playlist_ID_593 = "PL1C8F05D1E2F4A3E5"   
YOUTUBE_playlist_ID_594 = "PLEuEX6d62_ThmL-mWF429JGNb0xgaqyw3"   
YOUTUBE_playlist_ID_595 = "PLA70BDEC842EFD1B1"
YOUTUBE_playlist_ID_596 = "PLRRe_urOjL_-g3mh2I1dOIJbUSmQCErry"   
YOUTUBE_playlist_ID_597 = "PL9tY0BWXOZFvdgp-L95ah3_g_dVyrdG_2"   
YOUTUBE_playlist_ID_598 = "PLA107D57396828C61"   
YOUTUBE_playlist_ID_599 = "PLA93FBFFB92366058"   
YOUTUBE_playlist_ID_600 = "PLehDej4bAH7s23koRAtKV1Tp51RXbPyTx"   
YOUTUBE_playlist_ID_601 = "PLE22oZlNYBeUkIxlGKvhW4jgQw5Td9A52"   
YOUTUBE_playlist_ID_602 = "PLvaqLJe33YM-YYV4QtgChF0xvymnzyHnG"   
YOUTUBE_playlist_ID_603 = "PL55E46876084F0FF1"   
YOUTUBE_playlist_ID_604 = "PL0FE41504CD0BA279"   
# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Pide Tu Cancion MusicHall en el Grupo Telegram @AprendiendoKodi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1+"/",
        thumbnail="https://i.imgur.com/yr7txZt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Pide Tu Concierto aqui en Music Hall en el Grupo Telegram @AprendiendoKodi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_2+"/",
        thumbnail="https://i.imgur.com/6tbCPcq.jpg",
		fanart="https://i.imgur.com/6tbCPcq.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Acid House Groovy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_111+"/",
        thumbnail="https://i.imgur.com/eRy3y8x.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]African Hits Song 2019[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_123+"/",
        thumbnail="https://i.imgur.com/GDCmvY8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Aires De Cuba[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_146+"/",
        thumbnail="https://i.imgur.com/ba6b0aX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alternative rock of the 2000s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_10+"/",
        thumbnail="https://i.imgur.com/V1ZqiX9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alucinante Canto Gregoriano Pop Rock[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_147+"/",
        thumbnail="https://i.imgur.com/TezNQwI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bachata[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_156+"/",
        thumbnail="https://i.imgur.com/eiLCAU9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Baladas De Ayer Hoy y Siempre[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_106+"/",
        thumbnail="https://i.imgur.com/JYDY7w6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Baladas Pop En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_83+"/",
        thumbnail="https://i.imgur.com/WOJzJbw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bast Boosted[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_167+"/",
        thumbnail="https://i.imgur.com/uN5VVWA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Best Classic rock mix[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_8+"/",
        thumbnail="https://i.imgur.com/ZvwVGKf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Best Women Jazz Music of All Time[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_53+"/",
        thumbnail="https://i.imgur.com/qPgX7rO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Big Room[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_175+"/",
        thumbnail="https://i.imgur.com/9QYu2LG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Billboard 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_143+"/",
        thumbnail="https://i.imgur.com/0HzRnK7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Boleros[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_64+"/",
        thumbnail="https://i.imgur.com/52v0FZO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bossanova Canciones en Acustico[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_59+"/",
        thumbnail="https://i.imgur.com/d3kFnc1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Boys Band[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_138+"/",
        thumbnail="https://i.imgur.com/y075DdT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]BSO Canciones De Peliculas Famosas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_84+"/",
        thumbnail="https://i.imgur.com/X0Jm2xZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Canciones Romanticas en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_105+"/",
        thumbnail="https://i.imgur.com/RpbOayc.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Canciones Spot Publicitarios[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_129+"/",
        thumbnail="https://i.imgur.com/G47GcR6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cante Flamenco - Figuras del cante Jondo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_30+"/",
        thumbnail="https://i.imgur.com/Tbi5AfE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chambao Chill Out[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_13+"/",
        thumbnail="https://i.imgur.com/THq2a2S.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chill Out[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_12+"/",
        thumbnail="https://i.imgur.com/yTnsSPZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chillout Lounge - Spotify[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_24+"/",
        thumbnail="https://i.imgur.com/CMhwl96.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chirigotas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_127+"/",
        thumbnail="https://i.imgur.com/ABRt8SO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Clasicos Del Funk[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_110+"/",
        thumbnail="https://i.imgur.com/992TtX4.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Clasicos De La Musica Electronica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_32+"/",
        thumbnail="https://i.imgur.com/GVH8gc0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Clasicos del Rap Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_73+"/",
        thumbnail="https://i.imgur.com/RMZ0aXQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Clasicos del Rock en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_11+"/",
        thumbnail="https://i.imgur.com/KyVQSrI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Conciertos en Directo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_33+"/",
        thumbnail="https://i.imgur.com/D0e8euc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Copla Española[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_70+"/",
        thumbnail="https://i.imgur.com/FnIz7PG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Country De Los 70 80[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_135+"/",
        thumbnail="https://i.imgur.com/Je1f67V.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cumbia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_151+"/",
        thumbnail="https://i.imgur.com/OaVd21R.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Disco Funk Soul 70s 80s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_37+"/",
        thumbnail="https://i.imgur.com/CEelwt2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Disco Hits of the 70s 80s 90s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_38+"/",
        thumbnail="https://i.imgur.com/Tp3VTg0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]El mejor Flamenquito 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_26+"/",
        thumbnail="https://i.imgur.com/r8XeyVC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Europa FM - Lista de Exitos 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_18+"/",
        thumbnail="https://i.imgur.com/J75Rikb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Euskal Musik[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_80+"/",
        thumbnail="https://i.imgur.com/XVeJXCt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Eurovision[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_102+"/",
        thumbnail="https://i.imgur.com/mEDVpJV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ganadores Eurovision 1956-2019[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_103+"/",
        thumbnail="https://i.imgur.com/Qly45Xg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Exitos Radio Ole[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_120+"/",
        thumbnail="https://i.imgur.com/7tNHdSK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fandangos y Cante Jondo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_31+"/",
        thumbnail="https://i.imgur.com/Rf0hkuk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fado Portugues[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_165+"/",
        thumbnail="https://i.imgur.com/9HD48Br.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Flamenco Pop Mix[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_29+"/",
        thumbnail="https://i.imgur.com/8OUagSi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Flashback Romantico Internacional[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_107+"/",
        thumbnail="https://i.imgur.com/8TIN5ff.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Folk Mexicano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_96+"/",
        thumbnail="https://i.imgur.com/PIBo335.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Garaje Rock[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_154+"/",
        thumbnail="https://i.imgur.com/MtZWQ9b.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Girls Power[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_139+"/",
        thumbnail="https://i.imgur.com/vqDri8j.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Glam And Hair Metal de Los 80[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_98+"/",
        thumbnail="https://i.imgur.com/MSfTpef.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Goguettes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_166+"/",
        thumbnail="https://i.imgur.com/2wBrN7y.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gospel Hits 2019[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_131+"/",
        thumbnail="https://i.imgur.com/6jMAiVH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Grandes Exitos de la Musica Indie en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_48+"/",
        thumbnail="https://i.imgur.com/SgDCIxN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Grunge The Best[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_155+"/",
        thumbnail="https://i.imgur.com/qztwyR3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Guitarra Clasica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_42+"/",
        thumbnail="https://i.imgur.com/qWr7skf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Guitarra Clasica Española[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_25+"/",
        thumbnail="https://i.imgur.com/HNHuitY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hard Rock 80s & 90s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_22+"/",
        thumbnail="https://i.imgur.com/BlBjux5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hard Rock 2 De Los 80 y 90[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_94+"/",
        thumbnail="https://i.imgur.com/j106577.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hard Rock Woman Singers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_140+"/",
        thumbnail="https://i.imgur.com/I7xcyNo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hilo Musical Canciones Para Recordar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_87+"/",
        thumbnail="https://i.imgur.com/Ehbz3nY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hilo Musical En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_86+"/",
        thumbnail="https://i.imgur.com/wvT1oqu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hilo Musical Internacional[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_85+"/",
        thumbnail="https://i.imgur.com/q4edbhf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hits Dance 2020 2021 Classifica Mtv[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_39+"/",
        thumbnail="https://i.imgur.com/3ytyF7o.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Humppa Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_168+"/",
        thumbnail="https://i.imgur.com/VQhEqJP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Indian American Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_124+"/",
        thumbnail="https://i.imgur.com/JS8p1k5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jesucristo Super Star Camilo Sesto[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_118+"/",
        thumbnail="https://i.imgur.com/B1iJrPR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Joropo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_164+"/",
        thumbnail="https://i.imgur.com/gTEWlax.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Karaoke En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_144+"/",
        thumbnail="https://i.imgur.com/07zHCNa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Karaoke Internacional[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_145+"/",
        thumbnail="https://i.imgur.com/72SbWDP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kiss Fm Radio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_122+"/",
        thumbnail="https://i.imgur.com/zgtcvHY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]KPOP 2020 2021 Korean Pop Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_119+"/",
        thumbnail="https://i.imgur.com/2dH0kMC.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Las Mejores Rancheras[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_66+"/",
        thumbnail="https://i.imgur.com/g3D7PdH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Latino Total 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_82+"/",
        thumbnail="https://i.imgur.com/U7wOsZk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Late 70s Soul Funk & Disco Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_36+"/",
        thumbnail="https://i.imgur.com/a1F1Guf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mas Escuchado 2019-2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_15+"/",
        thumbnail="https://i.imgur.com/AmoXCbH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mas Nuevo Del Rap Y Hip Hop En Español 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_75+"/",
        thumbnail="https://i.imgur.com/j2rpjC7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Mejores Boleros de Todos los Tiempos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_65+"/",
        thumbnail="https://i.imgur.com/7B9EKjJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Mejores Exitos de Guitarra Española[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_43+"/",
        thumbnail="https://i.imgur.com/StuplSO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mejor Del Country[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_134+"/",
        thumbnail="https://i.imgur.com/urbBmOZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mejor de la Opera Lirica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_116+"/",
        thumbnail="https://i.imgur.com/FAyOGUX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mejor del Reggae[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_56+"/",
        thumbnail="https://i.imgur.com/MLHdoft.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mejor de La Zarzuela[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_68+"/",
        thumbnail="https://i.imgur.com/nhq4fNY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lounge Music 2019[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_23+"/",
        thumbnail="https://i.imgur.com/JBBhJlm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]M80 Serie Oro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_121+"/",
        thumbnail="https://i.imgur.com/RnSB4FW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Marchas Militares Españolas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_170+"/",
        thumbnail="https://i.imgur.com/xZiu8gV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Marchas Nupciales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_161+"/",
        thumbnail="https://i.imgur.com/IZA7IYc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Marchas De Procesiones y Cofrades[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_128+"/",
        thumbnail="https://i.imgur.com/v4pa3vM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mariachi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_97+"/",
        thumbnail="https://i.imgur.com/UNxdqB1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mejores Canciones Rumba Flamenca Pop 2020-2021[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_27+"/",
        thumbnail="https://i.imgur.com/R5Cdma5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mejores Canciones de la Radio 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_34+"/",
        thumbnail="https://i.imgur.com/s1eaBKA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mejores Canciones Musica rock[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_9+"/",
        thumbnail="https://i.imgur.com/iDA38r1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Merengue[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_153+"/",
        thumbnail="https://i.imgur.com/8JKJzpo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mento Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_163+"/",
        thumbnail="https://i.imgur.com/wDfVaG1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Metal Sinfonico Gotico[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_113+"/",
        thumbnail="https://i.imgur.com/WNCPlsd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Milongas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_169+"/",
        thumbnail="https://i.imgur.com/1wQ3gBu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mix Internacional 2020-2021[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_6+"/",
        thumbnail="https://i.imgur.com/i4avcbK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mix Reggaeton 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_14+"/",
        thumbnail="https://i.imgur.com/G7HgD9Q.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]MTV Greatest Hits[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_61+"/",
        thumbnail="https://i.imgur.com/77rD8gZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mtv Top Songs 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_60+"/",
        thumbnail="https://i.imgur.com/9W3ieuN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]MTV Top Hits[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_62+"/",
        thumbnail="https://i.imgur.com/I1ZjuSS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Barroca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_125+"/",
        thumbnail="https://i.imgur.com/RyYkttl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Brasilera 2020 Lo Mas Escuchado[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_58+"/",
        thumbnail="https://i.imgur.com/ihMknfV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Canaria[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_101+"/",
        thumbnail="https://i.imgur.com/YB2VTF5.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Celta Epica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_81+"/",
        thumbnail="https://i.imgur.com/iYn8iZ5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Clasica Instrumental[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_21+"/",
        thumbnail="https://i.imgur.com/VLFhuAJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Del Alma Kundalini Yoga[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_92+"/",
        thumbnail="https://i.imgur.com/9JId3Um.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Española Flamenco Pop[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_28+"/",
        thumbnail="https://i.imgur.com/CPRNpCl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Folk Latina[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_95+"/",
        thumbnail="https://i.imgur.com/6uOvnoq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Gallega[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_104+"/",
        thumbnail="https://i.imgur.com/XikeTkl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Italiana top 80s-90s-00s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_45+"/",
        thumbnail="https://i.imgur.com/15I8Syb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Navideña Internacional[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_88+"/",
        thumbnail="https://i.imgur.com/SILxjqZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Para Bailar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_17+"/",
        thumbnail="https://i.imgur.com/Ou7Kjmw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Retro Disco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_109+"/",
        thumbnail="https://i.imgur.com/qMTvcIo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Variada de Todo un Poco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_16+"/",
        thumbnail="https://i.imgur.com/RJ018Tm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]New Age[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_159+"/",
        thumbnail="https://i.imgur.com/HxZwpcm.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]New Metal Songs 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_93+"/",
        thumbnail="https://i.imgur.com/QRSyQMA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nightcore 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_148+"/",
        thumbnail="https://i.imgur.com/2c70Ajm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Novedades POP en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_47+"/",
        thumbnail="https://i.imgur.com/5Em3PAr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Opera Rock The Best Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_117+"/",
        thumbnail="https://i.imgur.com/AKDIKiL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pasodobles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_69+"/",
        thumbnail="https://i.imgur.com/QBhm3w9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_54+"/",
        thumbnail="https://i.imgur.com/RBQnFAW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Latino Clasico[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_5+"/",
        thumbnail="https://i.imgur.com/P5eJVmT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Latino Mix 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_20+"/",
        thumbnail="https://i.imgur.com/hcUe0tq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]POP Music  2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_3+"/",
        thumbnail="https://i.imgur.com/bbN45sb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Music Lo Mejor de Todos los Tiempos 2020-2021[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_4+"/",
        thumbnail="https://i.imgur.com/0eq7tXz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Rock En Catala 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_78+"/",
        thumbnail="https://i.imgur.com/a5G4AC0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Punk Rock En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_79+"/",
        thumbnail="https://i.imgur.com/dJwMB0Q.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Rock Best of 1990 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_55+"/",
        thumbnail="https://i.imgur.com/CFbI5Lb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rancheras Para El Recuerdo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_67+"/",
        thumbnail="https://i.imgur.com/KT3IJGx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rap Conciencia Hip -Hop en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_76+"/",
        thumbnail="https://i.imgur.com/0jz5zlD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rap Hip Hop en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_71+"/",
        thumbnail="https://i.imgur.com/IDjIjyC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Reggaeton Hits[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_40+"/",
        thumbnail="https://i.imgur.com/TRPvO7t.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Reggaeton 2019 Playlist & Latin Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_41+"/",
        thumbnail="https://i.imgur.com/L3SQ5YE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Reggae En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_57+"/",
        thumbnail="https://i.imgur.com/XJzhCnd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Reggae Playlist[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_63+"/",
        thumbnail="https://i.imgur.com/RwoHeoK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Retro Disco Infierno[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_132+"/",
        thumbnail="https://i.imgur.com/2Egvoiz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Road Trip Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_150+"/",
        thumbnail="https://i.imgur.com/wIKuXVQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rock A Violin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_114+"/",
        thumbnail="https://i.imgur.com/GPlojss.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]80s y 90s Rock[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_7+"/",
        thumbnail="https://i.imgur.com/vOuU0yR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rockabilly Boogie Woogie[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_133+"/",
        thumbnail="https://i.imgur.com/tVfeXT5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rock Instrumental de Guitarra Electrica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_44+"/",
        thumbnail="https://i.imgur.com/j2skU30.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rock Sinfonico[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_112+"/",
        thumbnail="https://i.imgur.com/eCAqWKM.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rumbas 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_99+"/",
        thumbnail="https://i.imgur.com/YPim42g.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ruta Del Bacalao[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_100+"/",
        thumbnail="https://i.imgur.com/Fokvewf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sintonias TV[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_130+"/",
        thumbnail="https://i.imgur.com/waFnhGS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ska Songs All Time[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_152+"/",
        thumbnail="https://i.imgur.com/bp8CADg.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sophistic Pop[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_172+"/",
        thumbnail="https://i.imgur.com/rCgSu9P.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Spotify Playlist 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_35+"/",
        thumbnail="https://i.imgur.com/MHnErB6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Surf Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_160+"/",
        thumbnail="https://i.imgur.com/33CbTO0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tandas de Tango[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_142+"/",
        thumbnail="https://i.imgur.com/ZV4GxzF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Beatles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_115+"/",
        thumbnail="https://i.imgur.com/COHYV3N.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Third Stream Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_173+"/",
        thumbnail="https://i.imgur.com/0cElGqF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Throwback Exitos de 1990 a 2000[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_149+"/",
        thumbnail="https://i.imgur.com/z19nx22.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Timeless Dance Bachata[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_137+"/",
        thumbnail="https://i.imgur.com/wyhNR9g.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top 50 España Exitos 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_19+"/",
        thumbnail="https://i.imgur.com/OHUtwe0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Best Rhythm aquas & Soul 60s 70s 80s & 90s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_108+"/",
        thumbnail="https://i.imgur.com/vVB0s2n.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Mejores aquas aquas-Rock  Jazz All Time[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_52+"/",
        thumbnail="https://i.imgur.com/nkIeyUi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Mejores Canciones Español 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_50+"/",
        thumbnail="https://i.imgur.com/X1fPsK3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Hip Hop Español 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_72+"/",
        thumbnail="https://i.imgur.com/yRggM5p.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Jazz Classics Songs of All Time[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_51+"/",
        thumbnail="https://i.imgur.com/ThRjE2R.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Las 50 Mejores Canciones del Rap en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_74+"/",
        thumbnail="https://i.imgur.com/u2zu8el.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Musica Italiana del Momento[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_46+"/",
        thumbnail="https://i.imgur.com/NP8qwiG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Musica Piano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_126+"/",
        thumbnail="https://i.imgur.com/RGcOde6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Todo Retro En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_141+"/",
        thumbnail="https://i.imgur.com/jHumbuT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Trap España 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_49+"/",
        thumbnail="https://i.imgur.com/92HJf5u.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Trova[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_157+"/",
        thumbnail="https://i.imgur.com/QKqCmE7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Urban[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_158+"/",
        thumbnail="https://i.imgur.com/XgfVp4C.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Vallenato[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_136+"/",
        thumbnail="https://i.imgur.com/eP5NkL4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Valses[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_162+"/",
        thumbnail="https://i.imgur.com/ZkTTIeU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]VaporWave Best Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_174+"/",
        thumbnail="https://i.imgur.com/bF6lgYm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Villancicos en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_89+"/",
        thumbnail="https://i.imgur.com/yYtbToH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Villancicos Heavy Metal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_90+"/",
        thumbnail="https://i.imgur.com/qvbZxjf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Wednesday Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_77+"/",
        thumbnail="https://i.imgur.com/fQZunsr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Yaravis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_171+"/",
        thumbnail="https://i.imgur.com/qYElmVv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
	    #action="", 
        title="[COLOR aqua]Zen Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_91+"/",
        thumbnail="https://i.imgur.com/Vmg7Kz2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]A Day To Remenber[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_176+"/",
        thumbnail="https://i.imgur.com/9a9jp8K.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Abba[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_177+"/",
        thumbnail="https://i.imgur.com/8qMcf9r.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]AcDc[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_178+"/",
        thumbnail="https://i.imgur.com/kN7n8Xx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Adele[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_179+"/",
        thumbnail="https://i.imgur.com/4nVJfi8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Adelitas Way[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_180+"/",
        thumbnail="https://i.imgur.com/oxFtYS9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Aerosmith[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_181+"/",
        thumbnail="https://i.imgur.com/ZwzaOz5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Airbourne[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_182+"/",
        thumbnail="https://i.imgur.com/WW86GfF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Alan Parsons[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_183+"/",
        thumbnail="https://i.imgur.com/uQikm93.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Alanis Morissette[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_184+"/",
        thumbnail="https://i.imgur.com/coP0PRC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Alaska Y Dinarama[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_185+"/",
        thumbnail="https://i.imgur.com/Hyyxpdz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Alejandro Sanz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_186+"/",
        thumbnail="https://i.imgur.com/l5ErmP5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Alice In Chains[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_187+"/",
        thumbnail="https://i.imgur.com/LlIh3fJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]All That Remains[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_188+"/",
        thumbnail="https://i.imgur.com/74XM5Ke.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Alphaville[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_189+"/",
        thumbnail="https://i.imgur.com/K69A9SB.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Alter Bridge[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_190+"/",
        thumbnail="https://i.imgur.com/rMxmI4f.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Amaral[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_191+"/",
        thumbnail="https://i.imgur.com/VwAmSgj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Amaranthe[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_192+"/",
        thumbnail="https://i.imgur.com/Aak3Du3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]American Authors[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_193+"/",
        thumbnail="https://i.imgur.com/FIzRgyn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Amon Amarth[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_194+"/",
        thumbnail="https://i.imgur.com/ryvP4w6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Amy Winehouse[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_195+"/",
        thumbnail="https://i.imgur.com/T7uboVc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Anthrax[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_196+"/",
        thumbnail="https://i.imgur.com/djE3Jo1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Antonio Orozco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_197+"/",
        thumbnail="https://i.imgur.com/O0ybARK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Aretha Franklin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_198+"/",
        thumbnail="https://i.imgur.com/tPltQ7P.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ariadna Grande[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_199+"/",
        thumbnail="https://i.imgur.com/qQyvkNn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Artic Monkeys[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_200+"/",
        thumbnail="https://i.imgur.com/BZyq1Yz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]As I Lay Dying[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_201+"/",
        thumbnail="https://i.imgur.com/xwbHvYw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Asking Alexandria[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_202+"/",
        thumbnail="https://i.imgur.com/2h0VpHL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Atreyu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_203+"/",
        thumbnail="https://i.imgur.com/DArawdD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Audioslave[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_204+"/",
        thumbnail="https://i.imgur.com/q0rrvXL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Avalanch[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_205+"/",
        thumbnail="https://i.imgur.com/pgvnnS9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Avenged Sevenfold[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_206+"/",
        thumbnail="https://i.imgur.com/2X3x6vX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Aviador Dro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_207+"/",
        thumbnail="https://i.imgur.com/pRn3oIv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Avril Lavigne[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_208+"/",
        thumbnail="https://i.imgur.com/2iTTt5C.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Azucar Moreno[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_209+"/",
        thumbnail="https://i.imgur.com/dk4TUcZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Babymetal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_210+"/",
        thumbnail="https://i.imgur.com/LQBx0Sj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Back Street Boys[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_211+"/",
        thumbnail="https://i.imgur.com/o7Xlb6u.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Bud Bunny[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_2112+"/",
        thumbnail="https://i.imgur.com/MtPOQLt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Bad Wolves[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_212+"/",
        thumbnail="https://i.imgur.com/zAikx1V.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Baron Rojo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_213+"/",
        thumbnail="https://i.imgur.com/OQItE4h.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Barry Whyte[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_214+"/",
        thumbnail="https://i.imgur.com/ri07nPX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Bee Gees[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_215+"/",
        thumbnail="https://i.imgur.com/YuxJS0W.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Beyonce[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_216+"/",
        thumbnail="https://i.imgur.com/Euw7Rpv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Big Time Rush[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_217+"/",
        thumbnail="https://i.imgur.com/e4go1Sc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Billy Idol[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_218+"/",
        thumbnail="https://i.imgur.com/FYkW5Zm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Black Eyed Peas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_219+"/",
        thumbnail="https://i.imgur.com/Fk3RdTP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Black Sabbath[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_220+"/",
        thumbnail="https://i.imgur.com/74wtldm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Black Stone Cherry[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_221+"/",
        thumbnail="https://i.imgur.com/IcXmQWa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Blas Canto[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_222+"/",
        thumbnail="https://i.imgur.com/NIScNvL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Blink 182[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_223+"/",
        thumbnail="https://i.imgur.com/NYraVCv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Blue Oyster Cult[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_224+"/",
        thumbnail="https://i.imgur.com/DKoFWVP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Bob Dylan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_225+"/",
        thumbnail="https://i.imgur.com/pcOJOnS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Bob Marley[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_226+"/",
        thumbnail="https://i.imgur.com/eXDjsdG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Bon Jovi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_227+"/",
        thumbnail="https://i.imgur.com/wrhCbPF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Bonney M[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_228+"/",
        thumbnail="https://i.imgur.com/eJEMseu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Bonnie Tyler[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_229+"/",
        thumbnail="https://i.imgur.com/Noe3HwP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Boston[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_230+"/",
        thumbnail="https://i.imgur.com/RGT1UIq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Breaking Benjamin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_231+"/",
        thumbnail="https://i.imgur.com/VcbQvS8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Bring Me The Horizon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_232+"/",
        thumbnail="https://i.imgur.com/HaITfZJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Bruce Springsteen[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_233+"/",
        thumbnail="https://i.imgur.com/5HwEx9a.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Bruno Mars[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_234+"/",
        thumbnail="https://i.imgur.com/2nOeSUj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Bryan Adams[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_235+"/",
        thumbnail="https://i.imgur.com/9UsEnl9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Bullet For My Valentine[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_236+"/",
        thumbnail="https://i.imgur.com/zUNRHie.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Café Quijano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_237+"/",
        thumbnail="https://i.imgur.com/wFzhKG2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Cafe Tacvba[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_238+"/",
        thumbnail="https://i.imgur.com/ICfzDRA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Caifanes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_239+"/",
        thumbnail="https://i.imgur.com/H4E2JNI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Camaron[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_240+"/",
        thumbnail="https://i.imgur.com/URnMsXl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Camilo Sesto[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_241+"/",
        thumbnail="https://i.imgur.com/hzR8BYy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Celine Dion[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_242+"/",
        thumbnail="https://i.imgur.com/arpzeaB.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Celtas Cortos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_2421+"/",
        thumbnail="https://i.imgur.com/sizNABm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Chicago[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_243+"/",
        thumbnail="https://i.imgur.com/7bpw7LD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Chuck Berry[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_244+"/",
        thumbnail="https://i.imgur.com/LM1tjlP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Cinderella[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_245+"/",
        thumbnail="https://i.imgur.com/tzZEBOY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Coheed And Cambria[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_246+"/",
        thumbnail="https://i.imgur.com/qz9lcz2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Coldplay[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_247+"/",
        thumbnail="https://i.imgur.com/aqsiq5c.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Creedence Clearwater Revival[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_248+"/",
        thumbnail="https://i.imgur.com/24dOf09.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Cyndi Lauper[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_249+"/",
        thumbnail="https://i.imgur.com/wgvyFKC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="",
        title="[COLOR magenta]Dadee Yankee[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_250+"/",
        thumbnail="https://i.imgur.com/vbhutQa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Daft Punk[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_251+"/",
        thumbnail="https://i.imgur.com/G9xxadj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Danzing[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_252+"/",
        thumbnail="https://i.imgur.com/CkeI2L5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]David Bisbal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_253+"/",
        thumbnail="https://i.imgur.com/cb9QzoF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]David Bowei[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_254+"/",
        thumbnail="https://i.imgur.com/0pREhIz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]David Bustamante[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_255+"/",
        thumbnail="https://i.imgur.com/p9Wzeso.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]David Guetta[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_256+"/",
        thumbnail="https://i.imgur.com/KLiLIsi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Deep Puple[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_257+"/",
        thumbnail="https://i.imgur.com/78REQo2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Def Leppard[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_258+"/",
        thumbnail="https://i.imgur.com/3YJdqwz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Deftones[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_259+"/",
        thumbnail="https://i.imgur.com/kRdJzPx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Depeche Mode[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_260+"/",
        thumbnail="https://i.imgur.com/LKfqOks.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Destinys Child[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_261+"/",
        thumbnail="https://i.imgur.com/7tOWYaa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Dio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_262+"/",
        thumbnail="https://i.imgur.com/59ri3oM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Dire Straits[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_263+"/",
        thumbnail="https://i.imgur.com/pRSDrKU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Disturbed[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_264+"/",
        thumbnail="https://i.imgur.com/GXfbApN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Doctor Feelgood[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_265+"/",
        thumbnail="https://i.imgur.com/3fHcczA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Don Omar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_266+"/",
        thumbnail="https://i.imgur.com/Rwgy15X.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Dope[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_267+"/",
        thumbnail="https://i.imgur.com/1ysowkh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Dover[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_268+"/",
        thumbnail="https://i.imgur.com/eDb72W4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Dragonforce[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_269+"/",
        thumbnail="https://i.imgur.com/fFIF8Hq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Dream Theater[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_270+"/",
        thumbnail="https://i.imgur.com/QRw1NAn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Drowing Pool[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_271+"/",
        thumbnail="https://i.imgur.com/I48lKtV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ducan Dhu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_272+"/",
        thumbnail="https://i.imgur.com/i8M64s7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Duran Duran[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_273+"/",
        thumbnail="https://i.imgur.com/DI5IGBa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Eagles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_274+"/",
        thumbnail="https://i.imgur.com/Vxo2u6l.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ed Sheeran[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_275+"/",
        thumbnail="https://i.imgur.com/REVCJLU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Efecto Mariposa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_276+"/",
        thumbnail="https://i.imgur.com/zTexmQs.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]El Arrebato[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_277+"/",
        thumbnail="https://i.imgur.com/N1VI1nL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]El Barrio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_278+"/",
        thumbnail="https://i.imgur.com/dLfoY5L.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]El Canto El Loco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_279+"/",
        thumbnail="https://i.imgur.com/pQlOHM9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]El Ultimo De La Fila[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_280+"/",
        thumbnail="https://i.imgur.com/QfOGBi8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Electric Light Orchestra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_281+"/",
        thumbnail="https://i.imgur.com/btGHWTW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Elton John[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_282+"/",
        thumbnail="https://i.imgur.com/8iADjLD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Elvis Presley[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_283+"/",
        thumbnail="https://i.imgur.com/rPx81P0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Enanitos Verdes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_284+"/",
        thumbnail="https://i.imgur.com/l5yqexI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Enrique Iglesias[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_285+"/",
        thumbnail="https://i.imgur.com/ml45fQY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Enya[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_286+"/",
        thumbnail="https://i.imgur.com/rC9BjLC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Eric Clapton[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_287+"/",
        thumbnail="https://i.imgur.com/nrHZAfV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Estopa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_288+"/",
        thumbnail="https://i.imgur.com/Mko0dS9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Eurythmics[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_289+"/",
        thumbnail="https://i.imgur.com/jqvvzOh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Evanescence[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_290+"/",
        thumbnail="https://i.imgur.com/BZqqUfQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Extremo Duro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_291+"/",
        thumbnail="https://i.imgur.com/eSgbnNy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Faith No More[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_292+"/",
        thumbnail="https://i.imgur.com/UEcksEm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Fall Out Boy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_293+"/",
        thumbnail="https://i.imgur.com/3X0RV40.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Fifth Harmony[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_294+"/",
        thumbnail="https://i.imgur.com/vRt9JDK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Fito y Fitipaldis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_295+"/",
        thumbnail="https://i.imgur.com/4nrTHgq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Five Finger Death Punch[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_296+"/",
        thumbnail="https://i.imgur.com/Suotvnr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Foo Fighters[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_297+"/",
        thumbnail="https://i.imgur.com/hswpYUS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Foreigner[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_298+"/",
        thumbnail="https://i.imgur.com/p62O6GM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Frank Sinatra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_299+"/",
        thumbnail="https://i.imgur.com/zKzbLiu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Frank Zappa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_300+"/",
        thumbnail="https://i.imgur.com/rvE9CJW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Fun[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_301+"/",
        thumbnail="https://i.imgur.com/cXUAx3p.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Gabinete Caligari[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_302+"/",
        thumbnail="https://i.imgur.com/hzUP3EH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Genesis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_303+"/",
        thumbnail="https://i.imgur.com/VJzNbgt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]George Michael[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_304+"/",
        thumbnail="https://i.imgur.com/tVrUZW8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ghost[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_305+"/",
        thumbnail="https://i.imgur.com/hNjVMg7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Girlicious[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_306+"/",
        thumbnail="https://i.imgur.com/sMLCGud.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Girls Aloud[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_307+"/",
        thumbnail="https://i.imgur.com/9aNudJu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Girls Generation[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_308+"/",
        thumbnail="https://i.imgur.com/O05yiDa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Godsmack[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_309+"/",
        thumbnail="https://i.imgur.com/u5H6Zl3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Gojira[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_310+"/",
        thumbnail="https://i.imgur.com/ZFAkxxr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Golpes Bajos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_311+"/",
        thumbnail="https://i.imgur.com/9Vwu432.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Good Charlotte[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_312+"/",
        thumbnail="https://i.imgur.com/7u2KIgw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Gorilaz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_313+"/",
        thumbnail="https://i.imgur.com/V8OpZiM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Green Day[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_314+"/",
        thumbnail="https://i.imgur.com/fHglx8r.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Greta Van Fleet[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_315+"/",
        thumbnail="https://i.imgur.com/MgHEp0g.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Guns And Roses[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_316+"/",
        thumbnail="https://i.imgur.com/RTLwCwk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ha Ash[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_317+"/",
        thumbnail="https://i.imgur.com/GqNsJOC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Halstorm[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_318+"/",
        thumbnail="https://i.imgur.com/f9lsuDK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Helloween[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_319+"/",
        thumbnail="https://i.imgur.com/H4jUoP4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Hellyeah[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_320+"/",
        thumbnail="https://i.imgur.com/zWSPH1O.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Heroes Del Silencio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_321+"/",
        thumbnail="https://i.imgur.com/DAdS1QR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Hombres G[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_322+"/",
        thumbnail="https://i.imgur.com/uwZN3sz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Icona Pop[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_323+"/",
        thumbnail="https://i.imgur.com/wAiMZOd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ilegales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_324+"/",
        thumbnail="https://i.imgur.com/P75aZUs.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Imagine Dragons[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_325+"/",
        thumbnail="https://i.imgur.com/GbEdouC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]In Flames[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_326+"/",
        thumbnail="https://i.imgur.com/ctAkFEq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]In This Moment[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_327+"/",
        thumbnail="https://i.imgur.com/ypPjhzi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Inxs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_328+"/",
        thumbnail="https://i.imgur.com/kgsBUmG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Iron Maiden[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_329+"/",
        thumbnail="https://i.imgur.com/xwHJHIH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Isabel Pantoja[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_330+"/",
        thumbnail="https://i.imgur.com/sa5VQN1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]J Balvin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_331+"/",
        thumbnail="https://i.imgur.com/mI6G2Qd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Jackson 5[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_332+"/",
        thumbnail="https://i.imgur.com/tD8fXWW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]James Blunt[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_333+"/",
        thumbnail="https://i.imgur.com/rjOmtGe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]James Brown[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_334+"/",
        thumbnail="https://i.imgur.com/HG94vKh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Janis Joplin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_335+"/",
        thumbnail="https://i.imgur.com/30vy8e3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Jarabe De Palo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_336+"/",
        thumbnail="https://i.imgur.com/xLMhKyk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Jason Derulo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_337+"/",
        thumbnail="https://i.imgur.com/ChSpBxA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Jeff Beck[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_338+"/",
        thumbnail="https://i.imgur.com/8IIbK0w.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Jenny And The Mexicats[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_339+"/",
        thumbnail="https://i.imgur.com/xGcdLgy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Jesse y Joy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_340+"/",
        thumbnail="https://i.imgur.com/OasaSsz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Jimmy Hendrix[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_341+"/",
        thumbnail="https://i.imgur.com/CgxmMED.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Joan Jett And The Blackhearts[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_342+"/",
        thumbnail="https://i.imgur.com/B95TSxz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Joan Manuel Serrat[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_343+"/",
        thumbnail="https://i.imgur.com/voHYgvt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Joaquin Sabina[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_344+"/",
        thumbnail="https://i.imgur.com/pSVv3I5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]John Coltrane[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_345+"/",
        thumbnail="https://i.imgur.com/fbpAgtg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Jonas Brothers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_346+"/",
        thumbnail="https://i.imgur.com/LPw7QxH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Judas Priest[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_347+"/",
        thumbnail="https://i.imgur.com/EVDJ2jo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Julio Iglesias[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_348+"/",
        thumbnail="https://i.imgur.com/RRblO7s.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Justin Timberlake[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_349+"/",
        thumbnail="https://i.imgur.com/YjytTW1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Kaka Deluxe[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_350+"/",
        thumbnail="https://i.imgur.com/GY1pgGX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Kansas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_351+"/",
        thumbnail="https://i.imgur.com/TaUNWCZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Katy Perry[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_352+"/",
        thumbnail="https://i.imgur.com/vS2WsWN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Killswitch Engage[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_353+"/",
        thumbnail="https://i.imgur.com/F2lcvch.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]King Crimson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_354+"/",
        thumbnail="https://i.imgur.com/4mKURPo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Kings Of Leon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_355+"/",
        thumbnail="https://i.imgur.com/iHTJkpj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Kiss[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_356+"/",
        thumbnail="https://i.imgur.com/PWnjIxR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Korn[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_357+"/",
        thumbnail="https://i.imgur.com/hZXe6nW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Kortatu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_358+"/",
        thumbnail="https://i.imgur.com/FNZQR1y.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Kraftwerk[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_359+"/",
        thumbnail="https://i.imgur.com/TPz2CTi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Kylie Minogue[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_360+"/",
        thumbnail="https://i.imgur.com/Smtudfe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]La Nueva Banda Timberiche[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_361+"/",
        thumbnail="https://i.imgur.com/AT1jiJK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]La Oreja De Van Gogh[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_362+"/",
        thumbnail="https://i.imgur.com/xLlMhXq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]La Quinta Estacion[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_363+"/",
        thumbnail="https://i.imgur.com/y3FhWWX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]La Union[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_364+"/",
        thumbnail="https://i.imgur.com/SQPijT5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Lady Antebellum[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_365+"/",
        thumbnail="https://i.imgur.com/dQp9iMs.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Lady Gaga[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_366+"/",
        thumbnail="https://i.imgur.com/VG4yBiq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Lamb Of God[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_367+"/",
        thumbnail="https://i.imgur.com/QhIZvTu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Led Zeppelin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_368+"/",
        thumbnail="https://i.imgur.com/h4ZqlpU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Lenny Kravitz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_369+"/",
        thumbnail="https://i.imgur.com/ySgIF6P.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Leño[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_370+"/",
        thumbnail="https://i.imgur.com/6Bcd4we.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Leprous[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_371+"/",
        thumbnail="https://i.imgur.com/gernYoW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Limp Bizkit[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_372+"/",
        thumbnail="https://i.imgur.com/N1GtzDx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Linkin Park[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_373+"/",
        thumbnail="https://i.imgur.com/ys1it7N.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Lionel Ritchie[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_374+"/",
        thumbnail="https://i.imgur.com/ku8j0DL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Little Mix[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_375+"/",
        thumbnail="https://i.imgur.com/zx0UsJf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Lone Star[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_376+"/",
        thumbnail="https://i.imgur.com/jRoS4CJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Loquillo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_377+"/",
        thumbnail="https://i.imgur.com/nFAom3e.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Lordi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_378+"/",
        thumbnail="https://i.imgur.com/61Maibq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Los Fabulosos Cadillacs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_379+"/",
        thumbnail="https://i.imgur.com/Qz5BsxW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Los Piratas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_380+"/",
        thumbnail="https://i.imgur.com/clBbsJw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Los Planetas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_381+"/",
        thumbnail="https://i.imgur.com/LPDBYXp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Los Rodriguez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_382+"/",
        thumbnail="https://i.imgur.com/HcqfVeR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Los Salvajes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_383+"/",
        thumbnail="https://i.imgur.com/NcOVpOz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Los Secretos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_384+"/",
        thumbnail="https://i.imgur.com/Vn72Uwb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Los Suaves[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_385+"/",
        thumbnail="https://i.imgur.com/GWA8FQe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Love of Lesbian[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_386+"/",
        thumbnail="https://i.imgur.com/BNJeS0a.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Luis Fonsi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_387+"/",
        thumbnail="https://i.imgur.com/tzgzq9n.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Luis Miguel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_388+"/",
        thumbnail="https://i.imgur.com/kRTpX5q.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]M Clan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_389+"/",
        thumbnail="https://i.imgur.com/Bi1FPrS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Machine Head[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_390+"/",
        thumbnail="https://i.imgur.com/xOq4oXm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Madonna[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_391+"/",
        thumbnail="https://i.imgur.com/2TYEep4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Magic[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_392+"/",
        thumbnail="https://i.imgur.com/Vl2S9UT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Malu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_393+"/",
        thumbnail="https://i.imgur.com/skfAuYa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Maluma[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_394+"/",
        thumbnail="https://i.imgur.com/40Dc35N.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Mana[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_395+"/",
        thumbnail="https://i.imgur.com/0dWfrBW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Manolo Garcia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_396+"/",
        thumbnail="https://i.imgur.com/QO9N2dH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Manolo Tena[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_397+"/",
        thumbnail="https://i.imgur.com/t0hYt8d.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Manuel Carrasco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_398+"/",
        thumbnail="https://i.imgur.com/SPKySUv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Mariah Carey[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_399+"/",
        thumbnail="https://i.imgur.com/aBwQ9HN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Marilyn Manson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_400+"/",
        thumbnail="https://i.imgur.com/5ChQmFX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Maroon 5[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_401+"/",
        thumbnail="https://i.imgur.com/kkMIegO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Mastodon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_402+"/",
        thumbnail="https://i.imgur.com/KUPIAiy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Mecano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_403+"/",
        thumbnail="https://i.imgur.com/7WZ8A4K.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Megadeth[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_404+"/",
        thumbnail="https://i.imgur.com/Du6Fe7Z.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Melendi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_405+"/",
        thumbnail="https://i.imgur.com/iChbwsd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Metallica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_406+"/",
        thumbnail="https://i.imgur.com/CPyojKL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Michael Jackson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_407+"/",
        thumbnail="https://i.imgur.com/5dg2SrI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Miguel Bose[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_408+"/",
        thumbnail="https://i.imgur.com/yMJhBrG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Mike Oldfield[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_409+"/",
        thumbnail="https://i.imgur.com/coDGAGQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Miranda[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_410+"/",
        thumbnail="https://i.imgur.com/zqdbuuv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Misfits[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_411+"/",
        thumbnail="https://i.imgur.com/GlYbhQL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Molotov[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_412+"/",
        thumbnail="https://i.imgur.com/8brYXko.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Moody Blues[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_413+"/",
        thumbnail="https://i.imgur.com/eE1N0VS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Motionless In White[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_414+"/",
        thumbnail="https://i.imgur.com/ck4aBqn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Motley Crue[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_415+"/",
        thumbnail="https://i.imgur.com/HiRSljO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Motorhead[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_416+"/",
        thumbnail="https://i.imgur.com/Fs49W6k.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Mudvayne[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_417+"/",
        thumbnail="https://i.imgur.com/giyqdwp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]My Chemical Romance[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_418+"/",
        thumbnail="https://i.imgur.com/2ewjM1P.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Nacha Pop[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_419+"/",
        thumbnail="https://i.imgur.com/xJvPSyW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Nightwish[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_420+"/",
        thumbnail="https://i.imgur.com/XQGkvnb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Nikki Clan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_421+"/",
        thumbnail="https://i.imgur.com/Mnj7CPf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Nikky Jam[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_422+"/",
        thumbnail="https://i.imgur.com/5o6bkUF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Niña Pastori[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_423+"/",
        thumbnail="https://i.imgur.com/WeFLcrj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Nirvana[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_424+"/",
        thumbnail="https://i.imgur.com/1utuvjX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]No Doubt[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_425+"/",
        thumbnail="https://i.imgur.com/v14qlJO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Nothing More[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_426+"/",
        thumbnail="https://i.imgur.com/6rdgUJY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Nsync[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_427+"/",
        thumbnail="https://i.imgur.com/aaQSm6Q.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ñu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_428+"/",
        thumbnail="https://i.imgur.com/IFniyTh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Oasis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_429+"/",
        thumbnail="https://i.imgur.com/2nSfBy0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Obus[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_430+"/",
        thumbnail="https://i.imgur.com/1EtbBEH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Of Mice And Men[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_431+"/",
        thumbnail="https://i.imgur.com/k8m9nAG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]One Direction[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_432+"/",
        thumbnail="https://i.imgur.com/LNKzQwX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]One Republic[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_433+"/",
        thumbnail="https://i.imgur.com/LNKzQwX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Orquesta Mondragon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_434+"/",
        thumbnail="https://i.imgur.com/2bQ1tTn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Our Last Nigth[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_435+"/",
        thumbnail="https://i.imgur.com/TOoLKzM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ov7[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_436+"/",
        thumbnail="https://i.imgur.com/I9jvfUI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ozuma[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_437+"/",
        thumbnail="https://i.imgur.com/Fj4l9qn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ozzy Osbourne[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_438+"/",
        thumbnail="https://i.imgur.com/amNZYCK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Pablo Alboran[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_439+"/",
        thumbnail="https://i.imgur.com/ZKy00nn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Pablo Lopez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_440+"/",
        thumbnail="https://i.imgur.com/FzPibaw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Paco De Lucia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_441+"/",
        thumbnail="https://i.imgur.com/CvJ5g8P.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Panic At The Disco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_442+"/",
        thumbnail="https://i.imgur.com/8PPoLQs.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Pantera[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_443+"/",
        thumbnail="https://i.imgur.com/zVQLwY9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Papa Roach[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_444+"/",
        thumbnail="https://i.imgur.com/GN4HFKA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Paramore[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_445+"/",
        thumbnail="https://i.imgur.com/cCUI7Se.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Parkway Drive[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_446+"/",
        thumbnail="https://i.imgur.com/oBhlFT3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Pastora Soler[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_447+"/",
        thumbnail="https://i.imgur.com/A1Avv8J.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Pat Benatar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_448+"/",
        thumbnail="https://i.imgur.com/yaAWa49.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Pata Negra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_449+"/",
        thumbnail="https://i.imgur.com/qYc5CGx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Pearl Jam[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_450+"/",
        thumbnail="https://i.imgur.com/9RUiCv2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Pet Shop Boys[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_451+"/",
        thumbnail="https://i.imgur.com/MchfoYu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Peter Gabriel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_452+"/",
        thumbnail="https://i.imgur.com/RehSEWz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Phil Collins[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_453+"/",
        thumbnail="https://i.imgur.com/Oprogtz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Pimpinella[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_454+"/",
        thumbnail="https://i.imgur.com/rDATIUV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Pink[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_455+"/",
        thumbnail="https://i.imgur.com/jPnaame.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Pink Floyd[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_456+"/",
        thumbnail="https://i.imgur.com/YmC999L.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Pitt Bull[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_457+"/",
        thumbnail="https://i.imgur.com/wdGtJcS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Poison[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_458+"/",
        thumbnail="https://i.imgur.com/kcasoR9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Pop Evil[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_459+"/",
        thumbnail="https://i.imgur.com/XF23cH3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Presuntos Implicados[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_460+"/",
        thumbnail="https://i.imgur.com/BKgClVe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Prevail[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_461+"/",
        thumbnail="https://i.imgur.com/YIC74ms.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Prince[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_462+"/",
        thumbnail="https://i.imgur.com/Px2uBRe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Puddle Of Mudd[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_463+"/",
        thumbnail="https://i.imgur.com/JU5citc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Pussy Cat Dolls[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_464+"/",
        thumbnail="https://i.imgur.com/lHYDMjr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Queen[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_465+"/",
        thumbnail="https://i.imgur.com/BRTXZ8y.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Queens Of Stone Age[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_466+"/",
        thumbnail="https://i.imgur.com/EtFRnW7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Quiet Riot[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_467+"/",
        thumbnail="https://i.imgur.com/QBW8neJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Radio Futura[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_468+"/",
        thumbnail="https://i.imgur.com/LtwMNii.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Radiohead[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_469+"/",
        thumbnail="https://i.imgur.com/WEWXnes.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Rage Aganist The Machine[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_470+"/",
        thumbnail="https://i.imgur.com/npy7CoB.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Rainbow[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_471+"/",
        thumbnail="https://i.imgur.com/GN2joO7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Rammstein[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_472+"/",
        thumbnail="https://i.imgur.com/yTcVcPU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ramones[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_473+"/",
        thumbnail="https://i.imgur.com/SDTkgng.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Raphael[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_474+"/",
        thumbnail="https://i.imgur.com/FKzGB6a.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ratt[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_475+"/",
        thumbnail="https://i.imgur.com/enMFCVc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Rbd[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_476+"/",
        thumbnail="https://i.imgur.com/ykHy6Wa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Red Hot Chilli Peppers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_477+"/",
        thumbnail="https://i.imgur.com/WhRPdVO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Reik[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_478+"/",
        thumbnail="https://i.imgur.com/S5G0o4o.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Rem[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_479+"/",
        thumbnail="https://i.imgur.com/5hoLOAr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Reo Speedwagon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_480+"/",
        thumbnail="https://i.imgur.com/yLDu5dp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ricky Martin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_481+"/",
        thumbnail="https://i.imgur.com/yD6nmWo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Rihanna[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_482+"/",
        thumbnail="https://i.imgur.com/GeamDKP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Rise Against[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_483+"/",
        thumbnail="https://i.imgur.com/v2tDIrB.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Rob Zombie[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_484+"/",
        thumbnail="https://i.imgur.com/2RnmnSG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Robbie Williams[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_485+"/",
        thumbnail="https://i.imgur.com/wEtrc9z.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Rocio Jurado[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_486+"/",
        thumbnail="https://i.imgur.com/xyIHUzV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Rod Steward[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_487+"/",
        thumbnail="https://i.imgur.com/bq1iZqA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Rolling Stone[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_488+"/",
        thumbnail="https://i.imgur.com/bPVzrV9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Rosalia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_489+"/",
        thumbnail="https://i.imgur.com/63KhKFC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Roxette[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_490+"/",
        thumbnail="https://i.imgur.com/lDb1qiY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Roxy Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_491+"/",
        thumbnail="https://i.imgur.com/kpXGmFz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Rush[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_492+"/",
        thumbnail="https://i.imgur.com/e3IDNHQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ruth Lorenzo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_493+"/",
        thumbnail="https://i.imgur.com/BM5rmts.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Sabaton[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_494+"/",
        thumbnail="https://i.imgur.com/81epsvZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Sade[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_495+"/",
        thumbnail="https://i.imgur.com/njTcxYC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Savage Garden[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_496+"/",
        thumbnail="https://i.imgur.com/eBEahMu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Scorpions[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_497+"/",
        thumbnail="https://i.imgur.com/1d0Nknr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Seether[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_498+"/",
        thumbnail="https://i.imgur.com/1COzeUA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Seguridad Social[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_499+"/",
        thumbnail="https://i.imgur.com/FZTCUbY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Sevendust[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_500+"/",
        thumbnail="https://i.imgur.com/Caufsty.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Sex Pistols[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_501+"/",
        thumbnail="https://i.imgur.com/92p1wi3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Shinedown[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_502+"/",
        thumbnail="https://i.imgur.com/w3ahtCV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Sia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_503+"/",
        thumbnail="https://i.imgur.com/0iAShQd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Simon And Garlfunken[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_504+"/",
        thumbnail="https://i.imgur.com/qn1UP0K.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Simple Minds[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_505+"/",
        thumbnail="https://i.imgur.com/I0MKPcX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Simple Plan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_506+"/",
        thumbnail="https://i.imgur.com/M4SKqbJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Simply Red[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_507+"/",
        thumbnail="https://i.imgur.com/zrxvEpb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Siniestro Total[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_508+"/",
        thumbnail="https://i.imgur.com/jWywaJ4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Skid Row[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_509+"/",
        thumbnail="https://i.imgur.com/alFyrL8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Skillet[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_510+"/",
        thumbnail="https://i.imgur.com/AfCti1r.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Slash[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_511+"/",
        thumbnail="https://i.imgur.com/76aTnQj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Slayer[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_512+"/",
        thumbnail="https://i.imgur.com/aojRjrP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]SlipKnot[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_513+"/",
        thumbnail="https://i.imgur.com/4CvZtN3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Smashing Pumpkins[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_514+"/",
        thumbnail="https://i.imgur.com/mtErSfe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Sonohra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_515+"/",
        thumbnail="https://i.imgur.com/l9vlCKF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Soundgarden[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_516+"/",
        thumbnail="https://i.imgur.com/3qcgBKv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Spandau Ballet[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_517+"/",
        thumbnail="https://i.imgur.com/r81znvJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Spice Girls[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_518+"/",
        thumbnail="https://i.imgur.com/d8uOEJo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Starset[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_519+"/",
        thumbnail="https://i.imgur.com/48W7C0Q.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Static X[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_520+"/",
        thumbnail="https://i.imgur.com/tVa2viS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Status Quo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_521+"/",
        thumbnail="https://i.imgur.com/u0AIR3X.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Stone Sour[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_522+"/",
        thumbnail="https://i.imgur.com/XoCAgz0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Styx[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_523+"/",
        thumbnail="https://i.imgur.com/yM5t4z3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Supertramp[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_524+"/",
        thumbnail="https://i.imgur.com/ONBHwMG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Surfin Bichos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_525+"/",
        thumbnail="https://i.imgur.com/uXZnJte.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Survivor[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_526+"/",
        thumbnail="https://i.imgur.com/JAFDyLo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]System Of A Donw[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_527+"/",
        thumbnail="https://i.imgur.com/PL99xQK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Talking Heads[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_528+"/",
        thumbnail="https://i.imgur.com/4EkvQo6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Tatu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_529+"/",
        thumbnail="https://i.imgur.com/RXv6Tww.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Tears for Fears[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_530+"/",
        thumbnail="https://i.imgur.com/Iu8HP3E.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ted Nugent[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_531+"/",
        thumbnail="https://i.imgur.com/rx2ktuk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Tequila[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_532+"/",
        thumbnail="https://i.imgur.com/FD9Q7uT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Tesla[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_533+"/",
        thumbnail="https://i.imgur.com/SufrR0x.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The 1975[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_534+"/",
        thumbnail="https://i.imgur.com/I3hp0PT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Amity Affliction[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_535+"/",
        thumbnail="https://i.imgur.com/qBfc4je.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Bangles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_536+"/",
        thumbnail="https://i.imgur.com/8uOV8Ta.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Beach Boys[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_537+"/",
        thumbnail="https://i.imgur.com/NZI2Dg7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Beatles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_538+"/",
        thumbnail="https://i.imgur.com/mKAkEBb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Blues Brothers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_539+"/",
        thumbnail="https://i.imgur.com/J13kfBP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Clash[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_540+"/",
        thumbnail="https://i.imgur.com/GBKN0V4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Communards[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_541+"/",
        thumbnail="https://i.imgur.com/u7wicNW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Corrs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_542+"/",
        thumbnail="https://i.imgur.com/A4xpuPI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Cranberries[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_543+"/",
        thumbnail="https://i.imgur.com/d3h1HC8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Cult[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_544+"/",
        thumbnail="https://i.imgur.com/YYthigE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Cure[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_545+"/",
        thumbnail="https://i.imgur.com/dchTOn9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Doors[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_546+"/",
        thumbnail="https://i.imgur.com/JiN0XwC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Killers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_547+"/",
        thumbnail="https://i.imgur.com/rCY1r4m.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Knack[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_548+"/",
        thumbnail="https://i.imgur.com/LiALYbz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Police[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_549+"/",
        thumbnail="https://i.imgur.com/6vx1Qfk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Pretenders[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_550+"/",
        thumbnail="https://i.imgur.com/coPP3t5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Pretty Reckless[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_551+"/",
        thumbnail="https://i.imgur.com/C25i7qe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Rasmus[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_552+"/",
        thumbnail="https://i.imgur.com/FDQ2i8n.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Vamps[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_553+"/",
        thumbnail="https://i.imgur.com/LJTAo6F.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Velvet Underground[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_554+"/",
        thumbnail="https://i.imgur.com/BBQLGfl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Wanted[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_555+"/",
        thumbnail="https://i.imgur.com/I0Jh3Dk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Waterboys[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_556+"/",
        thumbnail="https://i.imgur.com/O3fmTlO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]The Who[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_557+"/",
        thumbnail="https://i.imgur.com/iZ8VRVq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Theory Of A Deadman[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_558+"/",
        thumbnail="https://i.imgur.com/RB6giew.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Thin Lizzy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_559+"/",
        thumbnail="https://i.imgur.com/Z2T0cnF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Thirty Secons To Mars[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_560+"/",
        thumbnail="https://i.imgur.com/V4FCyVT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Three Days Grace[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_561+"/",
        thumbnail="https://i.imgur.com/E6bLZVR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Tierra Santa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_562+"/",
        thumbnail="https://i.imgur.com/jPZ3l0A.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Tina Turner[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_563+"/",
        thumbnail="https://i.imgur.com/eEOZy6A.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Tino Casal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_564+"/",
        thumbnail="https://i.imgur.com/v72tyGC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Tokio Hotel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_565+"/",
        thumbnail="https://i.imgur.com/0HL8rtG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Tom Jones[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_566+"/",
        thumbnail="https://i.imgur.com/WqzDj8G.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Toni Braxton[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_567+"/",
        thumbnail="https://i.imgur.com/Meq8hUg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Tools[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_568+"/",
        thumbnail="https://i.imgur.com/L1o0Jeq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Toto[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_569+"/",
        thumbnail="https://i.imgur.com/1KBF8nk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Toy Dolls[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_570+"/",
        thumbnail="https://i.imgur.com/KMUsbRE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Tracy Chapman[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_571+"/",
        thumbnail="https://i.imgur.com/lLSOfbr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Train[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_572+"/",
        thumbnail="https://i.imgur.com/4KoWWcL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Triana[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_573+"/",
        thumbnail="https://i.imgur.com/xiX5xPj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Trivium[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_574+"/",
        thumbnail="https://i.imgur.com/7Inpzxr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Twisted Sister[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_575+"/",
        thumbnail="https://i.imgur.com/IhEIBzt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]U2[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_576+"/",
        thumbnail="https://i.imgur.com/7KYOa3l.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ub40[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_577+"/",
        thumbnail="https://i.imgur.com/L60wAvH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ufo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_578+"/",
        thumbnail="https://i.imgur.com/VpfelZy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ugly Kid Joe[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_579+"/",
        thumbnail="https://i.imgur.com/2lrw8l6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ultraspank[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_580+"/",
        thumbnail="https://i.imgur.com/85umw6M.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Ultravox[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_581+"/",
        thumbnail="https://i.imgur.com/oI8veeE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Umberto Tozzi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_582+"/",
        thumbnail="https://i.imgur.com/jiAqpt1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Undisputed Truth[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_583+"/",
        thumbnail="https://i.imgur.com/mIs783b.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Unknown Mortal Orchestra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_584+"/",
        thumbnail="https://i.imgur.com/0crPiFM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Urge Overkill[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_585+"/",
        thumbnail="https://i.imgur.com/mnUvDwr.jpghttps://i.imgur.com/4F2dJEW.jpg",
		fanart="https://i.imgur.com/CGRFk7P.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Uriah Heep[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_586+"/",
        thumbnail="https://i.imgur.com/sNMNgOT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Usher[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_587+"/",
        thumbnail="https://i.imgur.com/GPSjbJ8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Van Halen[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_588+"/",
        thumbnail="https://i.imgur.com/H6QEg7d.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Vetusta Morla[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_589+"/",
        thumbnail="https://i.imgur.com/hDXmBgn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Village People[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_590+"/",
        thumbnail="https://i.imgur.com/RMpmwUW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Volbeat[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_591+"/",
        thumbnail="https://i.imgur.com/gFV1pGk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Warcry[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_592+"/",
        thumbnail="https://i.imgur.com/UhhQviP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Warrant[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_593+"/",
        thumbnail="https://i.imgur.com/TE5gOhQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Wasp[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_594+"/",
        thumbnail="https://i.imgur.com/cmRhLu8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Westlife[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_595+"/",
        thumbnail="https://i.imgur.com/EN0aNMe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Whisbone Ash[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_596+"/",
        thumbnail="https://i.imgur.com/AeWzNY9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]White Snake[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_597+"/",
        thumbnail="https://i.imgur.com/PgpiBOg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Whitney Houston[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_598+"/",
        thumbnail="https://i.imgur.com/hzNu2jw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Within Templation[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_599+"/",
        thumbnail="https://i.imgur.com/OyirEeb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Zak Abel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_600+"/",
        thumbnail="https://i.imgur.com/olprY2m.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Zara Larsson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_601+"/",
        thumbnail="https://i.imgur.com/ShTWD6B.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Zion And Lennox[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_602+"/",
        thumbnail="https://i.imgur.com/vpbinJd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Zoe[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_603+"/",
        thumbnail="https://i.imgur.com/FbQ6cEv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR magenta]Zz Top[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_604+"/",
        thumbnail="https://i.imgur.com/ce2Yy2a.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
run()